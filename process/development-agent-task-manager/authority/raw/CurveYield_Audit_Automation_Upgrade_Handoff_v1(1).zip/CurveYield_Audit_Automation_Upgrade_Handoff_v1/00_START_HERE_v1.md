# CurveYield Audit Automation Upgrade — START HERE

Version: v1  
Snapshot date: 2026-09-24 / 2026-09-25 UTC transition  
Primary repositories:
- `CurveYield2/Audit-Controller`
- `CurveYield2/Contract-Automation`

## Mission

Continue the approved **Audit Agent Workload Reduction Layer v1** without restarting, re-designing, or duplicating existing systems.

The central engineering rule is:

> **Reuse existing processes first. Extend them second. Refactor them third. Invent a new process only when the existing system genuinely cannot carry the requirement.**

This rule is especially binding for:
- GitHub bridges
- request transport
- phase gates
- handoffs
- qualification
- evidence ledgers
- web-agent wake/watchdog systems
- source admission/import
- cross-repository GitHub operations

## Current high-level state

The workload-reduction architecture has been substantially implemented on:

- Audit-Controller draft PR **#50**
- branch: `automation/audit-workload-reduction-v1`
- last captured head: `ae7568ae57dede1a182f79e8badf769892296d2d`
- state: OPEN / DRAFT
- mergeable at final snapshot: true

The redundant second audit-operator bridge was designed, implemented, then correctly removed after discovering that the canonical V7 atomic request bridge should be extended instead.

The canonical execution path is now:

`Audit-Controller private request`
→ `minimal public controller-operation pointer`
→ existing `v7:submit` / atomic request branch + trace PR
→ existing `V7 Audit Controller Execution` workflow
→ deterministic controller operation
→ private result writeback

The canonical workflow is:
`CurveYield2/Contract-Automation/.github/workflows/audit-controller-execution.yml`

## Critical current blocker / finding

The controller-operation E2E reaches the private Audit-Controller access step but GitHub returns **401 Bad credentials** when the canonical workflow tries to use `AUDIT_CONTROLLER_GITHUB_TOKEN`.

Important:
- This does **not** mean normal web agents cannot write cross-repository.
- It does **not** mean the GitHub connector is broken.
- It does **not** mean the workflow architecture is wrong.
- The same secret name is used in other workflows.
- `agent-zip-import-v1.yml` demonstrates the preferred/proven cross-repository pattern using `gh api`, `gh auth setup-git`, `gh repo clone`, `git fetch`, and ordinary authenticated Git operations.
- The canonical V7 workflow was refactored to use that exact pattern.
- Despite that, the controller-operation E2E still received `401 Bad credentials`, proving the remaining problem is the actual Actions-side credential validity/scope in that workflow context.

Do not invent another bridge or secret path until existing credential behavior is conclusively resolved.

## Latest captured Contract-Automation qualification

Status: PASS  
Qualified commit: `181868f6dd6828134e471930d16c6f36b1d7a294`  
Qualification run: `36075488259`

Full matrix passed:
- GitHub-native
- Anvil runner
- full Node suite
- static checks
- build checks
- toolchain verification
- Slither
- Medusa
- Forge
- Phase 6
- Phase 7

**Mandatory:** before merging PR #50, re-read `Contract-Automation@main/process/V7_QUALIFICATION_STATUS.json` and bind Audit-Controller to the newest qualified commit/run. Contract-Automation main was still moving because browser-agent automation was actively landing.

## Major new capability discovered during this work

The repository now contains browser/web-agent automation capable of:
- waking/resuming an existing ChatGPT web-agent conversation;
- creating a fresh ChatGPT web-agent conversation;
- injecting an instruction/wake message;
- maintaining a 5-minute productivity watchdog;
- avoiding interruption while the agent is visibly productive;
- terminating the watchdog after terminal completion;
- validating browser-agent phase completion using separate approved phase-report evidence.

This means web agents are no longer useful only in Phase 0.

The intended future architecture is:

`reasoning reviewer completes phase`
→ machine validates completion/retirement
→ handoff boundary
→ wake/create web grunt worker
→ web worker performs only mechanical inter-phase work
→ machine validates grunt completion
→ wake next reasoning reviewer
→ next phase begins

The web grunt worker must never own semantic security decisions.

## Read order

1. `01_AUTOMATION_UPGRADE_SPECIFICATION_v1.md`
2. `02_IMPLEMENTATION_STATUS_v1.md`
3. `03_ARCHITECTURE_AND_INVARIANTS_v1.md`
4. `04_WEB_AGENT_INTERPHASE_DESIGN_v1.md`
5. `05_CREDENTIAL_AND_BRIDGE_INVESTIGATION_v1.md`
6. `06_CHRONOLOGICAL_ENGINEERING_LOG_v1.md`
7. `07_EXACT_RESUME_CHECKLIST_v1.md`
8. `08_REPO_PATHS_AND_IDENTITIES_v1.md`
9. `09_ACTIVE_PRS_RUNS_AND_BRANCHES_v1.json`
10. `10_SUCCESSOR_WAKE_MESSAGE_v1.txt`

Do not restart completed design or implementation work.
