# Architecture Decisions and Invariants

Version: v1

## Permanent decisions

### One canonical V7 bridge

There must not be a separate audit workload-reduction bridge.

Use:
`.github/workflows/audit-controller-execution.yml`

### Atomic public pointer / private request split

Public pointer contains only:
- request ID;
- exact Audit-Controller repository;
- exact Audit-Controller commit;
- exact private request path;
- verify-controller flag.

Sensitive/private campaign state remains private.

### Public execution plane

All reusable/rate-limited compute belongs in Contract-Automation.

### Progressive disclosure

Reviewers should receive only current work context.

Do not preload future phases or unrelated specialist resources.

### Security judgment cannot be automated away

Machine automation can prove completeness/identity.
It cannot decide substantive security conclusions.

### Retirement is machine-gated

Agent cannot retire until required machine gates pass.

### Existing qualification is authoritative

The admitted execution contract binds exact qualified runner identity.

### Existing ledgers stay authoritative

New queue/projection code should consume existing ledger dialects rather than replace them.

### Existing wake/watchdog system stays authoritative

Do not build a new browser-agent dispatcher.

### Existing phase-completion approval stays authoritative

Web-agent grunt completion should eventually integrate with the existing approved-report/phase-completion workflow rather than inventing a competing terminal marker.

## Key anti-patterns already discovered

Do not:
- create a second bridge;
- create a second submitter;
- add a new private workflow because private files are inconvenient;
- let raw `"PASS"` strings satisfy completion;
- initialize Foundry/Medusa/Anvil for JSON-only controller work;
- let automation auto-promote findings;
- confuse Lite route folders with semantic contract IDs;
- assume unknown obligation status is terminal;
- use a new secret merely because one workflow cannot authenticate;
- assume cross-repo GitHub connector capability implies Actions token capability.
