# Exact Resume Checklist

Version: v1

A successor should execute these steps in order.

## 1. Do not restart design

Read:
- this packet;
- Audit-Controller PR #50;
- current Contract-Automation main;
- current V7 qualification status.

Do not recreate the deleted parallel bridge.

## 2. Freeze current repo identities

Fetch:
- `CurveYield2/Contract-Automation@main`
- `CurveYield2/Audit-Controller@main`
- Audit-Controller PR #50 head
- `process/V7_QUALIFICATION_STATUS.json`

Record exact SHAs.

## 3. Resolve the credential blocker

Current real E2E fails with:
`401 Bad credentials`

at private Audit-Controller `gh api`.

Investigate existing `AUDIT_CONTROLLER_GITHUB_TOKEN`.

Do not change architecture first.

If token is stale, replace the existing secret rather than adding a new credential name/path.

## 4. Rerun the existing E2E

Use request:
`awr-e2e-canonical-v1`

Use existing trace PR #230 if still useful, or recreate atomically from current main while preserving same request semantics.

Expected successful steps:
- resolve pointer;
- skip heavy setup;
- private controller auth succeeds;
- exact PR #50 commit checked out;
- optional full controller verify succeeds;
- private operation request validates;
- skill package resolves;
- operator runs;
- results write back to exact private branch;
- compare-and-swap protection passes.

## 5. Verify private controller code

Require complete:
`npm run verify`

against exact current PR #50 head.

Do not merge PR #50 before exact verification passes.

## 6. Rebind qualified runner

Read newest:
`Contract-Automation/process/V7_QUALIFICATION_STATUS.json`

Update in Audit-Controller:
- admitted execution contract qualified commit;
- canonical qualification run ID;
- qualified-runner policy test;
- synthetic/current-runner fixture.

Never bind raw main without qualification.

## 7. Re-read PR #50 diff for redundancy

Keep existing-process-first discipline.

If a new module duplicates mature controller functionality:
- reuse mature primitive;
- keep only Lite-specific orchestration where required.

Do not force Full/v26 semantics onto Lite contracts.

## 8. Integrate inter-phase web grunt lane

First inspect current main because wake/handoff automation was actively landing.

Reuse:
- browser-agent wake;
- watchdog;
- phase-completion approval;
- existing successor handoff workflow.

Do not add another web-agent dispatcher.

Add mechanical inter-phase work only.

Recommended initial boundaries:
- P1→P2
- P5→P6
- P67→P8
- P9→P10

Phase 0 remains a major web-bootstrap lane.

## 9. Test

Run:
- existing canonical bridge tests;
- full Contract-Automation V7 qualification where affected;
- full Audit-Controller verify;
- one real Lite current-state projection;
- one completion/retirement fail-closed test;
- one validated handoff;
- one web-agent mechanical boundary test.

## 10. Merge/cleanup

When all green:
- make PR #50 non-draft;
- merge;
- delete/retire implementation branch;
- close/delete trace request branches/PRs with recorded disposition;
- verify no redundant operator bridge remains;
- ensure all live code is on main;
- update skill/repo compatibility documentation if required by latest skill-update rules.
