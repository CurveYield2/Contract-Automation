# Reference Snapshot — Browser Agent Wake Registration

Version: v1

Source:
`CurveYield2/Contract-Automation`
path `process/browser-agent-wake/README.md`
captured file SHA: `0b0dedf81239dc5539a9705c371393ff0adba8ad`

Captured behavior:
- registration file per campaign;
- `resume_existing` and `create_fresh`;
- wake message;
- 5-minute watchdog;
- completion target;
- productivity-aware non-interruption;
- provider redundancy:
  1. GitHub Playwright + ChatGPT storage state
  2. Browserless
  3. Browserbase
- all wake/watchdog automation stays in Contract-Automation.

Use live repo file if newer.
