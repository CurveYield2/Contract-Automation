# Reference Snapshot — AUDIT_WORKLOAD_REDUCTION_LAYER

Version: v1

Source:
`CurveYield2/Audit-Controller`
branch `automation/audit-workload-reduction-v1`
path `docs/agent-guides/AUDIT_WORKLOAD_REDUCTION_LAYER_v1.md`
captured file SHA: `6226ef7ab59adc7866253fa9919cc9e468b988b0`

Key contents captured:
- deterministic workload-reduction purpose;
- Audit-Controller private authority / Contract-Automation public execution boundary;
- one canonical bridge;
- private operation request + public atomic pointer;
- operations: PROJECT_CURRENT_STATE, BUILD_EXECUTION_REQUEST, INGEST_EXECUTION_EVIDENCE, BUILD_SUCCESSOR_HANDOFF;
- completion/retirement invariant;
- Lite compressed-phase identity;
- existing cross-repo credential boundary.

Use live repo file if newer.
