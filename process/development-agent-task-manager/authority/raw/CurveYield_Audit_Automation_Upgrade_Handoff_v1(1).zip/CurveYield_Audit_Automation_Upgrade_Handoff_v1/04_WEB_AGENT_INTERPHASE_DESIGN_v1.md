# Web-Agent Inter-Phase Mechanical Worker Design

Version: v1

## Why this changed

Initial design assumed web agents were practical only in Phase 0 because they could not directly coordinate with successor agents and scheduled wake-up was coarse.

New GitHub workflow capability changes that assumption.

The repository can now:
- wake an existing web ChatGPT agent;
- create a fresh web ChatGPT agent;
- post an instruction automatically;
- monitor it every five minutes;
- avoid interrupting productive work;
- stop the watchdog after terminal completion;
- separately approve phase-completion evidence.

Therefore web agents can safely be used at phase boundaries without human relay.

## Proposed boundary architecture

### Stage A — reasoning reviewer

Reviewer completes semantic phase responsibilities.

### Stage B — machine validation

Automation validates:
- report;
- outputs;
- step dispositions;
- sealing criteria;
- obligations;
- execution receipts;
- retirement readiness.

### Stage C — web mechanical worker

When useful, wake/create web agent.

It receives:
- exact immutable repo URL;
- exact Start Here;
- exact mechanical work packet;
- do-not-repeat list;
- prohibited semantic tasks;
- completion target.

### Stage D — mechanical completion gate

Automation verifies:
- expected files exist;
- digests;
- ledger updates;
- indexed evidence;
- required report/receipt;
- no unauthorized semantic changes.

### Stage E — successor reviewer

Generate validated successor handoff and wake the next reasoning reviewer.

## Candidate grunt passes

### P0 → P1
- finalize bootstrap artifact inventory;
- digest verification;
- Source Intelligence file/index checking;
- automation completion reconciliation;
- Start Here/handoff packaging.

### P1 → P2
- reconcile build/static/source-intelligence artifacts;
- index references;
- prepare exact Phase-2 inputs;
- ledger/status normalization.

### P5 → P6
- handoff package assembly;
- evidence index refresh;
- obligation due-set extraction;
- exact execution-request scaffolding;
- runner/qualification identity prefill.

### P6/7 → P8
- ingest returned execution evidence;
- index candidates/evidence mechanically;
- update evidence references;
- reproduce missing-output list;
- no candidate disposition.

### P8 → P9
- remediation-workspace mechanical preparation;
- source/evidence identity checks;
- candidate/finding artifact collation;
- no remediation correctness decision.

### P9 → P10
- final evidence index prefill;
- closure artifact inventory;
- digest and provenance table assembly;
- unresolved-obligation list generation.

## Prohibited web grunt work

Never delegate:
- candidate promotion/rejection;
- severity grading;
- exploit validity judgment;
- materiality;
- architecture/threat interpretation;
- remediation acceptance;
- residual risk;
- ambiguous source semantics.

## Wake system facts captured

Registration path:
`process/browser-agent-wake/registrations/<SAFE_CAMPAIGN_ID>.json`

Modes:
- `resume_existing`
- `create_fresh`

Watchdog:
- 5-minute cycles
- productivity-aware
- terminal completion target
- redundant providers

Wake/provider order documented:
1. GitHub-hosted Playwright using ChatGPT storage state
2. Browserless
3. Browserbase

Do not modify this stack casually; it was actively being hardened during this task.
