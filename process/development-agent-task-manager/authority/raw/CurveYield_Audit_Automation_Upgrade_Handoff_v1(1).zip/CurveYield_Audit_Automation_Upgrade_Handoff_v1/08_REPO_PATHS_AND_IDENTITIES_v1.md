# Repository Paths and Identity Index

Version: v1

## Audit-Controller

Repo:
`CurveYield2/Audit-Controller`

Primary implementation branch:
`automation/audit-workload-reduction-v1`

Draft PR:
`#50`

Key files:
- `docs/agent-guides/AUDIT_WORKLOAD_REDUCTION_LAYER_v1.md`
- `.deep-assurance/operator/README_v1.md`
- `packages/controller-core/src/audit-operator-cli-v1.mjs`
- `packages/controller-core/src/phase-work-queue-v1.mjs`
- `packages/controller-core/src/current-work-packet-v1.mjs`
- `packages/controller-core/src/phase-completion-report-validator-v1.mjs`
- `packages/controller-core/src/automation-completion-validator-v1.mjs`
- `packages/controller-core/src/phase-retirement-gate-v1.mjs`
- `packages/controller-core/src/execution-request-builder-v1.mjs`
- `packages/controller-core/src/execution-evidence-ingestor-v1.mjs`
- `packages/controller-core/src/successor-handoff-builder-v1.mjs`
- `packages/controller-core/test/audit-workload-reduction-v1.test.mjs`
- `packages/controller-core/test/audit-workload-reduction-extended-v1.test.mjs`
- `protocol/schemas/audit-workload-reduction-request-v1.schema.json`
- `protocol/schemas/audit-controller-operation-pointer-v1` lives in Contract-Automation

Operator request path:
`.deep-assurance/operator/requests/<request-id>.json`

E2E request:
`.deep-assurance/operator/requests/awr-e2e-canonical-v1.json`

## Contract-Automation

Repo:
`CurveYield2/Contract-Automation`

Canonical V7 workflow:
`.github/workflows/audit-controller-execution.yml`

Atomic request submitter:
`packages/github-native-sim/src/request-submission-v1.mjs`

Atomic request resolver:
`packages/github-native-sim/src/request-resolution-v1.mjs`

Controller pointer validator:
`packages/github-native-sim/src/controller-operation-pointer-v1.mjs`

V7 CLI:
`packages/github-native-sim/src/v7-cli.mjs`

Bridge regression tests:
- `packages/github-native-sim/test/atomic-request-bridge-v1.test.mjs`
- `packages/github-native-sim/test/execution-workflow-v2.test.mjs`

Qualification:
- `.github/workflows/v7-execution-infrastructure-qualification.yml`
- `process/V7_QUALIFICATION_STATUS.json`

Web-agent systems:
- `.github/workflows/browser-agent-wake.yml`
- `.github/workflows/browser-agent-watchdog.yml`
- phase-completion approval workflow on current main
- `process/browser-agent-wake/README.md`
- `scripts/browser-agent-wake.mjs`

Cross-repo reference implementation:
`.github/workflows/agent-zip-import-v1.yml`

## Important PRs

Audit-Controller:
- PR #50 — workload reduction layer — active draft

Contract-Automation:
- PR #230 — trace-only E2E controller-operation request — active at snapshot
- PR #235 — gh-clone private-access repair — merged/closed after qualification

## Important historical runs

- `36073323988` — earlier PASS qualification for `c0d1a6c...`
- `36074475152` — PASS qualification for `009ed34f...`
- `36075488259` — captured latest PASS qualification for `181868f6...`
- `36075475465` — real E2E controller operation; failed at private credential with 401

Always prefer current status file over these historical numbers.
