# Cross-Repository Credential and Bridge Investigation

Version: v1

## Why this investigation happened

A real canonical controller-operation E2E failed at private Audit-Controller checkout.

Initial mistaken inference:
- "cross-repo writes may be broken."

User correctly stated cross-repo writes definitely work.

That forced a deeper historical inspection.

## Findings

### GitHub connector/web agents

Cross-repository operations through the connected GitHub app work.

This is separate from GitHub Actions secret behavior.

### `agent-zip-import-v1.yml`

A newly landed fanout workflow demonstrates the preferred/proven style:
- set `GH_TOKEN`;
- `gh api repos/<repo> --silent`;
- `gh auth setup-git`;
- `gh repo clone`;
- `git fetch`;
- normal authenticated Git commit/push.

This was identified as the likely "trick" the user remembered.

### Canonical bridge repair

The canonical `audit-controller-execution.yml` was changed to use the same style instead of private `actions/checkout`.

The change was qualified on PR #235 and merged.

### E2E after repair

The real controller-operation E2E was rerun.

At:
`gh api repos/CurveYield2/Audit-Controller --silent`

GitHub returned:
**401 Bad credentials**

Therefore:
- the secret is present enough to be masked/injected;
- failure is not due to `actions/checkout`;
- failure is not due to ref/SHA fetch;
- failure is not due to request resolver;
- failure is not due to bridge topology;
- current blocker is token validity or authorization.

## Existing token candidates

### `AUDIT_CONTROLLER_GITHUB_TOKEN`

Canonical intended private-controller credential.

Currently returns 401 in controller-operation E2E.

### `PREFLIGHTSIM_GITHUB_TOKEN`

Existing broader token used by the deployed PreflightSim/GitHub bridge service.

Do NOT repurpose blindly.

Current evidence proves it can drive existing GitHub service behavior, but does not yet prove private Audit-Controller contents/write scope.

Test/reuse existing credential before creating new token.

## Recommended next credential procedure

1. Inspect current successful workflows using `AUDIT_CONTROLLER_GITHUB_TOKEN`.
2. Determine whether any have succeeded against private Audit-Controller after the current timestamp.
3. If all fail with 401, treat token as stale/expired/revoked.
4. Replace **that existing secret** rather than inventing a new auth path.
5. Give replacement minimum required private repo scopes:
   - read Audit-Controller contents;
   - write Audit-Controller contents/branches required by canonical writeback.
6. Rerun the existing controller-operation E2E.
7. Do not change bridge architecture unless credential replacement still fails.

## Critical distinction

"Cross-repo GitHub writes work" and "this Actions secret authenticates" are different facts.

Do not conflate them again.
