# Phase 0 Universal Source ZIP Fan-Out Protocol

## Purpose

Every Lite audit begins by preserving the exact audit source ZIP supplied to the `web-bootstrap-agent` at wake-up in both canonical CurveYield repositories. This is a universal Phase-0 bootstrap requirement for every audit. It is mechanical source admission only; it does not authorize semantic audit judgments.

## Canonical destinations

Use the exact audit name resolved in Phase 0 Step 1 as `<AUDIT_NAME>` and preserve the exact source ZIP filename as `<SOURCE_ZIP_FILENAME>`.

The exact same ZIP bytes MUST be present at both destinations on `main`:

1. `CurveYield2/Audit-Controller`: `campaigns/<AUDIT_NAME>/source/<SOURCE_ZIP_FILENAME>`
2. `CurveYield2/Audits`: `<AUDIT_NAME>/source/<SOURCE_ZIP_FILENAME>`

The top-level audit folder is therefore under `campaigns/` in `Audit-Controller`, and directly at repository root in `Audits`.

### Hard repository-automation boundary

- **No GitHub Actions workflow may be created or executed from `Audit-Controller` for this transfer.**
- **No GitHub Actions workflow may be created or executed from `Audits` for this transfer.**
- All automated download/verification/write activity is initiated and executed from `CurveYield2/Contract-Automation` using its admitted cross-repository credential path.
- Never copy secrets, tokens, credentials, or private keys into the source ZIP, request manifest, audit repositories, logs, or completion report.

## Mandatory procedure

### 1. Freeze the exact audit/source identity

Before transfer:

- resolve the exact `<AUDIT_NAME>` from the current audit authority/campaign identity;
- identify the authoritative source ZIP supplied to the web-bootstrap agent at wake-up;
- preserve the original filename exactly;
- record the byte size;
- record the source archive SHA-256 when available from the attached-file/runtime evidence;
- do not re-zip, unpack/repack, normalize, rename, or otherwise transform the source archive before fan-out.

If a SHA-256 is not available from the attachment/runtime, do not invent one. The Contract-Automation importer must calculate the downloaded ZIP SHA-256 and record it as the admitted source digest before repository writeback.

### 2. Upload the exact ZIP with the connected Google Drive app

Use the connected Google Drive app to upload the exact source ZIP as an ordinary raw ZIP file. Record:

- Drive file ID;
- Drive browser URL;
- exact filename;
- byte size.

Do not convert the ZIP to a Google Workspace file.

### 3. Make the Drive object link-readable with the authenticated TinyFish Drive profile

Use TinyFish browser automation with the saved/default authenticated Google Drive browser profile.

Open the exact uploaded Drive file by file ID/URL and set:

- **General access:** `Anyone with the link`
- **Role:** `Viewer`

Copy the resulting shareable link and bind it to the exact Drive file ID. Do not substitute another similarly named Drive object.

If the saved Drive session is stale, repair/re-authenticate the saved TinyFish Drive profile and retry the same file. Do not abandon the method merely because an unauthenticated browser session fails.

### 4. Create the universal fan-out import request in Contract-Automation

Using the GitHub connector, create a fresh request JSON under:

`CurveYield2/Contract-Automation@main:.agent-upload/requests/<REQUEST_ID>.json`

The request MUST identify one source and both canonical destinations. Use this schema shape:

```json
{
  "schema": "curveyield-audit-source-fanout/v1",
  "request_id": "<stable-unique-request-id>",
  "audit_name": "<AUDIT_NAME>",
  "source": {
    "type": "google-drive",
    "url": "<ANYONE_WITH_LINK_URL>",
    "drive_file_id": "<DRIVE_FILE_ID>",
    "filename": "<SOURCE_ZIP_FILENAME>",
    "sha256": "<SOURCE_SHA256_IF_KNOWN>",
    "size": "<SOURCE_BYTE_SIZE>"
  },
  "targets": [
    {
      "repository": "CurveYield2/Audit-Controller",
      "branch": "main",
      "path": "campaigns/<AUDIT_NAME>/source/<SOURCE_ZIP_FILENAME>"
    },
    {
      "repository": "CurveYield2/Audits",
      "branch": "main",
      "path": "<AUDIT_NAME>/source/<SOURCE_ZIP_FILENAME>"
    }
  ]
}
```

If the exact admitted importer schema uses an equivalent field name or wrapper while preserving the same two fixed destinations and identity requirements, use the admitted schema. Do not omit either destination and do not redirect the source ZIP to an ad-hoc location.

### 5. Supervise the Contract-Automation import workflow to terminal state

Observe the admitted `Contract-Automation` source-import/fan-out workflow to terminal state. Starting the workflow is not completion.

The workflow must, at minimum:

1. parse and validate the request;
2. reject unsafe/ambiguous repository paths;
3. download the exact Drive object;
4. verify ZIP magic bytes;
5. verify byte size when supplied;
6. calculate SHA-256 and compare it with the pre-transfer SHA-256 when supplied;
7. write the exact verified ZIP bytes to both canonical destination paths;
8. use only admitted Contract-Automation-held credentials for cross-repository writeback;
9. handle concurrent `main` updates without force-pushing or discarding unrelated commits;
10. report terminal per-destination success/failure evidence.

Any failure, missing destination, hash mismatch, size mismatch, non-ZIP response, authentication failure, or write race that cannot be safely repaired leaves Phase 0 active.

### 6. Independently verify both destination copies

After workflow success, use the GitHub connector to verify both canonical repository paths exist on `main` and correspond to the same admitted source identity.

Record for each destination:

- repository;
- branch;
- full path;
- filename;
- Git object/blob identity returned by GitHub;
- byte size;
- source SHA-256 proven by the importer/completion evidence;
- workflow run/job identity that performed the write.

The agent may not treat source admission as complete until both copies are verified.

## Failure / repair rules

- If the Google Drive app upload fails, retry the same exact source object through the connected Drive app before changing methods.
- If TinyFish opens an unauthenticated Drive session, use the saved/default authenticated Drive profile and retry the exact file ID.
- If a cross-repository push races with another `main` update, the importer must fetch/rebase/retry safely; force-push is forbidden.
- If the Contract-Automation cross-repository token cannot write a required destination, fail closed and repair the existing admitted credential path. Do not create a workflow in `Audit-Controller` or `Audits` as a workaround.
- Never fall back to model-mediated base64/Git-blob upload for normal source ZIP transfer while this admitted Drive-to-Contract-Automation path is available.

## Completion evidence

Phase 0 source fan-out is `PASS` only when all of the following are true:

- one exact source ZIP identity is bound to the audit;
- the Drive file ID and link-readable URL are recorded;
- the Contract-Automation request/run/job identity is recorded;
- `Audit-Controller/campaigns/<AUDIT_NAME>/source/<SOURCE_ZIP_FILENAME>` exists and is verified;
- `Audits/<AUDIT_NAME>/source/<SOURCE_ZIP_FILENAME>` exists and is verified;
- both destination copies are bound to the same admitted source SHA-256/size;
- no transfer workflow was created or run from `Audit-Controller` or `Audits`.

Record these facts in `PHASE0_WEB_BOOTSTRAP_COMPLETION_REPORT.md` and the campaign source fence before Phase-0 retirement.
