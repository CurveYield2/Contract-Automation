#!/usr/bin/env python3
import subprocess,sys
raise SystemExit(subprocess.call([sys.executable,'tests/validate_skill.py','.']))
