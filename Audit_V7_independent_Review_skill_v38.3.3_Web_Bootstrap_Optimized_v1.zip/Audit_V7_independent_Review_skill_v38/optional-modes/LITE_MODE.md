# Optional Lite Mode

This router is outside the normal pathway. Use it only after the human explicitly says `use lite mode`.

- Start the isolated copied pathway here: [`lite-pathway/SKILL.md`](lite-pathway/SKILL.md).
- If an orchestrator is appointed: [`lite-pathway/LITE_ORCHESTRATOR_MODE.md`](lite-pathway/LITE_ORCHESTRATOR_MODE.md).
- To upgrade the same audit to Full without repeating valid Lite work: [`lite-pathway/LITE_TO_FULL_UPGRADE.md`](lite-pathway/LITE_TO_FULL_UPGRADE.md).

Without explicit Lite selection, ignore this entire optional directory and follow the standard pathway unchanged.
