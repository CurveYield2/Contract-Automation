# Lite-to-Full No-Repeat Upgrade

## Trigger and authority

Activate only when the human explicitly orders a Full upgrade of a Lite audit, including `upgrade this lite audit to full mode` or `run the full extensive testing`.

The standard pathway outside this isolated Lite directory becomes the execution authority for Full Phases 6–10. Preserve the Lite campaign as immutable provenance; do not restart Phases 0–5.

## Evidence adoption before new work

Create the campaign-local [`LITE_TO_FULL_DELTA_RECONCILIATION.md`](LITE_TO_FULL_DELTA_RECONCILIATION.md) from the supplied template and bind:

- exact Lite campaign/source/build/deployment identity;
- every Lite artifact proposed for reuse with immutable reference/digest;
- the Full-path campaign generation/rework authorization;
- `REUSED_UNCHANGED`, `REQUIRES_REBIND`, `INVALIDATED_REPLACE`, or `SUPERSEDED` disposition for each Lite artifact;
- the exact Full requirement already satisfied by reused evidence, when any;
- every omitted Full process that remains to execute.

Exact matching source/build/deployment evidence is reused. Never rerun accepted Lite targeted tests or deployment/configuration simulations merely for convenience. A material source, dependency, configuration, toolchain, fork, or deployment-identity change follows the standard Evidence Invalidation Matrix.

## Upgrade route

1. Enter the standard Full Phase 6 with fresh reviewers 3A, 3B, and 3C at `gpt-5.6-sol`, `xhigh`.
2. Execute every comprehensive Phase-6 requirement omitted by Lite mode and every unresolved gap. Reused Lite tests remain accepted inputs when exact and sufficient.
3. Continue into standard Full Phase 7 with `gpt-5.6-sol`, `xhigh`. Reuse exact Lite deployment/configuration evidence and execute only uncovered Full lifecycle requirements.
4. Update the delta reconciliation with new evidence, superseded evidence, new candidates, changed dispositions, and invalidation state.
5. If Full Phase 6–7 creates no new security candidate, changes no prior candidate disposition, and invalidates no evidence supporting sealed Lite Phase 8–9 conclusions, do not re-execute Phases 8 or 9.
6. If a new candidate or materially changed candidate evidence exists, reopen standard Phase 8. If Phase 8 validates a new security finding, reopen standard Phase 9 and record its remediation state even when no fix is supplied.
7. Always reopen standard Phase 10 and issue a Full-assurance final report distinguishing reused Lite work from newly executed Full work.

The Full final report must not imply that reused Lite evidence was independently re-executed.
