# Audit V7 Lite Pathway — User Guide

Activate only by saying `use lite mode`. Then start at `SKILL.md` inside this isolated copied pathway.

## Actor route

1. `web-bootstrap-agent` — ordinary ChatGPT web-chat agent with GitHub connector — Phase 0 mechanical/bootstrap work only.
2. `reviewer-1` — Terra/high — Phase 1 semantic scope/dependency/standards analysis and risk grade.
3. `reviewer-2` — Sol/high — combined Phases 2–5.
4. `reviewer-3L` — Sol/high — merged Lite Phases 6–7.
5. `reviewer-4` — Sol/high — combined Phases 8–10.

Fresh-agent handoffs occur after Phase 0, Phase 1, Phase 5 and merged Phase 6–7. The web-bootstrap agent must trigger/supervise all required existing bootstrap automation and may retire only after Phase-0 controller completion validation and `P0_TO_P1` validation both pass.

Phase 0 generates the accepted Source Intelligence system and reusable neutral structural indexes. Later reviewers consume these artifacts and perform higher-intelligence semantic/security work rather than repeating mechanical reconnaissance.

Merged Lite Phase 6–7 performs exact build admission, complete deploy/configuration simulation, candidate-specific deterministic simulation and basic targeted fuzzing. It does not execute the copied Full broad/random/stateful/chaos/Medusa/mutation/differential/corpus/known-attack/coverage-closure campaigns.

Phase 9 runs only if remediation artifacts exist. Phase 10 issues a concise Lite evidence index/report and discloses omitted Full work.

To add Full extensive testing later without repeating valid Lite work, use `LITE_TO_FULL_UPGRADE.md`.
