# External Dependency Ledger

For every reviewed component, record: Dependency identity, address, authority, interface, upgrade path, assumptions, failure propagation, and evidence.

Each entry includes exact source locations, assumptions, observed behavior, attack or failure cases, evidence references, and reviewer decision.
