# Process Integrity Ledger v2

Record campaign creation, gate definitions, worker registration, claims, expiry, submissions, reviews, technical requests, artifact acceptance, findings, remediation, and finalization. Each row includes command ID, actor, timestamp, prior state, next state, evidence references, exact source, and decision reason.

Also record acceptance identities for the security-surface reconciliation, risk-weighted Agent 7 source-first review, every triggered targeted simulation, and the conditional live-deployment attestation when required.
