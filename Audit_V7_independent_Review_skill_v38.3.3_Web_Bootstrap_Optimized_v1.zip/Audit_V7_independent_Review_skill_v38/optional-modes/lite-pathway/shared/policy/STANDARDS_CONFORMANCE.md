# Standards Conformance

For every reviewed component, record: Claimed standard, required behavior, observed behavior, evidence, deviation, and integration impact.

Each entry includes exact source locations, assumptions, observed behavior, attack or failure cases, evidence references, and reviewer decision.
