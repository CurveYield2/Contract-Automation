# Lite Assurance Precision Controls

These controls preserve precision inside the retained Lite scope without importing excluded Full campaigns.

## Security-surface reconciliation

Phase 0 web-bootstrap records every structurally identifiable externally reachable surface in the immutable Source Intelligence core; later reviewers determine semantic security significance. Phase 4 must cover every in-scope contract and material reachable function against that inventory. A material `UNREVIEWED` surface blocks the combined Phase-2–5 seal; do not substitute synthetic coverage percentages.

## Candidate validation priority

Phase 8 validates every material candidate and prioritizes direct custody/principal loss, insolvency, unbounded mint, authority capture, permanent lock, upgrade takeover, oracle-critical control and equivalent high-consequence paths. It may consume prior evidence, but must inspect the exact source and independently decide reachability, impact and disposition.

## Targeted deterministic evidence

When existence or severity depends on ordering, timing, state sequence, quantitative behavior, cross-user value movement or disputed runtime behavior, require the smallest deterministic scenario that resolves the claim. Reuse exact accepted merged Phase 6–7 evidence when it proves the same claim; otherwise create only the missing candidate-specific evidence.

## Live deployment/configuration identity

When the release is live or mixed, bind in-scope addresses, runtime/proxy/implementation identity and security-critical configuration at an immutable block/state reference. The complete deploy/configuration simulation does not substitute for live identity, and live identity does not substitute for source review.

## Placement

- Phase 0 web-bootstrap creates the structural inventory and initial overlays.
- Phase 4 closes manual coverage against that inventory.
- Merged Lite Phase 6–7 accepts retained build/deploy/configuration and candidate-specific execution evidence.
- Phase 8 validates candidate conclusions.
- Phase 9 verifies remediation only when artifacts exist.
- Phase 10 binds final identities, evidence, omissions and limitations in the concise Lite report.

A missing retained precision artifact is a process obligation, not a security finding. Repair it or disclose the exact irrecoverable limitation.
