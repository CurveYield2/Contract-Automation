# Lite Operations and Recovery Lens

**Executor:** whichever of `reviewer-1`, `reviewer-2`, `reviewer-3L`, or `reviewer-4` is controller-authorized.

On controller, GitHub connector, build, runner, simulation, targeted-fuzz, evidence serialization or handoff failure: preserve the failed attempt, diagnose, perform the narrow repair/retry/rebind route, and continue unaffected work. Do not ask the human for facts recoverable from the skill, campaign or connected repositories.

Recovery must not silently import excluded Full campaigns into Lite mode. A required retained process becomes blocked only after its prescribed recovery paths are exhausted and evidence is filed.
