# Lite Build and Simulation Evidence Lens

**Executors:** `reviewer-1` for Phase-1 build admission, `reviewer-3L` for merged Lite Phase 6–7, and `reviewer-4` only for candidate/remediation validation that requires execution.

Bind every command/job/run/artifact/result to exact source, dependency, toolchain, configuration and environment identities. Distinguish build success, deploy/config success and security evidence; none substitutes for another.

Merged Lite Phase 6–7 uses this lens only for exact build admission, complete deploy/configuration simulation, candidate-specific deterministic simulation and basic targeted fuzzing.
