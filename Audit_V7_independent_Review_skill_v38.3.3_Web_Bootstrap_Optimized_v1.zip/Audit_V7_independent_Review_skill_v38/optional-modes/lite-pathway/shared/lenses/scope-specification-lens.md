# Scope Specification Lens v1

**Executor:** `reviewer-1` for Phase-1 scope and bounded risk grading; fresh `reviewer-2` for Phase-2 specification. **Active:** Phases 1–2.

This lens preserves the corresponding Deep Assurance V6.1 role objective without claiming a separate reviewer identity. Use the current phase instruction, applicable domain ledgers, exact evidence bindings, and `shared/lenses/SOLO_LENS_ISOLATION_PROTOCOL.md`.

The lens may produce candidates, challenges, reconciliations, or evidence validation, but it cannot bypass the current phase, automatic advancement/completeness gate, source identity, findings-validation pipeline, or final evidence convergence.
