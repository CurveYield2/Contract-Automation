# Solo Lens Isolation Protocol v1

## Assurance truth

`PROCEDURAL_INDEPENDENCE_ONLY`. One agent cannot supply true separate-reviewer epistemic independence. V7 preserves the purpose of V6.1 clean-room/independent review through controlled inputs, source-first retracing, sealed notes, delayed reconciliation, and transparent limitation reporting.

## First-pass analytical lenses

For Phases 2–5, enter the named lens with the exact source, admitted specification/context, applicable domain ledgers, and neutral machine evidence. Produce the lens evidence from source rather than copying conclusions from another phase report.

## Phase-5 procedural-independent retrace

1. Freeze a risk-priority set mechanically from scope/risk data without importing prior conclusion prose.
2. Use source + specification + neutral tool facts as the retrace context.
3. Re-derive privileged flows, value flows, key invariants, external calls, state transitions, and highest-risk attack paths source-first.
4. Seal retrace notes and candidate issues.
5. Only after sealing, reconcile against prior phase outputs: confirmations, contradictions, omissions, duplicates, and newly discovered surfaces.
6. Record the independence limitation in the Phase-5 and final reports.

## Contamination response

If prior conclusions are intentionally consulted before a required sealed retrace, mark the retrace `CONTAMINATED`, restart it from the allowed context packet when feasible, and record the event. Never silently claim independence.
