# Lite Audit Controller and GitHub Protocol

All repository operations use the connected GitHub connector app under the universal rules. Bind the exact active campaign pointer and `workspacePath`; never invent or normalize a campaign path.

Lite execution begins with non-semantic `web-bootstrap-agent` for Phase 0, followed by the semantic reviewer lineage `reviewer-1` → `reviewer-2` → `reviewer-3L` → `reviewer-4`. Mandatory fresh-agent handoffs are `P0_TO_P1`, `P1_TO_P2`, `P5_TO_P6`, and `P67_TO_P8`.

Controller state must preserve exact campaign/source/build identities, the accepted Source Intelligence bundle identity, current milestone/segment, authorized reviewer, checkpoint digests, due obligations, handoff identities and Lite activation evidence.

If the connector fails, follow the homepage Recovery Router. Never substitute direct GitHub URLs, browser access or generic web retrieval for repository operations.
