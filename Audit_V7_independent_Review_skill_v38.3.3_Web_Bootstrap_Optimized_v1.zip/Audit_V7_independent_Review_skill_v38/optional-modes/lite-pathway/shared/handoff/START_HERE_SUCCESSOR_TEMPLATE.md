# Lite Successor Start Packet

- Boundary: `<P0_TO_P1 | P1_TO_P2 | P5_TO_P6 | P67_TO_P8>`
- Campaign/generation:
- Campaign link:
- Controller `workspacePath`:
- Incoming reviewer/model/reasoning:
- Source identity:
- Build identity:
- Authoritative handoff reference/digest:
- Milestone/completion report reference/digest:
- Global checkpoint references/digests:
- Obligations due now:
- Open limitations/blockers:

## Orchestrated local inputs

- Exact skill ZIP filename/local path/SHA-256:
- Exact source ZIP filename/local path/SHA-256:

Read this routing packet first, then verify the authoritative handoff and create the receipt. Do not redo sealed predecessor work.
