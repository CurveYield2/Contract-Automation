# Lite Successor Wake-Up Message

You are `<incoming reviewer>` for boundary `<P0_TO_P1 | P1_TO_P2 | P5_TO_P6 | P67_TO_P8>`.

Locally available inputs:

- skill ZIP: `<filename>` at `<local path>`; SHA-256 `<digest when available>`;
- source ZIP: `<filename>` at `<local path>`; SHA-256 `<digest when available>`;
- campaign: `<link>`;
- controller workspace: `<workspacePath>`;
- campaign/generation: `<ids>`;
- source identity: `<exact identity>`.

Read the supplied skill, then the campaign-local `START_HERE_SUCCESSOR.md`. Verify `SUCCESSOR_HANDOFF.json`, create `SUCCESSOR_HANDOFF_RECEIPT.json`, and execute only your authorized Lite milestone. Consume sealed evidence; do not restart prior work for convenience.
