# Lite Source Intelligence Reuse Protocol

## Purpose

Phase 0 web-bootstrap creates and seals the canonical Source Intelligence system: immutable structural core, revisioned runtime/deployment overlay, revisioned assurance-readiness overlay, and Bundle Index. Mutable campaign files may be navigation targets, but accepted revisions and digests are the evidence identities.

## Lite ownership and verification

1. `web-bootstrap-agent` generates and accepts the exact-template Source Intelligence core and initial overlays in Phase 0 using neutral structural facts only.
2. `reviewer-2` verifies the accepted Bundle Index and component identities once on entry to combined Phases 2–5.
3. Phases 3–10 reuse that accepted verification. They do not repeat bundle verification or reconstruct sealed structural inventories merely because a new internal segment begins.
4. A material source, dependency, build, configuration, toolchain, fork or deployment-identity change requires classification under the Evidence Invalidation Matrix. Reverify or regenerate only the affected component and downstream evidence.

## Maximum-coverage use

Source Intelligence is a coverage baseline and pointer system, not a substitute for semantic review. Later phases use its contract/function/call/value-flow/privilege/dependency/deployment references to ensure coverage while recording newly learned semantic facts in the appropriate live graph, ledger or overlay.

## Mutable files

The Bundle Index may point to mutable campaign-local working files. Every evidentiary reference must also pin the accepted revision/commit/digest. A path without accepted identity is navigational only.

## No-repeat rule

Do not rebuild structural inventories, rehash unchanged bundle components, or reopen Phase 0 for convenience. If a later phase finds an actual gap or identity change, file the exact delta, update/invalidate affected evidence, and continue without replaying unaffected work.
