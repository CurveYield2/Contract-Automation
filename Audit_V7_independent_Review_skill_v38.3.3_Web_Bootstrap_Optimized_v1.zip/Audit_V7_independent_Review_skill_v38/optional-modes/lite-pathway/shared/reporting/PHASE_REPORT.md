# Lite Milestone Report

Use this report only at the four Lite milestones: Phase 0–1, combined Phase 2–5, merged Phase 6–7, and combined Phase 8–10. Do not file duplicate reports for internal segments.

## Identity

- Campaign ID/generation:
- Milestone:
- Reviewer/model/reasoning:
- Source/repository/commit/digest:
- Build/dependency/toolchain identity:
- Accepted Source Intelligence bundle identity:
- Incoming handoff receipt, if any:

## Milestone result

- Status/verdict:
- Required retained work completed:
- Exact limitations/blockers:
- Full-only work omitted under Lite authority, if applicable:

## Canonical outputs created

| Artifact | Immutable reference/digest | Source/build identity | Acceptance status |
|---|---|---|---|

## New canonical audit facts

| Fact ID | Claim | Evidence | Confidence/disposition |
|---|---|---|---|

## Candidates/findings

| ID | Status | Severity if validated | Decisive evidence | Next obligation |
|---|---|---|---|---|

## Global controls

- Security Traceability Graph reference/digest:
- Carried-Forward Obligation Ledger reference/digest:
- Evidence Invalidation Matrix reconciliation:
- Domain Applicability Registry reference/digest:

## Carried-forward obligations

| Obligation ID | Due milestone/phase | Required reviewer | Acceptance condition | Evidence/state |
|---|---|---|---|---|

## Evidence invalidation triggers

List any source, build, dependency, configuration, toolchain, fork, deployment or remediation identity change that would invalidate or require rebind of this milestone's evidence.

## Transition

- Next state:
- Handoff profile/reference/digest, if applicable:
- Phase-9 condition (`REMEDIATION_ARTIFACTS_EXIST` or `SKIPPED_NO_REMEDIATION`), if applicable:
- Automatic transition timestamp:
