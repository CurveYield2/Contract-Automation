# Finding Template v2

## Identity

- Finding ID:
- Exact source commit:
- Affected paths and symbols:
- Severity: critical, high, medium, low, or informational
- Maximum credible impact: quantified amount/range and evidence-backed bound
- Economic materiality / bound: quantified absolute and relative exposure, principal impact, accumulation/scalability, and cross-user allocation rationale
- Status: unresolved, resolved, risk accepted, or not an issue

## Analysis

- Title:
- Requirement or invariant:
- Preconditions:
- Attack or failure sequence:
- Impact:
- Likelihood and constraints:
- Evidence references:
- Recommended root-cause remediation:
- Regression evidence required:
