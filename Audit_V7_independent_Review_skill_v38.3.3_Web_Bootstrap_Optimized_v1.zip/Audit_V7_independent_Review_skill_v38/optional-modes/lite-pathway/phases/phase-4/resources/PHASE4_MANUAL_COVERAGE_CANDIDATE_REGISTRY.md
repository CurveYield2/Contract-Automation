# Phase 4 Manual Coverage & Candidate Registry

## Manual review coverage
| Coverage ID | Contract / function / sensitive flow / integration | Review type | Related `PROP-*` / `HYP-*` | Reviewed? | Evidence / notes reference | Residual gap |
|---|---|---|---|---|---|---|
| | | | | | | |

## Privilege and integration coverage
| Surface | Authority/dependency | Paths reviewed | Result | Candidate IDs / obligations |
|---|---|---|---|---|
| | | | | |

## Candidate / execution-target registry
| Candidate ID | Suspicious behavior / potential defect | Affected surface | Related property/hypothesis | Current evidence | Validation needed | Explicit Phase-6/7 test target | Status |
|---|---|---|---|---|---|---|---|
| CAND- | | | | | | | |

## Reconciliation
- Unreviewed material surfaces:
- Assumptions requiring execution:
- Carried-forward obligations:
- Evidence invalidation triggers:

## Campaign-global synchronization
Before phase sealing, mirror every material stable ID/relationship created or changed by this artifact into the campaign-local `SECURITY_TRACEABILITY_GRAPH`, and mirror every deferred/later-phase-required action into the canonical `CARRIED_FORWARD_OBLIGATION_LEDGER` with a stable `OBL-*` ID. Record the current immutable graph/ledger references and digests in the Phase Report. Narrative reminders do not replace these global artifacts.
