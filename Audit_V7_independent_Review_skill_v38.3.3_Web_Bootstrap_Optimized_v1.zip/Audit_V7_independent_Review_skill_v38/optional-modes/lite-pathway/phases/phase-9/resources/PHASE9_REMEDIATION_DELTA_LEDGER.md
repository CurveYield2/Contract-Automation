# Phase 9 Remediation Delta Ledger

Create one row per validated finding and one row for any remediation artifact that changes audited behavior. If no remediation exists, file the explicit no-remediation record.

| Finding ID | Old identity | Remediation identity | Changed files/symbols | Root-cause fix | Stale evidence invalidated | Decisive proof rerun | Directly affected surfaces reviewed | New evidence identities | Residual risk | Final disposition |
|---|---|---|---|---|---|---|---|---|---|---|---|
| | | | | | | | | | | | |

## No-remediation path
- `SKIPPED_NO_REMEDIATION`: `YES | NO`
- Evidence-bound reason:
- Findings still open and their dispositions:

## Release-delta reconciliation
- Unrelated changes detected:
- Source-bound evidence requiring broader invalidation/re-execution:
- New candidate issues introduced by remediation:
- Carried-forward obligations:
- Evidence invalidation triggers:

## Campaign-global synchronization
Maintain the graph, obligation ledger and invalidation state live. Seal their final checkpoint only in Phase 10. Do not broaden remediation verification into unrelated regression campaigns.
