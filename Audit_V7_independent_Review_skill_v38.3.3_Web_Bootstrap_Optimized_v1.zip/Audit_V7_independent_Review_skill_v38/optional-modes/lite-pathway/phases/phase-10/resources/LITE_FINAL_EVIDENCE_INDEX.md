# Lite Final Evidence Index

> **PREFILL:** Populate exact machine-known identities, references/digests, candidate/finding IDs, obligation statuses, remediation state and omitted-work rows directly from canonical controller/evidence state when available. The reviewer verifies these fields and authors only missing security conclusions/limitations.

## Exact identities

- Campaign/generation:
- Lite skill ZIP identity/digest:
- Source ZIP/repository/commit/digest:
- Dependency lock/toolchain/build artifact identity:
- Deployment/configuration simulation identity:
- Remediation identity or `SKIPPED_NO_REMEDIATION`:

## Milestone evidence

| Milestone | Required evidence | Exact reference/digest | Source identity | Status | Limitation |
|---|---|---|---|---|---|
| Phase 0–1 | admission, source fence, risk grade, Source Intelligence | | | | |
| Combined Phase 2–5 | specification, threats/domains, manual review, economic/math, reconciliation | | | | |
| Merged Lite Phase 6–7 | build, deploy/config, deterministic candidate simulation, targeted fuzz | | | | |
| Combined Phase 8–10 | validation, remediation/skip, final reconciliation | | | | |

## Findings and obligations

| ID | Final disposition | Severity/status | Decisive evidence | Remediation status | Residual limitation |
|---|---|---|---|---|---|

## Full-only omitted work

List each omission from the merged Phase 6–7 evidence and its no-repeat upgrade target. Omission is never evidence of safety.
