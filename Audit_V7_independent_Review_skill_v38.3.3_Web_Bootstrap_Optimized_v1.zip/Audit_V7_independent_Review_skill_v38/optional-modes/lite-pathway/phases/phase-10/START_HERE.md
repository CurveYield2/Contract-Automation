# Lite Combined Phases 8–10 — Segment 3: Concise Finalization

> The same `reviewer-4` closes the Lite audit. Produce a concise evidence index and final report; do not recreate the Full assurance-case bureaucracy removed from this isolated path.

> Open [`PHASE_CONTRACT.json`](PHASE_CONTRACT.json) first.

## Mechanical prefill rule

Populate exact identities, milestone references/digests, candidate/finding IDs, obligation statuses, remediation status and Full-only omission rows mechanically from canonical controller/evidence state wherever available. `reviewer-4` verifies the populated facts and authors only the security narrative, limitations, finding conclusions and final Lite verdict. Do not spend reviewer context retyping machine-known identifiers.

## Steps

| Step | Action | Required work | Resource |
|---:|---|---|---|
| 1 | Freeze exact identity and scope | Mechanically prefill exact campaign, source, build, deployment/config and remediation identities from canonical state; reviewer-4 verifies them and confirms Lite authority. | [Evidence index](resources/LITE_FINAL_EVIDENCE_INDEX.md) |
| 2 | Index decisive evidence | Mechanically prefill milestone evidence references/digests and finding/obligation rows from canonical state; reviewer-4 verifies completeness and adds only missing decision-relevant context. | [Evidence index](resources/LITE_FINAL_EVIDENCE_INDEX.md) |
| 3 | Reconcile findings and obligations | Ensure every material candidate/finding and due retained Lite obligation has a final disposition; identify unresolved limitations. | [Traceability graph](../../shared/controller/SECURITY_TRACEABILITY_GRAPH.json) |
| 4 | Disclose Lite omissions and residual risk | List every Full-only execution family not performed and explain that no safety conclusion is drawn from its omission. | [Final report](resources/LITE_FINAL_REPORT.md) |
| 5 | State no-repeat Full upgrade route | Explain that later Full assurance resumes at the standard Full Phase 6/7 delta without redoing valid Lite work. | [Upgrade path](../../LITE_TO_FULL_UPGRADE.md) |
| 6 | Seal one combined Phase 8–10 milestone | Seal the evidence index, final report, graph, obligation ledger and invalidation state; set the Lite final verdict. | [Phase Report](../../shared/reporting/PHASE_REPORT.md) |

The final report must not claim Full assurance, comprehensive dynamic coverage or completion of omitted campaigns.
