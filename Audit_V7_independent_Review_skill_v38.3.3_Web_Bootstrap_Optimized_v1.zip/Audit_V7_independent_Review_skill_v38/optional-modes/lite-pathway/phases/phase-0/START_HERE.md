# Phase 0 — Web Bootstrap, Source Intelligence & Execution Readiness

> **EXECUTOR:** `web-bootstrap-agent` — a ChatGPT web-chat agent with the GitHub connector. This actor performs only neutral/mechanical/repetitive work. It has **no authority** to make security findings, threat judgments, risk/severity decisions, exploitability conclusions, standards-conformance conclusions, dependency trust judgments, or remediation decisions.

> **ONE-SESSION OBJECTIVE:** Complete every safely front-loadable mechanical task and supervise all required existing GitHub/Contract-Automation bootstrap execution to terminal validated evidence in this Phase-0 session. Do not leave routine setup for reviewer-1.

> **CURRENT-PHASE READ BOUNDARY:** Read this card first. Do **not** open another phase folder. Open only the resource linked by the active step below; conditional resources are opened only when their trigger applies.

> **PHASE CONTRACT HARD GATE:** Before executing Step 1, open [`PHASE_CONTRACT.json`](PHASE_CONTRACT.json). It is the machine-readable contract for this phase. The web-bootstrap agent may not retire until the current controller/Phase-Contract completion validation reports `PASS` and the `P0_TO_P1` handoff is valid.

> **UNIVERSAL RULE IDS:** `U-EXEC-001`, `U-GITHUB-001`, `U-STATE-001`, `U-EVIDENCE-001`, `U-REPAIR-001`, `U-HUMAN-001`, `U-DISCLOSURE-001`, `U-SOURCEINTEL-001`, `U-UPDATES-001`, and `U-HUMANCOMMS-001` remain binding.

## Phase card

| Step | Action | What to do | Open only when this step is active |
|---:|---|---|---|
| 1 | **Resolve or create the exact campaign** | Use the GitHub connector only. Bind exact campaign generation, workspace, controller branch, skill/source identities and current Phase-0 authority. | [AUDIT_CONTROLLER_AND_GITHUB_PROTOCOL.md](../../shared/controller/AUDIT_CONTROLLER_AND_GITHUB_PROTOCOL.md) |
| 2 | **Admit, stage and inventory the exact source** | Mechanically preserve repository/commit or archive digest, extraction evidence, full file/contract/script/test inventory and source-fence identity. Do not infer security significance. | [SOLO_AUDIT_STATE.json](../../shared/controller/SOLO_AUDIT_STATE.json) |
| 3 | **Prove GitHub and execution-plane readiness** | Prove live GitHub-connector reads against `CurveYield2/Audit-Controller` and `CurveYield2/Contract-Automation`. Inspect the currently admitted Contract-Automation qualification. If qualification/admission is stale or absent, trigger the **existing** qualification/bridge path, observe it to terminal state, retrieve evidence and repair only by existing recovery routes. | [PHASE0_CAPABILITY_PREFLIGHT.md](resources/PHASE0_CAPABILITY_PREFLIGHT.md) · [GITHUB_ACTIONS_VIA_GITHUB_APP.md](../../shared/execution/GITHUB_ACTIONS_VIA_GITHUB_APP.md) · [INSTRUCTION_READ_PROOF.json](resources/INSTRUCTION_READ_PROOF.json) |
| 4 | **Initiate and supervise all required existing bootstrap automation** | Use only existing Contract-Automation/bridge capabilities. Trigger the exact build/static/SBOM/structural execution required by the accepted source; observe each required run to terminal state, capture request/run/job/artifact identities, retrieve evidence, diagnose mechanically recoverable failures and retry. Starting a workflow is not completion. | [TECHNICAL_EXECUTION_REQUEST_PLAYBOOK.md](../../shared/execution/TECHNICAL_EXECUTION_REQUEST_PLAYBOOK.md) · [EXECUTION_PREFLIGHT_AND_REPAIR_PROTOCOL.md](../../shared/execution/EXECUTION_PREFLIGHT_AND_REPAIR_PROTOCOL.md) |
| 5 | **Admit the exact build/compiler identity** | Establish the exact compiler/build/toolchain identity and accepted compiler artifacts for the frozen source using the returned execution evidence. | [supply-chain-build.md](../../../../shared/domain-modules/supply-chain-build.md) |
| 6 | **Generate and seal the canonical Source Intelligence core** | Fill the exact supplied template from the admitted source/build. Populate structural source/build facts, ABI/callable surfaces, storage/inheritance/interface facts, external-call topology, raw privilege/access candidates, structural protocol topology and preliminary compiler gas estimates. No semantic security conclusions. | [SOURCE_INTELLIGENCE_TEMPLATE.json](../../shared/source-intelligence/SOURCE_INTELLIGENCE_TEMPLATE.json) · [SOURCE_INTELLIGENCE_SCHEMA.json](../../shared/source-intelligence/SOURCE_INTELLIGENCE_SCHEMA.json) · [SOURCE_INTELLIGENCE_REUSE_PROTOCOL.md](../../shared/source-intelligence/SOURCE_INTELLIGENCE_REUSE_PROTOCOL.md) |
| 7 | **Attach neutral static reconnaissance and SBOM** | Attach exact neutral Slither/static/SBOM/tool evidence and candidate indexes to Source Intelligence. Analyzer output is machine evidence/candidate input, never a finding. | [supply-chain-build.md](../../../../shared/domain-modules/supply-chain-build.md) · [SOURCE_INTELLIGENCE_REUSE_PROTOCOL.md](../../shared/source-intelligence/SOURCE_INTELLIGENCE_REUSE_PROTOCOL.md) |
| 8 | **Initialize overlays and pin the accepted Source Intelligence Bundle** | Initialize runtime/deployment and assurance-readiness overlays with discovery/readiness facts only; commit accepted revisions and the Bundle Index with exact revision/commit/digest/status/invalidation/preserved-snapshot identities. Do not accept Phase-6 adequacy or Phase-7 runtime/gas conclusions. | [Runtime overlay](../../shared/source-intelligence/RUNTIME_DEPLOYMENT_OVERLAY_TEMPLATE.json) · [Readiness overlay](../../shared/source-intelligence/ASSURANCE_READINESS_OVERLAY_TEMPLATE.json) · [Bundle index](../../shared/source-intelligence/SOURCE_INTELLIGENCE_BUNDLE_TEMPLATE.json) |
| 9 | **Front-load neutral specification/dependency/standards inputs** | Mechanically index documented actors/roles, declared intent, interfaces, explicit exclusions, dependency identities/addresses/interfaces/upgrade facts and claimed standards. Do **not** determine protected-asset priority, trust assumptions, failure propagation, standards applicability/conformance, or negative security requirements. | [PHASE0_BOOTSTRAP_AUDIT_SURFACE_MANIFEST.md](resources/PHASE0_BOOTSTRAP_AUDIT_SURFACE_MANIFEST.md) |
| 10 | **Precompute reusable later-phase structural indexes** | Ensure Phase 0 leaves reusable ABI/function/event/error/selector, storage, inheritance/interface, call/create/delegate, raw privilege, deployment-script/config-field, test/script/harness availability and bytecode/runtime-size references wherever the current source/tooling supports them. Reuse Source Intelligence rather than creating parallel inventories. | [SOURCE_INTELLIGENCE_REUSE_PROTOCOL.md](../../shared/source-intelligence/SOURCE_INTELLIGENCE_REUSE_PROTOCOL.md) |
| 11 | **Complete the frozen Bootstrap Audit Surface Manifest** | Reconcile exact source/build/dependency/deployable/neutral-recon/Source-Intelligence identities and the neutral documented-input indexes into the Phase-0 manifest. | [PHASE0_BOOTSTRAP_AUDIT_SURFACE_MANIFEST.md](resources/PHASE0_BOOTSTRAP_AUDIT_SURFACE_MANIFEST.md) |
| 12 | **Reconcile campaign-global mechanical state** | Update the Security Traceability Graph with source/structural roots, reconcile obligations due in Phase 0, create stable later-phase obligations for unresolved required work, and classify every material observed change under the Evidence Invalidation Matrix. Do not create semantic security conclusions. | [SECURITY_TRACEABILITY_GRAPH.json](../../shared/controller/SECURITY_TRACEABILITY_GRAPH.json) · [CARRIED_FORWARD_OBLIGATION_LEDGER.json](../../shared/controller/CARRIED_FORWARD_OBLIGATION_LEDGER.json) · [EVIDENCE_INVALIDATION_MATRIX.json](../../shared/controller/EVIDENCE_INVALIDATION_MATRIX.json) |
| 13 | **File the Web Bootstrap Completion Report** | File the concise completion report with every automation/request/run/artifact identity and every required output/status. This is a retirement-control artifact, not a duplicate milestone report. | [PHASE0_WEB_BOOTSTRAP_COMPLETION_REPORT.md](resources/PHASE0_WEB_BOOTSTRAP_COMPLETION_REPORT.md) |
| 14 | **Obtain controller/Phase-Contract PASS** | Submit/check the Phase-0 completion state through the current existing controller/Phase-Contract validation path. If it does not return `PASS`, remain active, execute the exact repair/missing work and rerun validation. The agent may not self-certify completion. | [AUTOMATIC_PHASE_ADVANCEMENT_PROTOCOL.md](../../shared/controller/AUTOMATIC_PHASE_ADVANCEMENT_PROTOCOL.md) |
| 15 | **Create and validate P0_TO_P1 successor package; retire** | Create `handoffs/P0_TO_P1/SUCCESSOR_HANDOFF.json`, `START_HERE_SUCCESSOR.md`, and `WAKE_UP_MESSAGE.md` for fresh high-reasoning `reviewer-1`. Validate the package, enter `WAITING_FOR_SUCCESSOR_AGENT`, and stop only after both Phase-0 completion validation and handoff validation are `PASS`. | [SUCCESSOR_HANDOFF_PROTOCOL.md](../../shared/handoff/SUCCESSOR_HANDOFF_PROTOCOL.md) · [SUCCESSOR_HANDOFF_BOUNDARY_PROFILES.json](../../shared/handoff/SUCCESSOR_HANDOFF_BOUNDARY_PROFILES.json) |

## Phase-0 semantic prohibition

The web-bootstrap agent may extract and organize neutral facts, but it MUST NOT decide or file authoritative conclusions about:
- protected-asset priority or maximum credible loss;
- trust assumptions or dependency failure significance;
- threat hypotheses or attack feasibility;
- standards applicability/conformance;
- invariant/property correctness;
- candidate validity, finding status or severity;
- remediation adequacy; or
- final security verdict.

Those begin with reviewer-1 in Phase 1 or later authorized reviewers.

## Required work

- Finish all current-infrastructure mechanical preparation in one web-bootstrap session wherever technically possible.
- Trigger **and verify** required existing GitHub/Contract-Automation automation; never leave a merely-started run for reviewer-1.
- Generate the accepted Source Intelligence system in Phase 0 so later reviewers consume rather than reconstruct structural facts.
- Leave exact durable evidence identities for every build/static/automation result.
- File the concise Phase-0 completion report, obtain controller validation `PASS`, seal/validate `P0_TO_P1`, and only then retire.
