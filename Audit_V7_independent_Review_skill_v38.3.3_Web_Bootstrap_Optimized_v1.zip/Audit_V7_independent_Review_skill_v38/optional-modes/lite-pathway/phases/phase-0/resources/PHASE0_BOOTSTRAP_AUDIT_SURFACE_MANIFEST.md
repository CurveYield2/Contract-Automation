# Phase 0 Bootstrap Audit Surface Manifest

## Frozen identity fence
- Campaign / generation:
- Repository + commit or uploaded-source digest:
- Extracted source-tree digest / inventory reference:
- Compiler version/configuration / optimizer / EVM version:
- Dependency / lockfile / vendored-source identities:
- Neutral Slither version/status/evidence:
- Canonical Source Intelligence core reference/version/SHA-256:
- Runtime/deployment overlay accepted revision/commit/SHA-256:
- Assurance-readiness overlay accepted revision/commit/SHA-256:
- Bundle Index reference/revision/commit/SHA-256:
- Source Intelligence Bundle completion status / limitations:
- Phase 1 Security Risk Grade Manifest reference/SHA-256: `PENDING_PHASE_1`

## In-scope source and deployable-contract inventory
| Surface ID | Path / contract | Kind | In scope by source fence? | Explicit documented exclusion | Deployable? | Claimed standards/interfaces | Live deployment/address if already documented | Evidence reference |
|---|---|---|---|---|---|---|---|---|
| | | | | | | | | |

## Documented intent and declared-role index — neutral extraction only
| ID | Document/source location | Declared actor/role/interface/requirement | Exact quoted-or-paraphrased fact | Evidence reference |
|---|---|---|---|---|
| | | | | |

Do not infer protected-asset priority, trust assumptions, prohibited outcomes, exploitability, or security significance in Phase 0. Those are Phase-1+ semantic decisions.

## External, deployment and release structural surfaces
| ID | Dependency / deployment / artifact | Exact identity/address/interface when mechanically available | Structural relationship only | Provenance/evidence |
|---|---|---|---|---|
| | | | | |

## Reusable later-phase structural indexes
- ABI / callable surface index:
- events / errors / selector index:
- storage-layout reference/status:
- inheritance/interface graph reference/status:
- direct external-call/delegate/create relationship reference/status:
- raw privilege/access candidate inventory reference/status:
- deployment-script/configuration-field inventory reference/status:
- tests/scripts/harness availability inventory reference/status:
- bytecode/runtime-size evidence reference/status:

## Canonical Source Intelligence reconciliation
- Exact filled template used: `shared/source-intelligence/SOURCE_INTELLIGENCE_TEMPLATE.json`
- Core generated after exact build admission: `YES | NO`
- Neutral Slither/static recon attached before seal: `YES | NO | TYPED_LIMITATION`
- All required structural families populated or explicitly `NOT_APPLICABLE`/`UNSUPPORTED`: `YES | NO`
- Structural `securitySurfaces` and static protocol topology populated or explicitly typed-limited: `YES | NO`
- Every compiler gas estimate is marked `PRELIMINARY_NOT_PHASE7_ACCEPTED`: `YES | NO | NOT_APPLICABLE`
- Runtime/deployment overlay initialized without Phase-7 acceptance: `YES | NO`
- Assurance-readiness overlay initialized without Phase-6A adequacy acceptance: `YES | NO`
- Bundle Index validates and pins every accepted revision/commit/digest/status/invalidation state/preserved snapshot: `YES | NO`
- `__FILL_REQUIRED__` sentinels remaining: **must be 0**
- Replacement/revision required: `NO | YES` (explain)

## Freeze conclusion
- Explicit documented exclusions and source-fence reasons:
- Source/build discrepancies:
- Structural uncertainties carried forward:
- Evidence invalidation triggers:

## Campaign-global synchronization
Before Phase-0 sealing, mirror every material stable structural ID/relationship created by this artifact into the campaign-local `SECURITY_TRACEABILITY_GRAPH`, and mirror every deferred mechanical/later-phase-required action into the canonical `CARRIED_FORWARD_OBLIGATION_LEDGER` with a stable `OBL-*` ID. Semantic security conclusions are prohibited here.
