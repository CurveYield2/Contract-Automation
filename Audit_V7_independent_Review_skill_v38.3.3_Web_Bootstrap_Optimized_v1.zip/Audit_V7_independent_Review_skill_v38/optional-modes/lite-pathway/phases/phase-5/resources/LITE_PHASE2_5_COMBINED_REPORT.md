# Lite Combined Phase 2–5 Analytical Milestone

## Identity

- Campaign / generation:
- Exact source/build identity:
- Reviewer: `reviewer-2`
- Model/reasoning: `gpt-5.6-sol` / `high`
- Accepted P1_TO_P2 receipt:
- Source Intelligence verification reference/digest and verification time:
- Material identity changes after Phase-2 verification: `NONE | LIST`

## Retained core analysis

| Area | Canonical artifact | Coverage/result | Material limitations |
|---|---|---|---|
| Specification/properties | Phase-2 registry | | |
| Architecture/privilege/threats | Phase-3 registry | | |
| Domain applicability | Domain registry | | |
| Complete manual/specialist review | Phase-4 registry/ledgers | | |
| Economic/accounting/math | Phase-5 evidence | | |
| Contradiction/candidate reconciliation | Phase-5 matrix | | |

## Completeness gates

- Every in-scope contract and material reachable function manually reviewed: `YES | NO`
- Every activated/uncertain material domain reviewed: `YES | NO`
- Every material property/hypothesis/candidate has a retained validation route: `YES | NO`
- Formal verification triggered for a material unresolved candidate: `NO | YES — evidence`
- Explicit material standards claim required exhaustive proof: `NO | YES — evidence`

## Single milestone reconciliation

- Security Traceability Graph reference/digest:
- Domain Applicability Registry reference/digest:
- Carried-Forward Obligation Ledger reference/digest:
- Evidence Invalidation classification:
- Candidates routed to merged Lite Phase 6–7:
- Residual limitations:

## Seal

- Status: `SEALED | BLOCKED`
- Combined report reference/digest:
- P5_TO_P6 handoff reference/digest:
