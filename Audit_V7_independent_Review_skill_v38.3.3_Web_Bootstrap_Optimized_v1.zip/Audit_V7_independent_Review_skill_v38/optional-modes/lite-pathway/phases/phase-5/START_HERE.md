# Lite Combined Phases 2–5 — Segment 4: Economic/Math Review and Combined Seal

> Continue in the same `reviewer-2` session. This segment replaces the separate Phase-5 procedural retrace with a bounded contradiction and candidate-reconciliation pass.

> Open [`PHASE_CONTRACT.json`](PHASE_CONTRACT.json) first.

## Delta-only source reopening

Start from the sealed Phase-4 coverage/candidate registry and accepted Source Intelligence. Reopen raw source only at value-flow, accounting, arithmetic, time/rate, incentive, or contradiction anchors needed for Phase-5 conclusions. Do not restart a broad implementation review that Phase 4 already completed.

## Steps

| Step | Action | Required work | Resource |
|---:|---|---|---|
| 1 | Enter economic/accounting lens | Bind the same exact source and consume Phases 2–4 properties, hypotheses, coverage, candidates, and activated domains. | [Economic lens](../../shared/lenses/economic-accounting-lens.md) |
| 2 | Review economic correctness | Model value flows, incentives, extraction paths, conservation, insolvency, unfair allocation, and adversarial economic states. | [Economic correctness](../../../../shared/domain-modules/economic-correctness.md) |
| 3 | Verify material mathematics | Check units, bounds, ratios, precision, rounding, time/rate behavior, and numerical edge cases. | [Mathematical verification](../../../../shared/domain-modules/mathematical-verification.md) |
| 4 | Execute activated economic specialist methods | Review every activated vault/oracle/lending/AMM/staking economic surface. | Copied domain modules in `../../../../shared/domain-modules/` |
| 5 | Perform bounded contradiction/candidate reconciliation | Compare Phase-5 conclusions against Phase-2 properties, Phase-3 hypotheses, and Phase-4 candidates. Record `CONFIRMED`, `CONTRADICTED`, `NEW`, or `UNRESOLVED`; do not repeat a clean-room source retrace. | [Reconciliation matrix](resources/PHASE5_RETRACE_RECONCILIATION_MATRIX.md) |
| 6 | Seal combined analytical state once | Reconcile the Source Intelligence identity, graph, domain registry, obligation ledger, and invalidation state once for the entire Phase 2–5 milestone. | [Combined report](resources/LITE_PHASE2_5_COMBINED_REPORT.md) |
| 7 | File one combined report | Seal the Phase-2 property, Phase-3 hypothesis, Phase-4 coverage/candidate, Phase-5 economic/math/reconciliation artifacts and file one milestone report. | [Phase Report](../../shared/reporting/PHASE_REPORT.md) |
| 8 | Handoff to reviewer-3L | Create P5_TO_P6 for the one merged Lite Phase 6–7 reviewer, enter `WAITING_FOR_SUCCESSOR_AGENT`, and stop. | [Lite handoff protocol](../../shared/handoff/SUCCESSOR_HANDOFF_PROTOCOL.md) |

The combined seal is forbidden while any in-scope contract lacks manual coverage, any activated material domain lacks review, or any due retained Lite obligation remains open.
