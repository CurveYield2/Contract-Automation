# Lite Combined Phases 2–5 — Segment 1: Specification

> **LITE SEGMENT:** `reviewer-2` executes Phases 2–5 continuously at `gpt-5.6-sol`, `high`. Phases 2–4 do not file separate reports or seal duplicate global checkpoints. One combined milestone seals after Phase 5.

> **PHASE CONTRACT:** Open [`PHASE_CONTRACT.json`](PHASE_CONTRACT.json) first. Apply the universal rules from the Lite homepage.

## Steps

| Step | Action | Required work | Resource |
|---:|---|---|---|
| 1 | Accept P1_TO_P2 | Verify campaign/source identity, Phase-1 risk grade, Phase-0 Bootstrap Audit Surface, and predecessor receipt. | [Handoff checklist](../../shared/handoff/SUCCESSOR_HANDOFF_RECEPTION_CHECKLIST.md) |
| 2 | Verify Source Intelligence once | Verify the accepted Bundle Index/component identities against exact source/build. This verification remains authoritative through Phase 5 unless a material identity change occurs. | [Reuse protocol](../../shared/source-intelligence/SOURCE_INTELLIGENCE_REUSE_PROTOCOL.md) |
| 3 | Enter specification lens | Preserve source-first reasoning and do not import later conclusions. | [Scope/specification lens](../../shared/lenses/scope-specification-lens.md) |
| 4 | Define requirements | Identify actors, assets, units, trust assumptions, valid/invalid transitions, prohibited outcomes, and negative requirements. | [Specification assurance](../../../../shared/domain-modules/specification-assurance.md) |
| 5 | Derive material mathematics | Define dimensions, bounds, conservation relations, precision, rounding, and edge behavior when applicable. | [Mathematical verification](../../../../shared/domain-modules/mathematical-verification.md) |
| 6 | Record properties | Complete stable `PROP-*` records and planned manual/targeted/simulation validation routes. | [Property registry](resources/PHASE2_SECURITY_PROPERTY_REGISTRY.md) |
| 7 | Continue without duplicate seal | Update live graph/obligation state, but do not file a Phase-2 report or rehash unchanged Source Intelligence. Continue directly to [Phase 3](../phase-3/START_HERE.md). | [Combined report](../phase-5/resources/LITE_PHASE2_5_COMBINED_REPORT.md) |

The inherited Phase-1 risk grade remains the starting control. New evidence may promote it; silent reduction is forbidden.
