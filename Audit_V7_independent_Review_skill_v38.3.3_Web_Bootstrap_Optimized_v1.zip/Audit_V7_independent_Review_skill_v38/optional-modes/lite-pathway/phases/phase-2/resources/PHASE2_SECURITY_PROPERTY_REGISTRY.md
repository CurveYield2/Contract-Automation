# Phase 2 Security Property Registry

Every material security requirement/invariant receives a stable `PROP-*` ID. Do not renumber existing IDs later.

| Property ID | Requirement / invariant | Protected asset / objective | Actors | Violation impact | Assumptions | Numerical/time bounds | Source/spec basis | Fuzzable? | Fork-simulatable? | Planned validation phase/method | Status |
|---|---|---|---|---|---|---|---|---|---|---|---|
| PROP- | | | | | | | | | | | |

## Negative requirements / prohibited outcomes
| Property ID | Prohibited outcome | Observable failure condition | Planned evidence route |
|---|---|---|---|
| | | | |

## Registry reconciliation
- Unresolved specification ambiguity:
- Properties promoted/changed and why:
- Carried-forward obligations:
- Evidence invalidation triggers:

## Campaign-global synchronization
Before phase sealing, mirror every material stable ID/relationship created or changed by this artifact into the campaign-local `SECURITY_TRACEABILITY_GRAPH`, and mirror every deferred/later-phase-required action into the canonical `CARRIED_FORWARD_OBLIGATION_LEDGER` with a stable `OBL-*` ID. Record the current immutable graph/ledger references and digests in the Phase Report. Narrative reminders do not replace these global artifacts.
