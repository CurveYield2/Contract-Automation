# Phase 3 Attack Hypothesis Registry

Every material attack path receives a stable `HYP-*` ID and maps to one or more `PROP-*` IDs.

| Hypothesis ID | Attacker / actor | Preconditions | Attack sequence | Targeted property IDs | Dependency / trust boundary | Expected impact | Observable success condition | Planned validation route `MANUAL | PHASE6 | PHASE7 | PHASE8` | Status | Evidence/source basis |
|---|---|---|---|---|---|---|---|---|---|---|
| HYP- | | | | | | | | | | |

## Architecture/authority reconciliation
- Critical trust boundaries:
- Privilege paths requiring later execution:
- Hypotheses intentionally dismissed and evidence-bound reason:
- Carried-forward obligations:
- Evidence invalidation triggers:

## Campaign-global synchronization
Before phase sealing, mirror every material stable ID/relationship created or changed by this artifact into the campaign-local `SECURITY_TRACEABILITY_GRAPH`, and mirror every deferred/later-phase-required action into the canonical `CARRIED_FORWARD_OBLIGATION_LEDGER` with a stable `OBL-*` ID. Record the current immutable graph/ledger references and digests in the Phase Report. Narrative reminders do not replace these global artifacts.
