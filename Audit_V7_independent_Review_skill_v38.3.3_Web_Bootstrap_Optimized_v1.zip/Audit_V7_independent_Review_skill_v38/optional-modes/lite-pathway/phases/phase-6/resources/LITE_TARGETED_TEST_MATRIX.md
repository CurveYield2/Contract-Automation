# Lite Candidate Target Matrix

| Target ID | Candidate / property / hypothesis | Exact setup and actor | Transaction sequence | Expected secure outcome | Exploit/failure oracle | Deterministic simulation | Targeted fuzz variables/bounds | Result | Evidence | Phase-8 obligation |
|---|---|---|---|---|---|---|---|---|---|---|

Rules:

- Include every material candidate and every due retained execution obligation from the combined Phase-2–5 milestone.
- Basic targeted fuzzing varies only candidate-relevant inputs and immediate boundaries.
- A target cannot be closed merely because one happy-path case passed.
- `INCONCLUSIVE` or unresolved `BLOCKED` always carries forward to Phase 8.
