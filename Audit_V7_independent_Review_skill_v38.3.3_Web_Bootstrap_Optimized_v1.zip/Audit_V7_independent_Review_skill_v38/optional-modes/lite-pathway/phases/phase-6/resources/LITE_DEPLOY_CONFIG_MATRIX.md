# Lite Deployment and Configuration Matrix

## Identity

- Campaign/generation:
- Source commit/digest:
- Build/toolchain identity:
- Chain/fork identity:
- Simulation command/run ID:

## Required sequence

| Order | Component/action | Constructor or initializer | Dependencies/addresses | Roles/ownership/governance | Approvals/configuration | Post-state assertion | Evidence | Status |
|---:|---|---|---|---|---|---|---|---|

## Usability checks

| Check ID | Required normal operation | Starting state | Transaction sequence | Expected result | Actual result | Evidence | Status |
|---|---|---|---|---|---|---|---|

## Configuration gaps and limitations

| Gap ID | Missing/uncertain value | Recovery attempted | Security effect | Candidate/obligation | Disposition |
|---|---|---|---|---|---|

Completion requires every material deploy/config action to be present or explicitly blocked with evidence.
