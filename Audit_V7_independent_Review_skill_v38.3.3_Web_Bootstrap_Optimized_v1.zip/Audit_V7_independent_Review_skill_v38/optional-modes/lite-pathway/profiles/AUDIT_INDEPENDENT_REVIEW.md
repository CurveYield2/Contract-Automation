# Lite Independent Review Profile

Exactly one actor is active at a time. Phase 0 is executed by `web-bootstrap-agent` (ChatGPT web chat + GitHub connector) with mechanical authority only. The semantic reviewer lineage is `reviewer-1` for Phase 1, `reviewer-2` for combined Phases 2–5, `reviewer-3L` for merged Lite Phases 6–7, and `reviewer-4` for combined Phases 8–10.

Mandatory fresh-agent boundaries occur after Phase 0, Phase 1, Phase 5 and merged Phase 6–7. Phase 0 may not issue findings/risk/severity/threat/remediation judgments and may retire only after controller completion `PASS` plus valid `P0_TO_P1`.

Candidate validation in Phase 8 remains evidence-based and source-aware. Lite scope intentionally omits the Full Phase-6/7 comprehensive campaign; its absence must be disclosed and must not be described as Full assurance.
