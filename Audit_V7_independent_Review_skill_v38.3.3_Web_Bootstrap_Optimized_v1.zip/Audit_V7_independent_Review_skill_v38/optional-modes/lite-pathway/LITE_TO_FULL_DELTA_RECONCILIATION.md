# Lite-to-Full Delta Reconciliation

## Identity and authority

- Lite campaign/generation:
- Full-upgrade authorization:
- Exact source/build/deployment identity:
- Standard Full pathway release/revision:
- Upgrade controller state/reference:

## Lite evidence adoption

| Lite artifact | Immutable reference/digest | Exact identity bound | Full requirement potentially satisfied | Disposition `REUSED_UNCHANGED | REQUIRES_REBIND | INVALIDATED_REPLACE | SUPERSEDED` | Reason/action |
|---|---|---|---|---|---|

## Full work remaining

| Standard Full Phase 6/7 requirement | Lite evidence, if any | Remaining delta | Assigned Full reviewer | Completion evidence |
|---|---|---|---|---|

Include every Full-only process enumerated in the Lite merged Phase 6–7 evidence.

## New or changed security state

- New candidates:
- Changed candidate dispositions:
- Invalidated Phase-8/9 support:
- Phase 8 reopen required: `YES | NO` and reason:
- Phase 9 reopen required: `YES | NO` and reason:
- Phase 10 reopen: `YES`:

## Final reconciliation

- Reused Lite work:
- Newly executed Full work:
- Superseded evidence:
- Full-path global checkpoint references/digests:
- Full final-report reference:
