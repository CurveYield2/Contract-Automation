# Package Provenance v38.3.3

Audit V7 independent Review v1 was derived from the user-supplied archive `Audit_V6.1_Deep_Assurance_Autonomous_Workflow_v16_14_v13 (1).zip`.

SHA-256 of supplied source archive: `6621fa8cb5ac54462a8d4857e203b9907c6b2e71e2f2436adee7f5e11f40b95e`

The predecessor archive is intentionally **not bundled inside the active V7 runtime skill**. It is maintained externally for provenance/process-loss review. `shared/internal/V6_1_TO_V7_PROCESS_COVERAGE.md` records the original file identities, hashes, and V7 dispositions needed to verify methodology preservation without exposing agents to a second executable audit framework.

The v19 reporting expansion adds mandatory phase-specific structured end-of-phase artifacts and universal durable phase-report fields without weakening or replacing the underlying audit methodology.


## v20 sequential runtime restructuring

The runtime packet now uses `SKILL.md` as the universal homepage and `phases/phase-0/` through `phases/phase-10/` as progressive-disclosure modules. GitHub repository access is explicitly restricted to the connected GitHub connector app. Phase-specific methodology was split from the former monolithic phase-instruction files into step-linked module resources without intentionally reducing substantive audit requirements.

## v21 execution/lineage homepage controls

The runtime adds mandatory non-blocking work updates that can never terminate execution while authorized work remains; a strict do-not-bother-the-human interaction boundary; immediate repair-first handling of required process failures; plain `CONTINUE` human phase responses; and mandatory fresh reviewer handoffs after Phases 5, 6, and 8. These changes alter orchestration and continuity, not the preserved substantive smart-contract audit methodology.


## v22 GitHub connector outage control

The runtime now requires active Phase-0 proof that the GitHub connector can read both required repositories. A connector outage triggers the defined recovery ladder first; if access remains unavailable after troubleshooting is exhausted or proven impossible, the auditor must send a concise human outage report with exact errors/recovery evidence while continuing all unaffected authorized work. Generic web/browser/raw GitHub access remains prohibited as repository-state substitution.


## v23 GitHub Actions agent-operation guide

Added a canonical ChatGPT-web-agent GitHub Actions guide under `shared/execution/GITHUB_ACTIONS_VIA_GITHUB_APP.md`, linked from technical execution preflight/playbook and the phases that directly depend on GitHub Actions. The guide records the event-trigger model used when direct `workflow_dispatch` is unavailable and documents safe creation of new agent-operable workflows.


## v24 phase-contract / traceability / obligation controls
Added machine-readable `PHASE_CONTRACT.json` files for all eleven phases, a campaign-global Security Traceability Graph, and a campaign-global Carried-Forward Obligation Ledger. Phase sealing now requires current graph/ledger checkpoints and reconciliation of all obligations due in the active phase. Fresh-reviewer handoffs carry exact global-state references/digests. No substantive audit-module methodology was removed by this control-layer addition.


## v25 deterministic domain applicability + Phase-6 sub-gates

Added an exact-source-bound deterministic specialist-domain trigger matrix/registry. Phase 3 classifies all ten domains, Phase 4 must execute every TRIGGERED/UNCERTAIN_INCLUDE specialist domain, and Phases 6/7 consume/re-evaluate decisions for fuzz/simulation coverage. Added P6.0–P6.8 internal Phase-6 execution gates mapping every existing Process 1–11 without changing the preserved normative fuzz methodology.


## v26 invalidation / generic handoff / rule-ID / regression / successor-bootstrap controls

Implemented five reliability/maintenance upgrades without changing protected substantive audit methodology: (1) `shared/controller/EVIDENCE_INVALIDATION_MATRIX.json` deterministically classifies production-source, compiler/build, runner/toolchain, harness/model, deployment/config, fork identity, dependency, remediation, security-model, documentation/report-only, controller-routing, and phase-rework changes as `INVALIDATES`, `REQUIRES_REBIND`, `RECONCILE_ONLY`, or `PRESERVES`; invalidation events are represented as `INV-*` traceability state and unresolved replacement/retest work as `OBL-*`. (2) Replaced three duplicated Phase-5/6/8 handoff protocol/schema/checklist/receipt families with one generic successor-handoff engine plus profiles `P5_TO_P6`, `P6_TO_P7`, and `P8_TO_P9`, preserving boundary-specific evidence and seed requirements. (3) Assigned stable `U-*` IDs to universal homepage rules and changed phase cards to reference those IDs rather than duplicate universal GitHub/access behavior. (4) Consolidated versioned pressure scenario files into one `tests/PRESSURE_SCENARIOS.md` corpus with stable IDs; obsolete PDF-layout-only scenarios remain retired because PDF production is no longer part of the runtime audit. (5) Every fresh-reviewer boundary now requires a generated campaign-local `START_HERE_SUCCESSOR.md` routing packet before the successor expands predecessor context.


## v27 Audit-Controller repository rename

Updated the canonical private controller repository identity from `CurveYield2/Solo-Audit-Controller` to `CurveYield2/Audit-Controller` throughout active skill instructions, Phase 0 capability checks, controller/execution protocols, and validators. Renamed the shared controller protocol module to `shared/controller/AUDIT_CONTROLLER_AND_GITHUB_PROTOCOL.md`. Methodological `SOLO_LENS_ISOLATION_PROTOCOL.md` remains unchanged because “solo lens” describes independent-review methodology rather than the repository name.

The v27 cleanup-alignment update also removes the obsolete homepage dependency on the archived `AGENT HANDOFF INSTRUCTIONS LOOK HERE READ ME/` recovery packet. Active handoff discovery now resolves campaign-local successor handoffs from campaign state / Phase Contracts, while repository-level current guidance resolves through `docs/agent-guides/`; `archive/recovery/` is provenance-only.


## v28 canonical Source Intelligence reuse system

Phase 1 now creates a canonical exact-template `SOURCE_INTELLIGENCE_vN.json` immediately after exact build admission and attaches neutral Slither/SBOM/static-recon evidence before Phase 1 seals. The packet ships `shared/source-intelligence/SOURCE_INTELLIGENCE_TEMPLATE.json`, `SOURCE_INTELLIGENCE_SCHEMA.json`, and `SOURCE_INTELLIGENCE_REUSE_PROTOCOL.md`; auditors fill the supplied structure rather than designing a report ad hoc. Phases 2–10 must load and review relevant sections of the latest accepted source/build-bound artifact and are forbidden from recreating already-sealed structural inventories merely for orientation. Manual/source-first semantic review remains mandatory where the phase methodology requires it. Remediation source/build changes invalidate the affected Source Intelligence baseline and require a new version before structural reuse. Phase reports and fresh-reviewer handoffs now carry Source Intelligence identities/reuse state.


### v28 successor wake-up delivery

Fresh-reviewer boundaries now also require a campaign-local `WAKE_UP_MESSAGE.md` generated from the exact `shared/handoff/WAKE_UP_MESSAGE_TEMPLATE.md`. The message contains immutable handoff-folder and start-file URLs plus all source/build/Source-Intelligence/current-state/first-action/completion information required to bootstrap a replacement agent without additional human explanation. The retiring agent must reproduce the exact filed message in a standalone fenced `text` copy block after the end-of-phase report.

The Source Intelligence template intentionally records its final artifact digest **outside** the artifact after sealing (Phase Report/controller evidence), avoiding an impossible self-referential digest field.


## v29 automatic advancement + three-agent Phase-6 hardening

Removed the per-phase human approval/`CONTINUE` gate. Phase reports remain mandatory, but validly sealed same-reviewer phases auto-advance; fresh-reviewer boundaries immediately generate successor handoffs/wake-up messages. Phase 10 closes automatically after its terminal completeness/closure manifest. Explicit human stop/rework instructions remain possible but are not progression prerequisites.

Phase 6 is now divided into mandatory fresh subreviewers `reviewer-2A` (design/admission), `reviewer-2B` (primary Medusa adversarial execution), and `reviewer-2C` (independent Foundry/coverage closure). Existing P6.0–P6.8 and Processes 1–11 are preserved exactly in order/semantics and assigned across those subreviewers. Added explicit accounting-assurance, randomized accounting-chaos, known-attack disposition, mutation-sensitivity, and multidimensional coverage-gap artifacts. The skill remains operational before the future six-layer automation and historical exploit KB are deployed: exact manual fallback templates and built-in known-attack taxonomy are normative whenever qualified automation is unavailable. Existing v28 Phase-6 campaigns migrate based on durable P6.* subgate state without repeating completed work.


## v32 quantitative economic severity calibration

Updated the canonical `shared/policy/SEVERITY_CALIBRATION.md` from v1 to v2 with user-directed quantitative economic severity thresholds. Medium materiality now begins at either **0.5% of total deposited funds in the affected contract/system** or **5% of annual strategy yield generated from deposits**. High begins when **5% or more of total deposited funds** can be lost, exploited, stolen, irrecoverably diverted, or stranded/frozen. Critical applies when a reachable event or exploit can cause **total or near-total loss of deposited value**. Severity precedence is explicit: Critical overrides High, High overrides Medium, and Medium overrides Low/Informational. Reviewers must record the production denominator and threshold calculation rather than infer materiality from tiny proof-of-concept fixtures.


## v32 severity/verdict separation controls

Clarified that deployment/release automation defects do not independently create security NO_GO verdicts unless they create validated High/Critical security findings. Clarified PRE_DEPLOYMENT simulations: audited contracts are deployed during fork simulation while only external lifecycle dependencies require pre-existing code/state. Added explicit separation between deployment readiness and security verdict.


## v33 Canonical Source Intelligence Bundle

Expanded Phase-1 Canonical Source Intelligence into an immutable source/build core plus revisioned runtime/deployment and assurance-readiness overlays controlled by a committed Bundle Index. The core now includes Phase-1-owned structural security surfaces, static upgrade/dependency/cross-chain/offchain topology, and preliminary compiler gas. Phase 6A retains exclusive adequacy acceptance; Phase 7 retains exclusive runtime/configuration/gas acceptance; Phase 9 regenerates/rebinds changed source; Phase 10 verifies final component identities. Canonical mutable paths are navigation only: accepted revision, immutable commit, SHA-256, status, invalidation state and preserved snapshot are the evidentiary identity. Added `EIM-014`–`EIM-016`, handoff continuity, controller state, and phase-report fields without reducing later semantic, adversarial, dynamic, remediation or final-assurance coverage.


## v36 isolated detailed Lite pathway

Created `optional-modes/lite-pathway/` from an exact byte-for-byte copy of the then-current standard instruction set before any Lite edits. The standard `phases/`, `shared/`, `profiles/`, `docs/`, `agents/`, and `assets/` pathway content was not modified for this release.

Only the copied Lite pathway was adapted into four sequential worker deployments: Terra/high for Phases 0–1; Sol/high for combined Phases 2–5; Sol/high for merged Lite Phases 6–7; and Sol/high for combined Phases 8–10. An optional Sol/max orchestrator reviews only four milestone packets and must provide each worker local readable copies of the exact supplied skill ZIP and source ZIP plus the current campaign link and controller `workspacePath`.

The copied Lite Phases 2–5 now use one continuous analytical run and one combined report. Merged Lite Phases 6–7 retain exact build admission, complete deploy/configuration simulation, candidate-specific deterministic simulation, and basic targeted fuzzing while expressly removing the copied Full broad/random/stateful/chaos/Medusa/mutation/differential/corpus/known-attack/coverage-closure campaign machinery. One reviewer performs Phase 8 validation, conditional Phase 9 remediation verification, and concise Phase 10 finalization. `LITE_TO_FULL_UPGRADE.md` preserves no-repeat reuse and resumes standard Full Phase 6/7 work as a delta.


## v38.3.2 Lite cold-walk integrity and efficiency optimization

Cold-start walkthrough repaired interrupted path/rename migration damage and preserved canonical progressive-disclosure navigation. Lite-mode execution was compressed without reducing retained security assurance: Phase 0 now seals an internal checkpoint and reports once at P0_1; normal reviewers remain at their required high reasoning levels while the optional orchestrator uses medium reasoning; the extra max adversarial review is conditional; Phase 4 uses one principal multi-lens semantic source traversal; Phase 5 reopens only economic/contradiction deltas; Phase 6 batches only exact-environment-compatible executions with candidate-specific evidence; Phase 8 reuses validated shared premises across candidate families while preserving individual dispositions; and Phase 10 mechanically prefills machine-known evidence/index fields for reviewer verification. Full-path methodology is not reduced by these Lite-specific changes.


## v38.3.3 Lite Phase-0 web-bootstrap specialization

Replaced Lite Phase 0 with a dedicated `web-bootstrap-agent` executed as a ChatGPT web-chat agent using the GitHub connector. Phase 0 now front-loads all safely neutral/mechanical work supported by existing infrastructure: campaign/source admission, existing Contract-Automation qualification and bootstrap-run supervision, exact build admission, neutral static/SBOM evidence, canonical Source Intelligence and overlays, neutral dependency/standards/documented-intent indexing, reusable structural indexes, and global mechanical checkpoints. It may not make security/risk/threat/severity/remediation judgments. Phase 1 is now a fresh high-reasoning `reviewer-1` segment focused on semantic scope/dependency/standards analysis and risk grading. Added `P0_TO_P1`; the web-bootstrap agent may retire only after Phase-0 controller/Phase-Contract completion validation and handoff validation both report PASS. No new repository automation capability is assumed; this revision uses only existing bridge/workflow/execution infrastructure and leaves future repo-automation integration for later skill updates.
