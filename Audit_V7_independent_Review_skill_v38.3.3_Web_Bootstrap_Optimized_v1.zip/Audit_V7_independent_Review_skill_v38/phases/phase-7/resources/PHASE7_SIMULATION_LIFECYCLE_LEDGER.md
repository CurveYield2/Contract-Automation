# Phase 7 Simulation Lifecycle Ledger

Create one `SIM-*` record per lifecycle recipe, deterministic reproduction, integration scenario, repeated-state scenario, or explicitly triggered simulation.

| Simulation ID | Recipe/scenario | Fork chain + block/hash/profile | Target/live addresses | Actors | Initial balances/state/config | Exact action sequence | Expected invariants / `PROP-*` | Observed state changes | Repeated-cycle/time-travel behavior | Final balances/state | Result | Candidate/finding IDs | Evidence refs/digests | Limitation / `RECIPE_GAP` | Untested reachable behavior | Reason | Disposition | Residual risk |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| SIM- | | | | | | | | | | | | | | |

## Scenario coverage reconciliation
- Required recipes/scenarios:
- Executed:
- `NOT_APPLICABLE` with reason:
- `RECIPE_GAP` items:
- Integrations not expressible on the admitted fork path:
- Repeated-state/lifecycle coverage gaps:
- Deployment-gas report reconciliation status:
- Untested reachable behavior reconciliation:
- Untested behavior justification/disposition:
- Residual risk assessment:
- Evidence invalidation triggers:

## Campaign-global synchronization
Before phase sealing, mirror every material stable ID/relationship created or changed by this artifact into the campaign-local `SECURITY_TRACEABILITY_GRAPH`, and mirror every deferred/later-phase-required action into the canonical `CARRIED_FORWARD_OBLIGATION_LEDGER` with a stable `OBL-*` ID. Record the current immutable graph/ledger references and digests in the Phase Report. Narrative reminders do not replace these global artifacts.
