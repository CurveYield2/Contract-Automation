# Phase 1 Security Risk Grade Manifest

## Exact identity
- Campaign / generation:
- Phase / revision:
- Reviewer lineage: `reviewer-1`
- Source repository / commit or source digest:
- Canonical Source Intelligence Bundle Index revision / commit / SHA-256:
- Phase 1 Audit Surface Manifest reference / SHA-256:

## Evidence basis
- Protected assets:
- Privileged actors and authority paths:
- Accounting and value-flow surfaces:
- External dependencies and trust assumptions:
- Upgrade, callback, cross-chain and offchain-control surfaces:
- Maximum credible loss or security impact:

## Security risk grade
- Accepted grade:
- Impact rationale:
- Complexity rationale:
- Coverage depth required by this grade:
- Assumptions and limitations:

## Promotion triggers
| Trigger ID | New evidence or condition | Required higher-grade response | Later phase responsible for detecting/reconciling |
|---|---|---|---|
| | | | |

## Fresh-reviewer inheritance
- Bound P1_TO_P2 handoff reference / digest:
- Fresh `reviewer-2` acceptance status: `PENDING`
- Rule: this grade is the Phase-2 starting control; new evidence may promote it but may not silently reduce it.

## Seal
- Manifest status: `SEALED | BLOCKED`
- Immutable reference / digest:
- Open limitations / OBL-* references:
