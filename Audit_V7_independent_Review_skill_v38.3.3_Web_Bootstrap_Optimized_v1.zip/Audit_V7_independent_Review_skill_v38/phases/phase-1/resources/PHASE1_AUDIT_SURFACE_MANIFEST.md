# Phase 1 Audit Surface Manifest

## Frozen identity fence
- Campaign / generation:
- Repository + commit or uploaded-source digest:
- Extracted source-tree digest / inventory reference:
- Compiler version/configuration / optimizer / EVM version:
- Dependency / lockfile / vendored-source identities:
- Neutral Slither version/status/evidence:
- Canonical Source Intelligence core reference/version/SHA-256:
- Runtime/deployment overlay accepted revision/commit/SHA-256:
- Assurance-readiness overlay accepted revision/commit/SHA-256:
- Bundle Index reference/revision/commit/SHA-256:
- Source Intelligence Bundle completion status / limitations:
- Phase 1 Security Risk Grade Manifest reference/SHA-256:

## In-scope source and deployable-contract inventory
| Surface ID | Path / contract | Kind | In scope? | Exclusion reason if any | Deployable? | Claimed standards/interfaces | Live deployment/address if applicable | Evidence reference |
|---|---|---|---|---|---|---|---|---|
| | | | | | | | | |

## External and release surfaces
| ID | Dependency / deployment / artifact | Exact identity | Audit relevance | Provenance/evidence |
|---|---|---|---|---|
| | | | | |

## Canonical Source Intelligence reconciliation
- Exact filled template used: `shared/source-intelligence/SOURCE_INTELLIGENCE_TEMPLATE.json`
- Core generated after exact build admission: `YES | NO`
- Neutral Slither/static recon attached before seal: `YES | NO | TYPED_LIMITATION`
- All required structural families populated or explicitly `NOT_APPLICABLE`/`UNSUPPORTED`: `YES | NO`
- Structural `securitySurfaces` and static protocol topology populated or explicitly typed-limited: `YES | NO`
- Every compiler gas estimate is marked `PRELIMINARY_NOT_PHASE7_ACCEPTED`: `YES | NO | NOT_APPLICABLE`
- Runtime/deployment overlay initialized without Phase-7 acceptance: `YES | NO`
- Assurance-readiness overlay initialized without Phase-6A adequacy acceptance: `YES | NO`
- Bundle Index validates and pins every accepted revision/commit/digest/status/invalidation state/preserved snapshot: `YES | NO`
- `__FILL_REQUIRED__` sentinels remaining: **must be 0**
- Replacement/revision required: `NO | YES` (explain)

## Freeze conclusion
- Explicit exclusions and reasons:
- Source/build discrepancies:
- Scope uncertainties carried forward:
- Evidence invalidation triggers:

## Campaign-global synchronization
Before phase sealing, mirror every material stable ID/relationship created or changed by this artifact into the campaign-local `SECURITY_TRACEABILITY_GRAPH`, and mirror every deferred/later-phase-required action into the canonical `CARRIED_FORWARD_OBLIGATION_LEDGER` with a stable `OBL-*` ID. Record the current immutable graph/ledger references and digests in the Phase Report. Narrative reminders do not replace these global artifacts.
