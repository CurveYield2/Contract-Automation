# Phase 5 Retrace Reconciliation Matrix

The source-first procedural retrace is sealed before reconciliation. Each material Phase-2–4 conclusion is then classified without rewriting the sealed retrace.

| Reconciliation ID | Prior item ID / conclusion | Retrace observation/evidence | Classification `CONFIRMED | CONTRADICTED | NEW | UNRESOLVED` | Security significance | Follow-up / carried obligation | Evidence references |
|---|---|---|---|---|---|---|
| | | | | | | |

## Economic/accounting additions
| ID | Economic/math/accounting conclusion | Related property/candidate | Evidence | Downstream Phase-6/7 action |
|---|---|---|---|---|
| | | | | |

## Handoff-critical state
- New candidates/hypotheses created:
- Contradictions requiring successor attention:
- Unresolved items to carry into Phase 6:
- Evidence invalidation triggers:

## Campaign-global synchronization
Before phase sealing, mirror every material stable ID/relationship created or changed by this artifact into the campaign-local `SECURITY_TRACEABILITY_GRAPH`, and mirror every deferred/later-phase-required action into the canonical `CARRIED_FORWARD_OBLIGATION_LEDGER` with a stable `OBL-*` ID. Record the current immutable graph/ledger references and digests in the Phase Report. Narrative reminders do not replace these global artifacts.
