# Final Audit Report Content Worksheet v7

This worksheet defines the required content and ordering for the client-facing Markdown final report.

The client-facing document must not identify itself as an `Audit V7` report or expose the internal skill/package version unless the client explicitly requests that information.

## Content sequence

1. Cover
2. Table of Contents
3. Summary
4. Scope
5. Overview / System Overview
6. Security Considerations and Threat Model
7. Audit Methodology & Security Processes
8. Methodology continuation when required
9. Deep Assurance Results
10. Security Claims & Assurance Evidence
11. Finding pages - content-driven repeatable count
12. Notes & Additional Information
13. Recommendations
14. Conclusion

## Finding flow

Present findings in severity order with stable IDs, clear titles, statuses, evidence-bound descriptions, impact, remediation, and verification state. Use continuation headings only when they improve readability.

## Required content

Use the current sealed evidence to populate engagement type, timeline, languages/stack, exact audited source/release identity, scope, architecture, threat model, methodology, quantitative test results, assurance claims, validated findings, dispositions, notes, recommendations, deployment/attestation state and conclusion.

Never copy factual content from the canonical template or worked example unless it is independently true for the current engagement.

## Final report gate

Reconcile every section against the current sealed evidence. Verify exact source/release identity, finding counts and statuses, methodology coverage, assurance-case summary, limitations, completion status, and security verdict. The report must not introduce stale template facts or internal skill-version branding.
