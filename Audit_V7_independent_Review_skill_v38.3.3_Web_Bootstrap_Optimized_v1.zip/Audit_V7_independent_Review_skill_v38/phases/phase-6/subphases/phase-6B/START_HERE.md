# Phase 6B — Primary Medusa Adversarial Execution

> **CURRENT-SUBPHASE READ BOUNDARY:** Read the Phase-6 router first, then this card. You are fresh `reviewer-3B`. Consume 6A design; do not redesign/repeat P6.0 unless invalidated.

## Phase card

| Step | Action | What to do | Open only when active |
|---:|---|---|---|
| 1 | **Receive P6A_TO_P6B** | Verify 6A seal, P6.0 terminal state, exact design/accounting/attack/harness evidence. | [Handoff protocol](../../../../shared/handoff/SUCCESSOR_HANDOFF_PROTOCOL.md) |
| 2 | **P6.1 broad discovery** | Execute Process 1 + Gate A exactly. | [P6.1](../../resources/subgates/P6_1_BROAD_DISCOVERY.md) |
| 3 | **P6.2 properties/invariants including accounting** | Execute Process 2; every applicable accounting invariant has executable/alternate disposition. | [P6.2](../../resources/subgates/P6_2_PROPERTIES_INVARIANTS.md) · [Accounting model](../../resources/PHASE6_ACCOUNTING_ASSURANCE_MODEL.md) |
| 4 | **P6.3 stateful/multi-actor/boundary + accounting-chaos campaigns** | Execute Processes 3/4/7 and the target-bound randomized accounting attack matrix; invariants run through meaningful sequences. | [P6.3](../../resources/subgates/P6_3_SEMI_TARGETED_STATEFUL.md) · [Attack matrix](../../resources/PHASE6_RANDOMIZED_ATTACK_CAMPAIGN_MATRIX.md) |
| 5 | **P6.4 deliberate Medusa refinement/rerun** | Review state/actor/property/accounting/motif gaps; materially refine harness/config/corpus and rerun. | [P6.4](../../resources/subgates/P6_4_COVERAGE_REFINEMENT.md) |
| 6 | **P6.5 targeted hypotheses + known-attack Medusa adaptations** | Execute Process 6 and every applicable known/historical attack suited to Medusa; runtime-only attacks get exact Phase-7 OBL. | [P6.5](../../resources/subgates/P6_5_TARGETED_BOUNDARY.md) · [Known attacks](../../resources/PHASE6_KNOWN_ATTACK_DISPOSITION.md) |
| 7 | **P6.6 triggered advanced campaigns and terminal Medusa evidence** | Evaluate Processes 8–11 independently; execute triggered work, deep campaigns and preserve corpus/counterexamples. | [P6.6](../../resources/subgates/P6_6_TRIGGERED_ADVANCED.md) |
| 8 | **Seal 6B and hand off automatically** | File terminal Medusa subphase report; create P6B_TO_P6C handoff/wake-up immediately. Do not run Foundry. | [Subphase report](../../resources/PHASE6_SUBPHASE_REPORT.md) · [Three-reviewer protocol](../../resources/PHASE6_THREE_REVIEWER_PROTOCOL.md) |
