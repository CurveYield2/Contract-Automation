# Phase 6 Multi-Dimensional Coverage Gap Report — Exact Fill Template

Use `COVERED | PARTIALLY_COVERED | ALTERNATE_EVIDENCE | NOT_APPLICABLE_WITH_EVIDENCE | UNEXPLAINED_GAP | BLOCKING_GAP | LIMITATION_ACCEPTED`.

| Dimension | Expected IDs/surfaces | Evidence exercised | Status | Residual gap / required refinement |
|---|---|---|---|---|
| Contract/function/selector | | | | |
| Property/invariant | | | | |
| Accounting invariant classes | | | | |
| Actor/authority | | | | |
| State transition/lifecycle | | | | |
| Transition-pair/sequence motifs | | | | |
| Threat hypotheses | | | | |
| Known/historical attack patterns | | | | |
| Randomized accounting attack motifs | | | | |
| Boundary/numerical/time | | | | |
| External dependency/integration | | | | |
| Ghost/reference/differential | | | | |
| Mutation/harness sensitivity | | | | |
| Medusa corpus/meaningful state | | | | |
| Foundry independent campaigns | | | | |

## Blocking rule
Any high-risk `UNEXPLAINED_GAP` must be promoted to `BLOCKING_GAP`. Code/line coverage alone can never clear this report.

## Final seal statement
- Blocking gaps remaining: MUST BE 0 for successful Phase-6 seal.
- Accepted limitations / OBL-* IDs:
