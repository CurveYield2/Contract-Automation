# Phase 6 Subphase Report Template

## Identity
- Campaign / generation:
- Phase 6 subphase: `6A | 6B`
- Reviewer: `reviewer-3A | reviewer-3B`
- Exact source/build identity:
- Source Intelligence ref/digest:
- Phase6 reviewer-state ref/digest:
- Phase6 subgate-state ref/digest:

## Subphase result
- Status: `SEALED | SEALED_WITH_LIMITATION | FAILED_BLOCKING`
- Work completed:
- Evidence refs/digests:
- Processes/subgates terminal this subphase:
- Accounting-assurance status:
- Known-attack disposition status:
- Randomized accounting attack status:
- Counterexamples/candidates:
- Coverage/residual gaps:
- Open OBL-* IDs:
- Typed limitations:

## DO NOT REPEAT
List exact sealed work/evidence the successor must consume without rerunning.

## Successor requirements
- Boundary profile:
- Exact first executable action:
- Exact completion condition:

This report is filed for continuity. It does not require human approval. After sealing, immediately create the required successor handoff/wake-up message and enter `WAITING_FOR_SUCCESSOR_AGENT`.
