# Phase 6 Accounting Assurance Model — Exact Fill Template

## Applicability
- Decision: `ACCOUNTING_ASSURANCE_REQUIRED | ACCOUNTING_ASSURANCE_NOT_APPLICABLE | ACCOUNTING_ASSURANCE_LIMITED`
- Evidence/rationale:
- Source Intelligence refs:

## Accounting state inventory

| Stable ID | State / claim / unit | Contract/function/storage refs | External balance dependency | Who can change it | Notes |
|---|---|---|---|---|---|
| | | | | | |

## Required invariant disposition

Use `EXECUTABLE_PROPERTY | INDEPENDENT_MODEL_CHECK | ALTERNATE_EVIDENCE | NOT_APPLICABLE_WITH_EVIDENCE | TYPED_LIMITATION`.

| Invariant class | Disposition | Exact formula/property | Evidence/campaign ID | Limitation |
|---|---|---|---|---|
| CONSERVATION | | | | |
| AGGREGATE_VS_USER_RECONCILIATION | | | | |
| SOLVENCY | | | | |
| NO_UNBACKED_CLAIMS | | | | |
| NO_UNAUTHORIZED_VALUE_EXTRACTION | | | | |
| ROUND_TRIP_BOUNDED_VALUE | | | | |
| SHARE_ASSET_CONSISTENCY | | | | |
| DEBT_PRINCIPAL_INTEREST_CONSISTENCY | | | | |
| REWARD_ACCRUAL_CONSISTENCY | | | | |
| FEE_CONSERVATION_AND_CAP | | | | |
| RESERVE_CONSISTENCY | | | | |
| COLLATERAL_LIABILITY_CONSISTENCY | | | | |
| LIQUIDATION_VALUE_CONSERVATION | | | | |
| MONOTONIC_ENTITLEMENT_WHERE_REQUIRED | | | | |
| ROUNDING_ERROR_BOUNDS | | | | |
| NO_DOUBLE_CLAIM | | | | |
| NO_NEGATIVE_OR_STALE_CLAIM | | | | |
| DIRECT_TRANSFER_DONATION_ACCOUNTING | | | | |
| TIME_ACCRUAL_CONSISTENCY | | | | |
| ROLE_SPECIFIC_ACCOUNTING | | | | |

## Attacker/victim/protocol value accounting
- Principal definition:
- Legitimate yield/reward definition:
- Fee definition:
- Cross-asset valuation basis, if any:
- Unexplained value-delta candidate threshold/rule:
