# Lending Liquidation Ledger

For every reviewed component, record: Collateral, debt, interest, health, liquidation, reserves, bad debt, rounding, and lifecycle reconciliation.

Each entry includes exact source locations, assumptions, observed behavior, attack or failure cases, evidence references, and reviewer decision.
