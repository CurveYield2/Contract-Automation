# Cross Chain Ledger

For every reviewed component, record: Chains, endpoints, trusted senders, nonces, domain separation, message ordering, failure, and recovery.

Each entry includes exact source locations, assumptions, observed behavior, attack or failure cases, evidence references, and reviewer decision.
