# Vault Strategy Ledger

For every reviewed component, record: Assets, shares, strategy balances, fees, harvest, loss, migration, emergency exit, and lifecycle invariants.

Each entry includes exact source locations, assumptions, observed behavior, attack or failure cases, evidence references, and reviewer decision.
