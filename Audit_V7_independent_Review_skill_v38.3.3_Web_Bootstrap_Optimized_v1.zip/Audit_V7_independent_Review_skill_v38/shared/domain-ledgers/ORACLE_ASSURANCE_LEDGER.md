# Oracle Assurance Ledger

For every reviewed component, record: Source, units, decimals, window, freshness, liquidity, manipulation, fallback, and downstream impact.

Each entry includes exact source locations, assumptions, observed behavior, attack or failure cases, evidence references, and reviewer decision.
