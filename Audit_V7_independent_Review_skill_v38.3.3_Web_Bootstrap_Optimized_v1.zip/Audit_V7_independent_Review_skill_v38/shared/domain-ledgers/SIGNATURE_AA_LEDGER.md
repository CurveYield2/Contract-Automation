# Signature Aa Ledger

For every reviewed component, record: Signer, caller, beneficiary, domain, chain, nonce, deadline, payload binding, cancellation, and replay.

Each entry includes exact source locations, assumptions, observed behavior, attack or failure cases, evidence references, and reviewer decision.
