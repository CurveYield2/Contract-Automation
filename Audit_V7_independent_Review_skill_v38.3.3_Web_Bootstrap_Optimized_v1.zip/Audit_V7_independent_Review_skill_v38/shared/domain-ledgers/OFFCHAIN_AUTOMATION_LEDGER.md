# Offchain Automation Ledger

For every reviewed component, record: Automation actor, permission, cadence, idempotency, incentives, failure behavior, recovery, and monitoring.

Each entry includes exact source locations, assumptions, observed behavior, attack or failure cases, evidence references, and reviewer decision.
