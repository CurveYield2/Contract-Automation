# Amm Hook Ledger

For every reviewed component, record: Pools, hooks, routers, callbacks, settlement, balance deltas, fee bounds, and invariants.

Each entry includes exact source locations, assumptions, observed behavior, attack or failure cases, evidence references, and reviewer decision.
