<!--M:specification-assurance:000bce7e4cdb6c7223f143b6d8149f9a7a52cab3d952977cbc181ac9efb43fb2-->
### `specification-assurance`
Trigger: Use when converting project intent, interfaces, invariants, failure behavior, and negative requirements into an auditable specification

## Objective

Produce a complete specification that reviewers can test against implementation and evidence.

## Review Contract

- List actors, assets, units, bounds, state transitions, interfaces, trust assumptions, and prohibited outcomes.
- Separate documented requirements from reviewer-derived requirements.
- Resolve ambiguity before a pass can be claimed.
- Bind every requirement to source locations and evidence expectations.

## Required Output

A specification matrix and negative-requirements set accepted by the scope lane.
