# Procedural Independent Review Lens v1

**Executor:** `reviewer-2` for the Phase-5 retrace; `reviewer-5` for the Phase-10 prepublication challenge. **Active:** Phase 5 retrace and Phase 10 prepublication challenge.

This lens preserves the corresponding Deep Assurance V6.1 role objective without claiming a separate reviewer identity. Use the current phase instruction, applicable domain ledgers, exact evidence bindings, and `shared/lenses/SOLO_LENS_ISOLATION_PROTOCOL.md`.

The lens may produce candidates, challenges, reconciliations, or evidence validation, but it cannot bypass the current phase, automatic advancement/completeness gate, source identity, findings-validation pipeline, or final evidence convergence.
