# Build Simulation Evidence Lens v1

**Executor:** `reviewer-1` in Phase 1; `reviewer-3` in Phase 6; `reviewer-4` in Phases 7–8; `reviewer-5` in Phase 9. **Active:** Phases 1, 6–9.

This lens preserves the corresponding Deep Assurance V6.1 role objective without claiming a separate reviewer identity. Use the current phase instruction, applicable domain ledgers, exact evidence bindings, and `shared/lenses/SOLO_LENS_ISOLATION_PROTOCOL.md`.

The lens may produce candidates, challenges, reconciliations, or evidence validation, but it cannot bypass the current phase, automatic advancement/completeness gate, source identity, findings-validation pipeline, or final evidence convergence.
