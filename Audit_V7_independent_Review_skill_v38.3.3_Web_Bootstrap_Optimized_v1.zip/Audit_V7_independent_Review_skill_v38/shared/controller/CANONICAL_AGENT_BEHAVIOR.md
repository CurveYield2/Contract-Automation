# Canonical Agent Behavior

Agents must preserve evidence chains, verify claims independently, identify uncertainty, and avoid unsupported conclusions.
