# Candidate First Protocol

Potential findings begin as candidates. Confirmation requires evidence, exploitability assessment, impact analysis, and validation before final classification.
