# Incremental Intelligence Rule

Escalate reasoning depth only when complexity, uncertainty, risk, or unresolved findings justify additional analysis.
