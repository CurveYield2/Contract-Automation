# cyavKAT V14 — Management-fee-neutral PPS protection

- Added `upgrade/src/libraries/CurveYieldManagementFeePpsLib.sol`, reading pending IPOR management fees from the actual factory vault and counting their eventual shares as virtual supply.
- Updated `CurveYieldBundleGuardFuse.enter/exit` to compare PPS using fee-adjusted supply before and after an action without changing the permitted economic-loss ceilings or transient API.
- Updated executor PPS snapshots, shortfall/coverage and gain calculations to use the same fee-adjusted supply, so an IPOR management-fee mint does not get treated as a strategy loss.
- Added guard regression tests for actual accrued-fee realization, extra unearned shares, underlying-asset loss, and no-fee changes.
- Kept all existing IPOR factory contracts, custom fee settings, vault migration scripts, mandatory Quest signing, and governance code unchanged.
- NOTE: This is an accounting normalization for **fee realization**, not permission for anyone to lower or redirect fees. The complete on-chain transition still has its separate prerequisites.
