# cyavKAT V13 — management-fee-adjusted zero deposit-loss invariant

After V12 confirmed a same-block **second identical deposit has exactly zero PPS loss**, V13 corrects only the fork test's reference price. The original, inflated before-deposit PPS excluded accrued IPOR management fees. IPOR mints those authorized management-fee shares on the first deposit, which dilutes the PPS even though no assets are lost.

V13 computes **independently before the first deposit** the precise expected management shares via the original vault's `convertToShares(getUnrealizedManagementFee())`, then requires:

- First deposit total share increase = user shares + onboarding withdrawal-manager shares + exact expected IPOR management shares (no hidden dilution).
- Second same-block deposit share increase = user shares + onboarding withdrawal-manager shares, with **zero** management shares.
- Onboarding-fee manager's actual pending shares equal precisely its newly minted shares for each deposit.
- `totalAssets` rises by the complete 500 avKAT on **each** deposit.
- First PPS remains >= precisely calculated fee-adjusted pre-deposit PPS, subject to 2 wei rounding.
- Second PPS remains >= first PPS, and `deployAssets` keeps PPS >= second PPS, same tolerance.

This does not waive any economic loss or change fee rates. No production Solidity sources, deployment scripts, factory contracts, or deployed-stack files are modified.
