# cyavKAT V7 — GitHub Katana test-derived corrections

- V6 compiled successfully in GitHub-hosted Foundry, but 14/88 unit tests reported failures and the fork suite stopped during fixture initialization.
- Fixed the Katana fork fixture so its reserved empty P0 JSON is removed before the unchanged production P0 script (which intentionally rejects overwriting any existing deployment record).
- Updated governance unit tests to assert the complete correct custom errors and their arguments, not just bare selectors. Production governance logic remains unchanged.
- Corrected the burn-only mock test to arm transient storage and call the mock vault's withdrawal within the same transaction. The production fee code remains unchanged pending fork confirmation.
- All original IPOR and deployed stack sources, mandatory Quest V2, and governance handover implementations are unchanged.
- This update is not proof of conformance; run the supplied tests on Katana Anvil before deploying.
