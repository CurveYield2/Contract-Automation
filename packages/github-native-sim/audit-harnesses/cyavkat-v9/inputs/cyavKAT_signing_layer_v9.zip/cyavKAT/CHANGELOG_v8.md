# cyavKAT V8 — GitHub Katana conformance tests: final fixture repair

- Production contracts and original IPOR sources remain byte-for-byte unchanged.
- V7 compiled and passed 84/88 unit tests, with four further mismatched bare-selector-only expectations. V8 asserts the full exact revert data.
- V7 fork migration correctly halted when the OLD, LIVE withdrawal manager was still holding existing fee shares. V8's test-only fork first asserts this guard REVERTS, then impersonates old WM on the ephemeral fork to transfer those shares to the fee-receiving Safe, preserving supply. This explicitly models a completed fee settlement without weakening the real P2_03 production guard.
- Real cutover is prohibited until pending requests and fee balances are properly settled on-chain; the fork-only accommodation is NOT deployment readiness evidence.
- Mandatory Quest V2 signing is retained.
