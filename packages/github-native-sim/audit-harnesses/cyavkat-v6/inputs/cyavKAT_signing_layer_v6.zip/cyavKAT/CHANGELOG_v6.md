# cyavKAT v6 — IPOR fuse conformance implementation

Based **only** on v5: Safe retains IPOR OWNER role 1, original IPOR Access Manager remains the role source, ADMIN_FEE is self-administered by the Safe initially, and mandatory Quest signing v2 stays intact. No change was made to original IPOR source, live deployed-source copies, the governance gate or live Quest signing contracts.

## Executable changes

1. **M3 claimability gate:** `upgrade/scripts/merkl_preflight_v6.py` checks the Merkl v4 API for the live cyavKAT vault and its IPOR RewardsClaimManager, using `amount - claimed` as claimable and treating pending separately. It fails closed on wrong chain/response/error, emits a confirmed-block hash receipt only if claimable totals are zero. `P2_04_RemoveV1Fuses` requires that receipt, checks the chain, addresses, values, canonical block hash and ≤200-block freshness before detaching the rewards fuses; it also checks the vault holds no direct Sushi V3 LP NFTs. No Sushi swap router or Charm vault is removed.
2. **R1/R2/R3:** `CurveYieldBundleGuardFuse` gains transient enter/exit with validated layouts; `CurveYieldRequestFeeSharesFuse` gains IPOR-standard enter/exit/transient wrappers **while retaining** legacy withdraw-manager call selectors and manager caller authorization; `CurveYieldErc1271InstallFuse`/`ConfigFuse` gain transient entrypoints for new vaults; ERC20Transfer/BurnHeldShares explicitly revert from unsupported exitTransient; BalancerBalance rejects a zero market id.
3. **Mandatory Quest-aware tests:** the Katana fork harness runs `K1_QuestSigning` migration against the already installed wrapper before the P2 deploy scripts and uses a dedicated **fork-only** synthetic M3 receipt. The v6 fork conformance suite adds scenarios for PPS-losing transfers being rejected and Quest functionality surviving M4. `FuseConformanceV6.t.sol` provides standalone constructor/selector/malformed-input assertions.
4. **Provenance / docs:** `verify_ipor_pin_v6.py` (compare pinned IPOR source with a preexisting checkout in a GitHub runner), `PROVENANCE_VERIFICATION_v6.md`, six fuse-family READMEs, and updated migration/legacy design documents. `check_conformance_source_v6.py` is a dependency-free static smoke checker and `test_merkl_preflight_v6.py` tests the Merkl parser / receipt flow without live traffic.

## Verified when packaged

- IPOR source tree (173 files including dependencies), deployed legacy source (45 files), archive (34 files), Quest signing layer and gate implementation were byte-for-byte unchanged against v5.
- New source smoke checks passed and the Python Merkl preflight mock unit suite passed.
- Relative Solidity import paths resolved. No Solidity compilation or dependency download performed locally.

## Not finished / not certified

The **full IPOR_FUSE_CONFORMANCE_SPEC.md Part 8 exit criteria are NOT satisfied**. Source-level additions are not validated by a Solidity compiler or an on-chain fork. The remaining tests include full profitable/unprofitable loop cycles and unwind, USDC partial liquidity, protected UTS swap, sell-or-burn economic equivalence, custody Merkl/Charm/cover, updated-market dependency refresh, instant-list execution, and an end-to-end M0–M5 rehearsal. The F2 bytecode equivalence check requires a GitHub runner/Foundry/cast against live Katana. Live P2_03 is blocked while the old withdrawal manager has outstanding requests, until they are resolved. The owner/Safe retains previously acknowledged high-level IPOR governance authority and any existing direct factory fee capability; v6 does not remove that bypass or alter v5 authorization decisions.

**Never deploy based solely on these source-level checks**. Compile in an external GitHub environment and run required fork tests against a healthy Katana endpoint; verify current live state and withdraw requests before any broadcast. See README.md and docs/IPOR_FUSE_CONFORMANCE_SPEC.md Part 11.
