// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.30;

import {console2} from "forge-std/Test.sol";
import {Vm} from "forge-std/Vm.sol";
import {FuseAction} from "../../src/interfaces/CurveYieldPhase2Interfaces.sol";
import {Phase2ForkBase, IErcFork, IExecFork, IGateFork} from "../helpers/Phase2ForkBase.sol";
import {CurveYieldBundleGuardFuse, CurveYieldBundleGuardFuseEnterData, CurveYieldBundleGuardFuseExitData} from "../../src/generic/CurveYieldBundleGuardFuse.sol";
import {CurveYieldErc20TransferFuse, CurveYieldErc20TransferFuseEnterData} from "../../src/generic/CurveYieldErc20TransferFuse.sol";
import {CurveYieldConfigKeys as K} from "../../src/governance/CurveYieldGateConfig.sol";

interface IVaultConf {
    function getFuses() external view returns (address[] memory);
    function isFuseSupported(address) external view returns (bool);
    function getInstantWithdrawalFuses() external view returns (address[] memory);
    function getMarketSubstrates(uint256) external view returns (bytes32[] memory);
    function getDependencyBalanceGraph(uint256) external view returns (uint256[] memory);
    function getActiveMarketsInBalanceFuses() external view returns (uint256[] memory);
    function totalAssetsInMarket(uint256) external view returns (uint256);
    function isBalanceFuseSupported(uint256, address) external view returns (bool);
}

interface IRcmConf {
    function isRewardFuseSupported(address) external view returns (bool);
}

interface IGateSub {
    function previewSubstrates(uint256) external view returns (bytes32[] memory);
}

/// @notice Fork suite of IPOR_FUSE_CONFORMANCE_SPEC Part 8: builds the new stack on a Katana fork with the REAL scripts
/// P0_00, P2_01 .. P2_04 and checks the removals, the market map, and the executor-driven flows.
contract ConformanceForkTest is Phase2ForkBase {
    IVaultConf internal v = IVaultConf(VAULT);

    uint256 internal constant ZERO_MARKET = type(uint256).max;

    function setUp() public {
        _setUpFork("conf");
    }

    function _contains(address[] memory a_, address x_) internal pure returns (bool) {
        for (uint256 i; i < a_.length; ++i) if (a_[i] == x_) return true;
        return false;
    }

    function _has(bytes32[] memory a_, bytes32 x_) internal pure returns (bool) {
        for (uint256 i; i < a_.length; ++i) if (a_[i] == x_) return true;
        return false;
    }

    // ---------------------------------------------------------------- removals (Part 2) and the market map (§4.4)

    function scenario_removalsAndMarketMap() external {
        address[] memory fuses = v.getFuses();
        // nothing from Part 2 is installed any more
        address[8] memory gone = [
            0x44D368e85f419C59aC01b7270D234d8BF19Df36e, 0x79E88DD967Ef9a31046455dB94b1e487329Ed705,
            0x987C05943855B22552898F032c1AEa7930E340da, 0xC66c3F5cC5e1550A0Ff960c06D630A2FBB80E19d,
            0x1f657229ec2D261be7dCD63ca82abed334d1f28b, 0x70a2f848E21c912D660FE2263E5Be538268A41Ec,
            0x1fB8b83bAf40c90F0b450A3fd7A8b2E97Ab2a3Ff, 0x84927bFf2a35a543ed94A7d96D5ccd162a167947
        ];
        for (uint256 i; i < gone.length; ++i) require(!_contains(fuses, gone[i]), "a removed fuse is still installed");
        // instant list: official fuses that pay avKAT only (B3)
        address[] memory instant = v.getInstantWithdrawalFuses();
        require(instant.length == 1 && instant[0] == _p2("lendSupplyFuse"), "instant list");
        // the reward fuses of the rewards claim manager are gone (D11)
        IRcmConf rcm = IRcmConf(RCM);
        require(!rcm.isRewardFuseSupported(0xc6d024E53204CADa27a3c60C77dA4de2e7eb5166), "Merkl claim fuse");
        require(!rcm.isRewardFuseSupported(0x8c82b1ba53784F888Ea49463e2138cDF82973470), "sweep fuse");
        require(!rcm.isRewardFuseSupported(0xb62241b19995Dac16D5905050804e1f06caC9704), "auto-harvest fuse");
        // market 54 is retired, the vKAT adapter is out of market 7 (F13), vbUSDC is in
        uint256[] memory active = v.getActiveMarketsInBalanceFuses();
        for (uint256 i; i < active.length; ++i) require(active[i] != 54, "market 54 active");
        bytes32[] memory m7 = v.getMarketSubstrates(7);
        require(!_has(m7, bytes32(uint256(uint160(0xD3d3fd4fe4c09d9BB826A37D368Cf8033e512507)))), "adapter in market 7");
        require(_has(m7, bytes32(uint256(uint160(0x203A662b0BD271A6ed5a60EdFbd04bFce608FD36)))), "vbUSDC not in market 7");
        for (uint256 i; i < m7.length; ++i) require(uint256(m7[i]) >> 248 == 0, "typed substrate in market 7");
        // market 14: the loop and the USDC market; 100_001: cyvbUSDC; 19: KAT
        bytes32[] memory m14 = v.getMarketSubstrates(14);
        require(m14.length == 2, "market 14");
        require(v.getMarketSubstrates(100_001).length == 1, "market 100001");
        require(v.getMarketSubstrates(19).length == 1, "market 19");
        // dependencies to market 7 (F12)
        uint256[4] memory dep = [uint256(12), 19, 100_001, 14];
        for (uint256 i; i < dep.length; ++i) {
            uint256[] memory g = v.getDependencyBalanceGraph(dep[i]);
            require(g.length == 1 && g[0] == 7, "dependency graph to market 7");
        }
        // the typed config of the custom fuses is exactly what the gate writes (R5)
        require(keccak256(abi.encode(v.getMarketSubstrates(ZERO_MARKET))) == keccak256(abi.encode(IGateSub(address(gate)).previewSubstrates(ZERO_MARKET))), "ZERO market");
        require(keccak256(abi.encode(v.getMarketSubstrates(12))) == keccak256(abi.encode(IGateSub(address(gate)).previewSubstrates(12))), "market 12");
    }

    // ---------------------------------------------------------------- the executor on the new stack

    function scenario_deployAssetsKeepsThePps() external {
        uint256 pps = _ppsFresh();
        _depositAvkat(alice, 500e18);
        vm.prank(keeper);
        exec.deployAssets();
        _ppsNotBelow(pps, "deployAssets");
    }

    /// @notice E5: a post-bundle guard must refuse a transfer that lowers PPS.
    /// The recipient and token are permitted substrates; only the PPS guard fails.
    function scenario_guardBlocksPpsLoss() external {
        _depositAvkat(alice, 10e18);
        uint256[] memory markets = new uint256[](0);
        bytes32[] memory morpho = new bytes32[](0);
        FuseAction[] memory actions = new FuseAction[](3);
        actions[0] = FuseAction(_p2("guardFuse"), abi.encodeCall(CurveYieldBundleGuardFuse.enter,
            (CurveYieldBundleGuardFuseEnterData({markets: markets}))));
        actions[1] = FuseAction(_p2("transferFuse"), abi.encodeCall(CurveYieldErc20TransferFuse.enter,
            (CurveYieldErc20TransferFuseEnterData({
                token: AVKAT, to: 0xe7D109Ce6b34447Dd45B54e5615F4177291D5ADf, amount: 1e18
            }))));
        actions[2] = FuseAction(_p2("guardFuse"), abi.encodeCall(CurveYieldBundleGuardFuse.exit,
            (CurveYieldBundleGuardFuseExitData({
                markets: markets, maxPpsDropBps: 0, minAssetsPerShareDelta: 0,
                minIdleAssets: 0, morphoMarkets: morpho
            }))));
        uint256 beforeAssets = cy.totalAssets();
        vm.prank(DEPLOYER);
        vm.expectRevert(CurveYieldBundleGuardFuse.CurveYieldBundleGuardFusePpsDropped.selector);
        cy.execute(actions);
        assertEq(cy.totalAssets(), beforeAssets, "failed bundle changed vault assets");
    }

    /// @notice D5: detached legacy installer must not disable signing or ordinary IPOR base routing.
    function scenario_questStillActiveAfterM4() external {
        string memory record = vm.readFile(questsPath);
        address wrapper = vm.parseJsonAddress(record, ".base1271");
        address oldInstaller = vm.parseJsonAddress(record, ".signatureFuse");
        address config = vm.parseJsonAddress(record, ".configFuse");
        require(!v.isFuseSupported(oldInstaller), "legacy Quest installer reappeared");
        require(v.isFuseSupported(config), "revised Quest config unregistered");
        (bool ok, bytes memory baseData) = VAULT.staticcall(abi.encodeWithSignature("PLASMA_VAULT_BASE()"));
        require(ok && abi.decode(baseData, (address)) == wrapper, "active Quest base changed");
        bytes memory assetData;
        (ok, assetData) = VAULT.staticcall(abi.encodeWithSignature("asset()"));
        require(ok && abi.decode(assetData, (address)) == AVKAT, "original IPOR base no longer handles asset()");
    }

    function test_conformance() public {
        _runS("removals and market map", this.scenario_removalsAndMarketMap.selector);
        _runS("deployAssets keeps the share price", this.scenario_deployAssetsKeepsThePps.selector);
        _runS("guard rejects a PPS drop", this.scenario_guardBlocksPpsLoss.selector);
        _runS("Quest V2 still active after M4", this.scenario_questStillActiveAfterM4.selector);
        _tearDownFiles();
        _finish();
    }
}
