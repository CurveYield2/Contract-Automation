# Governance handover v5 — fee Safe IPOR OWNER retention

- Removed the P3_05 factory fee bypass preflight that blocked handover when the
  existing admin-fee Safe retains direct native IPOR factory permissions.
- Made preservation of the Safe's native IPOR Access Manager OWNER role 1 with
  zero execution delay an explicit P3_05 pre/post condition, and P9 final condition.
- Retained all fee-capable custom Ownable contracts under the CurveYield Gate;
  the Safe remains the initial gate-local self-managed ADMIN_FEE holder.
- Kept factory-native fee roles 901/902 assigned to Gate and revoked from Safe,
  while **preserving** Safe's separate IPOR OWNER role 1.
- Changed P9 factory Vault/FeeManager direct-permission failures to NOTICE logs.
  Native factory fee calls can bypass the Gate when IPOR permissions allow them;
  this is an acknowledged limit, NOT proof of factory-level fee exclusivity.
- Removed duplicate canCall declaration in P3_05 access-manager interface.
- Added regression test confirming Safe remains IPOR OWNER when fee contracts
  are Gate-owned and when gate-local ADMIN_FEE authority is rotated.
- Original IPOR factory source/deployed sources and mandatory Quest signing V2
  deployment checks remain unmodified.

Not compiled, fork-tested or deployed; verification is limited to source and
packaging checks until executed in a build/fork environment.
