# Source and runtime equivalence — v6

Only the **GitHub execution environment** may download dependencies or compile. Do not compile or fetch packages in the local environment.

The v6 bundle retains `ipor-fusion/contracts/` from v5. The executable check is `upgrade/scripts/verify_ipor_pin_v6.py` and compares each of the 90 shipped `.sol` sources byte-for-byte to `a1f79d6c3d0d426ace4df55ed0fb8ea340580739`.

In an isolated GitHub Actions runner (or Codespace), fetch the pinned IPOR checkout, then run:

```bash
python3 upgrade/scripts/verify_ipor_pin_v6.py --upstream /path/to/upstream/ipor-fusion
```

This only verifies source identity, **not** runtime equivalence. To reproduce F2, in that same isolated runner install the original pin's exact dependencies, compile with `solc 0.8.30`, optimizer **200 runs**, EVM **cancun**, and compare the deployed bytecode retrieved through `cast code` with the compiled `PlasmaVault`, `PlasmaVaultBase`, and `PlasmaVaultMarketsLib` runtimes. Strip Solidity's trailing CBOR metadata before comparing, and normalize *only* the linked `PlasmaVaultMarketsLib` slots to deployed address `0x6475d2c6b2e2Dc3de7F26226D08651F7F85ACf08`. Any other difference fails. Run `forge build` and fork tests against the bundled `upgrade/` separately (its build profile is different: optimizer 1 run, EVM prague, viaIR).

Addresses: vault clone `0xEd83daf48429cfb2C650Fd721b9241e180fd4548`, implementation `0xe0873c4f498ad4fd3ba9515ee69c545be084a3b8`, original base `0x6D73E66A5486C8Aa7DD8a3231F89087CE1D74b49`. The active signing wrapper remains `0x0a9eA25C827Ec0C6B2619C231B7566846619B365`; **do not** compare it in place of the original base. Record the exact compiler version, link addresses, chain ID, block number, and hashes in the test output.

No source verification or on-chain runtime comparison was executed when producing v6. A passing source check does not prove on-chain equivalence.
