# Bundle guard fuse — v6

**Source** `upgrade/src/generic/CurveYieldBundleGuardFuse.sol`; **exception E5**: official IPOR pre-hooks only validate before an action, not after it. Deploy to `ZERO_BALANCE_MARKET`, with immutable Morpho singleton. Does not own the vault or call gate contracts.

`enter((uint256[] markets))` snapshots the updated gross-asset valuation and supply at a nesting depth in transient storage. `exit((uint256[] markets,uint256 maxPpsDropBps,int256 minAssetsPerShareDelta,uint256 minIdleAssets,bytes32[] morphoMarkets))` refreshes again and enforces the requested loss/profit, idle, and granted Morpho LTV bounds; an unsuccessful exit reverts the bundle. `ZERO_BALANCE_MARKET` typed substrates set the PPS and LTV ceilings; the fuse also applies hard-coded 10% PPS and 85% LTV maxima. `maxPpsDropBps=0` prohibits a drop except the explicit 1,000 raw-asset rounding allowance. A negative `minAssetsPerShareDelta` allows bounded loss and is restricted by the substrate ceiling; deployment gate should normally keep the PPS ceiling at zero.

`enterTransient()` reads `[marketCount,marketIds...]`; `exitTransient()` reads `[marketCount,marketIds...,maxPpsDropBps,signedMinAssetsPerShareDelta,minIdleAssets,morphoMarketCount,morphoIds...]`. A signed negative delta is a two's-complement 256-bit word. Both outputs are empty. Malformed lengths revert, not silently default.

**Fork acceptance:** demonstrated same-bundle PPS rejection, nested scopes, LTV under/over permitted cap, and market 12→7 refresh. Never use this as a substitute for a post-settlement asset accounting check.
