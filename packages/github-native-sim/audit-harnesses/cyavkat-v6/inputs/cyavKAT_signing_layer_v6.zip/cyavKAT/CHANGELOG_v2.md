# cyavKAT Quest Signing Layer — v2 changes

Relative to the prior `cyavKAT_signing_layer_v1.zip`:

- Made Quest ERC-1271 signing an **enforced mandatory prerequisite** of the V2 upgrade, not a
  separate optional note. Introduced read-only `P2_00_VerifyQuestSigning` and integrated the
  shared on-chain `_requireQuestSigningV2()` precondition into the active Phase 2, governance,
  POL, custody and finalization scripts.
- New persistent `CurveYieldQuestSignerConfigFuse` exposes `QUEST_SIGNING_LAYER_VERSION() == 2`.
  Old installer and any older configuration fuses are rejected by on-chain V2 preflight.
- The **revised** `K1_QuestSigning` deploys the new version-2 config from `upgrade/src/katana/`
  and, on `QUEST_DETACH_INSTALL=true`, replaces any older recorded config and detaches the old
  installer, keeping the existing live wrapper and original IPOR factory base intact.
- K1 now rejects multiple simultaneous operation flags and shares the `QUEST_DEPLOYMENTS` record
  path with the V2 gate. `QUEST_REQUIRED_SIGNER` supports gated signer rotation.
- Removed stale precompiled `upgrade/out/` and `upgrade/cache/` files so deployment cannot silently reuse V1 binaries.
- Made real directories, deployment order, exact active scripts/commands, role prerequisites,
  `--broadcast` behavior and hard STOP conditions explicit in `README.md` and
  `docs/QUEST_SIGNING_LAYER_v2.md`.
- Added a unit assertion for the V2 version marker and binding invariants; updated phase-script
  comments and other signing reference docs to avoid endorsing the old installer as persistent.
- Preserved original `ipor-fusion/` and `deployed/` file bytes; no IPOR deployed contract was changed.

**NOT executed:** Solidity compilation, Forge/fork test run, transaction broadcast, or a live
on-chain version-gate verification. Static inspection and ZIP integrity checks only.
