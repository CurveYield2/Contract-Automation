# Governance control gate V4 — 2026-10-10

- Replaced V3 immutable-admin-fee policy with a dedicated, singleton, self-managed gate `ADMIN_FEE` role.
- Initialized role holder from the current `ADMIN_FEE_SAFE` admin-fee receiver. `adminReceiver` payout reference remains independent from role changes.
- Added self-only `transferAdminFeeRole`, selector-allowlisted `executeAdminFee` and fee function registration.
- Configured CLASS_FEE values, ranges, target fee argument ranges and fee-routing registry updates for fee role only.
- Added fee management for withdraw-manager split/onboarding/burn-only paths, wrapper fee splits and recipient changes.
- Required fee-bearing Ownable targets to transfer ownership to gate; reassigned IPOR 901/902 to gate and revoked the initial fee Safe from those roles.
- Preserved the original IPOR Access Manager as the only authority for native IPOR roles, and all original factory source files unchanged.
- Updated deployment, handover, POL and custody scripts, P9 check and source regression tests.
- Preserved mandatory revised Quest signing V2 migration and on-chain verification.

**Security qualification:** Gate-only dispatch does not prevent pre-existing IPOR administrators or other unknown permission holders from calling original factory fee setters directly. On-chain effective-permission verification is required before claiming the factory is fee-gate exclusive. This bundle was NOT compiled, fork-tested or deployed.
