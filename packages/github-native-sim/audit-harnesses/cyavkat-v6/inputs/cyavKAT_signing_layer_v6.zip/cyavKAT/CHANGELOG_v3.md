# cyavKAT IPOR role governance v3 — changes relative to signing layer v2

- Preserved every file in `ipor-fusion/` and `deployed/` byte-for-byte and retained all V2 Quest changes.
- Refactored operational `CurveYieldGovernanceGate` to **read permissions from the existing IPOR Access Manager**,
  replacing the gate's address-based DAO, fee-authority role ledger and protected execution lane.
- Made the admin-fee receiver immutable, all FEE-class numeric settings/ranges permanently immutable,
  fee-key registration one-time/sealed and protected-selector registration monotonic.
- Globally barred fee setter selectors, generic nested execution, role mutation and ownership moves;
  general gate execution is restricted to contracts actually owned by the gate (not fee Safe or third parties),
  and direct calls to the IPOR Access Manager are forbidden. The fee-sensitive revenue-custody and
  profit-splitter wiring keys are immutable after the initial deployment.
- Implemented narrow Ownable2Step acceptance and rollback-to-existing-fee-Safe methods for operational-only targets.
- Split Phase 3 ownership: operating custom modules go to the gate; fee-capable custom modules stay with the
  existing fee Safe, including the wrapper burn forwarder that can change contributor destinations. IPOR roles are granted solely via the original IPOR Access Manager; fee roles never go to gate.
- Removed gate `isFeeAuthority` from the withdrawal manager's onboarding receiver authorization: it now
  uses the existing IPOR template fee-setting permission directly even if a config gate is configured.
- Adapted P2_01, P2_02, P3_03, P3_04, P3_05, P3_99, P6_01, P6_02, P9; added new gate preflight,
  gate-specific deployment-record path and upgraded governance security/unit tests.
- Quest signing remains a **hard prerequisite** in all existing V2 scripts; no previous Quest implementation is restored.

**Never reuse an existing V2 gate address.** Migration of a previously deployed V2 gate-bound
custom stack needs additional per-contract owner/configGate migration and fork validation.

**Not executed:** local compilation (per instructions), Solidity unit/fork tests or live broadcast.
