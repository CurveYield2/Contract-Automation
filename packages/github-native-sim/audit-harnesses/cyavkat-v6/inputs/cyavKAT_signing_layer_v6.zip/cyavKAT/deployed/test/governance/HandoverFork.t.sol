// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.30;

import {console2} from "forge-std/Test.sol";
import {LendingForkSetup} from "../helpers/LendingForkSetup.sol";
import {P2_01_Deploy} from "../../script/P2_01_Deploy.s.sol";
import {P2_02_ConfigureVault} from "../../script/P2_02_ConfigureVault.s.sol";
import {P3_01_DeployGovernanceTokens} from "../../script/P3_01_DeployGovernanceTokens.s.sol";
import {P3_02_DeployDao} from "../../script/P3_02_DeployDao.s.sol";
import {P3_03_DeployGovernanceCore} from "../../script/P3_03_DeployGovernanceCore.s.sol";
import {P3_04_ConfigureGate} from "../../script/P3_04_ConfigureGate.s.sol";
import {P3_05_Handover} from "../../script/P3_05_Handover.s.sol";
import {P3_99_Rollback} from "../../script/P3_99_Rollback.s.sol";
import {CurveYieldGovernanceGate} from "../../src/governance/CurveYieldGovernanceGate.sol";
import {CurveYieldOptimizationGuardian} from "../../src/governance/CurveYieldOptimizationGuardian.sol";
import {IAragonDao} from "../../script/P3_02_DeployDao.s.sol";

interface IOwnableH {
    function owner() external view returns (address);
}

interface IAccessManagerH {
    function hasRole(uint64 roleId, address account) external view returns (bool, uint32);
    function isTargetClosed(address target) external view returns (bool);
}

interface IAllocationH {
    function vaultFloorBps() external view returns (uint16);
}

interface IScriptH {
    function setPaths(string calldata, string calldata) external;
    function run() external;
}

/// @notice Full handover on a Katana fork: P2_01 -> P2_02 -> P3_01..P3_05, then adversarial checks through the DAO, the
/// guardian lane, and finally P3_99_Rollback. Bot owners / operator are placeholders. Scripts run as the deployer through
/// `PRIVATE_KEY=0` (they fall back to broadcasting as DEPLOYER).
/// Run: RAYON_NUM_THREADS=2 forge test --match-path test/governance/HandoverFork.t.sol -vv
contract HandoverForkTest is LendingForkSetup {
    address constant AM = 0xd7f408f203c5c6a76c9c55c9f6b015929F151fAA;
    address constant VAULT = 0xEd83daf48429cfb2C650Fd721b9241e180fd4548;
    address constant DEPLOYER = 0x11b78837cadC8E894F1c6e13fA9f3A085a75FA35;
    address constant FEE_SAFE = 0x47623C62f281807D615eeb4A2CEee9d97F9D3C49;
    address constant FEE_MANAGER = 0x11a81a7B7436CB1E8f73866AF74961cE499f5Ec6;
    address constant CUSTODY = 0xe7D109Ce6b34447Dd45B54e5615F4177291D5ADf;
    address constant ROUTER = 0x01F9894f92ea9224fECc8C35482E20a05De13582;
    address constant WM_OLD = 0x59B340EAb30AFE0cecD51C609d3190e8C75C40AE;
    bytes32 constant EXECUTE_PROPOSAL = keccak256("EXECUTE_PROPOSAL_PERMISSION");
    bytes32 constant EXECUTE_PERMISSION = keccak256("EXECUTE_PERMISSION");

    string p2Path;
    string p3Path;
    string lendPath;
    string p2;
    string p3;
    string lend;
    address gate;
    address dao;
    address guardian;
    address adminPlugin;
    address operator = makeAddr("operator");
    address bot1 = makeAddr("bot1");
    address bot2 = makeAddr("bot2");
    address[] gated; // every contract the handover moves to the gate (deployer-owned, plus custody and router)

    function setUp() public {
        vm.createSelectFork(vm.envString("KATANA_RPC_URL"), vm.envUint("FORK_BLOCK"));
        vm.setEnv("PRIVATE_KEY", "0");
        p2Path = _tmpPath("handover-p2");
        p3Path = _tmpPath("handover-p3");
        lendPath = _tmpPath("handover-lend");
        vm.setEnv("PHASE3_DEPLOYMENTS", p3Path);
        vm.setEnv("SAFE_OWNER_BOT1", vm.toString(bot1));
        vm.setEnv("SAFE_OWNER_BOT2", vm.toString(bot2));
        vm.setEnv("BOT_OPERATOR", vm.toString(operator));
        _prepareLending(lendPath, p2Path);

        _run(address(new P2_01_Deploy()));
        _run(address(new P2_02_ConfigureVault()));
        IScriptH(address(new P3_01_DeployGovernanceTokens())).run();
        IScriptH(address(new P3_02_DeployDao())).run();
        IScriptH(address(new P3_03_DeployGovernanceCore())).run();
        _run(address(new P3_04_ConfigureGate()));
        _run(address(new P3_05_Handover()));

        p2 = vm.readFile(p2Path);
        p3 = vm.readFile(p3Path);
        lend = vm.readFile(lendPath);
        gate = vm.parseJsonAddress(p3, ".governanceGate");
        dao = vm.parseJsonAddress(p3, ".dao");
        guardian = vm.parseJsonAddress(p3, ".optimizationGuardian");
        adminPlugin = vm.parseJsonAddress(p3, ".adminPlugin");
        string[7] memory p2Keys = ["executor", "allocation", "loopController", "splitter", "vkatController", "lendController", "lpController"];
        string[4] memory p3Keys = ["engagementToken", "engagementRewards", "voterRewards", "proposalBond"];
        for (uint256 i; i < p2Keys.length; ++i) gated.push(vm.parseJsonAddress(p2, string.concat(".", p2Keys[i])));
        for (uint256 i; i < p3Keys.length; ++i) gated.push(vm.parseJsonAddress(p3, string.concat(".", p3Keys[i])));
        gated.push(vm.parseJsonAddress(lend, ".wcyavkat"));
        gated.push(vm.parseJsonAddress(lend, ".wrapperFeeSplitter"));
        gated.push(CUSTODY);
        gated.push(ROUTER);
    }

    function _run(address script_) internal {
        IScriptH(script_).setPaths(p2Path, lendPath);
        IScriptH(script_).run();
    }

    function _has(uint64 role_, address who_) internal view returns (bool has_) {
        (has_,) = IAccessManagerH(AM).hasRole(role_, who_);
    }

    function _pad(string memory sig_) internal pure returns (bytes memory) {
        return abi.encodePacked(bytes4(keccak256(bytes(sig_))), new bytes(128)); // selector + zero arguments
    }

    function _expectProtected(address target_, bytes memory data_) internal {
        vm.prank(dao);
        vm.expectRevert(abi.encodeWithSelector(CurveYieldGovernanceGate.ProtectedCall.selector, target_, bytes4(data_)));
        CurveYieldGovernanceGate(gate).execute(target_, data_);
    }

    /// @dev One test: the scripts read PHASE3_DEPLOYMENTS from the process environment, so parallel tests would race on it.
    function test_handover_endToEnd() public {
        _check1_handoverState();
        _check2_daoCannotReachProtectedCalls_butNormalCallsWork();
        _check3_guardian_runPauseUnpause();
        _check4_rollback_restoresTheDeployer();
    }

    // ---------------------------------------------------------------- 1. the handover

    function _check1_handoverState() internal view {
        // every gated contract is owned by the gate
        for (uint256 i; i < gated.length; ++i) {
            assertEq(IOwnableH(gated[i]).owner(), gate, string.concat("not gate-owned: ", vm.toString(gated[i])));
        }
        // the deployer holds none of the vault roles; the gate holds them (except ALPHA, kept by the executor)
        uint64[11] memory roles = [uint64(1), 100, 200, 300, 600, 800, 900, 901, 902, 1000, 1200];
        for (uint256 i; i < roles.length; ++i) {
            assertFalse(_has(roles[i], DEPLOYER), string.concat("deployer still holds role ", vm.toString(uint256(roles[i]))));
            if (roles[i] != 200) assertTrue(_has(roles[i], gate), string.concat("gate missing role ", vm.toString(uint256(roles[i]))));
        }
        assertFalse(_has(200, gate), "the gate must not hold ALPHA");
        // (no cutover in this run, so the executor holds no ALPHA yet; the handover must not have given it to the gate)
        assertTrue(_has(2, guardian), "the guardian holds GUARDIAN (role 2)");
        // the Admin plugin is still installed and the deployer still administers it
        IAragonDao d = IAragonDao(dao);
        assertTrue(d.hasPermission(adminPlugin, DEPLOYER, EXECUTE_PROPOSAL, ""), "deployer lost EXECUTE_PROPOSAL on the Admin plugin");
        assertTrue(d.hasPermission(dao, adminPlugin, EXECUTE_PERMISSION, ""), "the Admin plugin lost EXECUTE_PERMISSION on the DAO");
        // the fee Safe is the gate's fee authority
        assertTrue(CurveYieldGovernanceGate(gate).isFeeAuthority(FEE_SAFE));
    }

    // ---------------------------------------------------------------- 2. the DAO cannot touch what is protected

    function _check2_daoCannotReachProtectedCalls_butNormalCallsWork() internal {
        address wmV2 = vm.parseJsonAddress(p2, ".withdrawManagerV2");
        // every protected selector in P3_04's list, through gate.execute as the DAO
        _expectProtected(FEE_MANAGER, _pad("updatePerformanceFee((address,uint256)[])"));
        _expectProtected(FEE_MANAGER, _pad("updateManagementFee((address,uint256)[])"));
        _expectProtected(FEE_MANAGER, _pad("setDepositFee(uint256)"));
        _expectProtected(FEE_MANAGER, _pad("updateHighWaterMarkPerformanceFee()"));
        _expectProtected(FEE_MANAGER, _pad("updateIntervalHighWaterMarkPerformanceFee(uint32)"));
        _expectProtected(VAULT, _pad("configurePerformanceFee(address,uint256)"));
        _expectProtected(VAULT, _pad("configureManagementFee(address,uint256)"));
        _expectProtected(CUSTODY, _pad("setRevenueShareBps(uint16)"));
        _expectProtected(CUSTODY, _pad("setWindupDistributionBps(uint16,uint16)"));
        _expectProtected(CUSTODY, _pad("setFeeRecipient(address)"));
        _expectProtected(CUSTODY, _pad("scheduleFullUnwind(address)"));
        _expectProtected(CUSTODY, _pad("executeFullUnwind()"));
        _expectProtected(ROUTER, _pad("setFeeRecipient(address)"));
        _expectProtected(ROUTER, _pad("setFeeBps(uint16)"));
        _expectProtected(ROUTER, _pad("setRouteFeeBps(address,address,uint16)"));
        _expectProtected(ROUTER, _pad("clearRouteFee(address,address)"));
        _expectProtected(ROUTER, _pad("transferOwnership(address)"));
        _expectProtected(vm.parseJsonAddress(p2, ".splitter"), _pad("setSplit(uint16,uint16,uint16,uint16)"));
        _expectProtected(vm.parseJsonAddress(p2, ".splitter"), _pad("setGrowthCustody(address)"));
        _expectProtected(wmV2, _pad("updateWithdrawFee(uint256)"));
        _expectProtected(wmV2, _pad("updateRequestFee(uint256)"));
        _expectProtected(wmV2, _pad("setProfitCustody(address)"));
        _expectProtected(WM_OLD, _pad("updateWithdrawFee(uint256)"));
        _expectProtected(WM_OLD, _pad("updateRequestFee(uint256)"));
        _expectProtected(vm.parseJsonAddress(lend, ".wcyavkat"), _pad("setFees(uint256,uint256)"));
        _expectProtected(vm.parseJsonAddress(lend, ".wrapperFeeSplitter"), _pad("setAdminReceiver(address)"));
        _expectProtected(vm.parseJsonAddress(p3, ".proposalBond"), _pad("setAdminReceiver(address)"));

        // access manager: fee roles and everything but the allowlisted role calls
        for (uint256 i; i < 2; ++i) {
            uint64 r = i == 0 ? uint64(901) : uint64(400);
            _expectProtected(AM, abi.encodeWithSignature("grantRole(uint64,address,uint32)", r, makeAddr("x"), uint32(0)));
        }
        uint64[5] memory feeRoles = [uint64(7), 400, 500, 901, 902];
        for (uint256 i; i < feeRoles.length; ++i) {
            _expectProtected(AM, abi.encodeWithSignature("revokeRole(uint64,address)", feeRoles[i], DEPLOYER));
        }
        _expectProtected(AM, _pad("setTargetFunctionRole(address,bytes4[],uint64)"));

        // ownership moves on every gated contract, and the gate itself
        for (uint256 i; i < gated.length; ++i) {
            _expectProtected(gated[i], abi.encodeWithSignature("transferOwnership(address)", makeAddr("attacker")));
            _expectProtected(gated[i], abi.encodeWithSignature("renounceOwnership()"));
        }
        _expectProtected(gate, abi.encodeWithSignature("setDao(address)", makeAddr("attacker")));

        // generic wrappers on the access manager and anywhere else
        bytes[] memory inner = new bytes[](0);
        _expectProtected(AM, abi.encodeWithSignature("multicall(bytes[])", inner));
        _expectProtected(AM, abi.encodeWithSignature("execute(address,bytes)", VAULT, hex""));

        // a normal DAO call succeeds: the allocation controller's vault floor (bounds 10% - 50%)
        address allocation = vm.parseJsonAddress(p2, ".allocation");
        assertEq(IAllocationH(allocation).vaultFloorBps(), 3_000);
        vm.prank(dao);
        CurveYieldGovernanceGate(gate).execute(allocation, abi.encodeWithSignature("setVaultFloorBps(uint16)", uint16(2_500)));
        assertEq(IAllocationH(allocation).vaultFloorBps(), 2_500);
        // ... and stays within its bounds
        vm.prank(dao);
        vm.expectRevert();
        CurveYieldGovernanceGate(gate).execute(allocation, abi.encodeWithSignature("setVaultFloorBps(uint16)", uint16(5_001)));
        // a role grant on an unprotected role that the gate administers (WHITELIST 800, admin ATOMIST 100) is allowed
        vm.prank(dao);
        CurveYieldGovernanceGate(gate).execute(AM, abi.encodeWithSignature("grantRole(uint64,address,uint32)", uint64(800), makeAddr("someone"), uint32(0)));
        assertTrue(_has(800, makeAddr("someone")));
    }

    // ---------------------------------------------------------------- 3. the guardian lane

    function _check3_guardian_runPauseUnpause() internal {
        CurveYieldOptimizationGuardian g = CurveYieldOptimizationGuardian(guardian);
        assertTrue(g.isOwner(DEPLOYER) && g.isOwner(FEE_SAFE) && g.isOwner(dao));
        assertEq(g.operator(), operator);
        address allocation = vm.parseJsonAddress(p2, ".allocation");

        // register the allowed action (P3_04 allow-listed allocation.setVaultFloorBps(uint16) in the gate's guardian lane)
        vm.prank(DEPLOYER);
        g.setAction(0, allocation, bytes4(keccak256("setVaultFloorBps(uint16)")), true, 1_000, 5_000, true);
        vm.prank(operator);
        g.run(0, 2_000);
        assertEq(IAllocationH(allocation).vaultFloorBps(), 2_000, "operator run did not reach the allocation controller");
        vm.prank(operator);
        vm.expectRevert();
        g.run(0, 999); // out of the action's bounds
        vm.prank(operator);
        vm.expectRevert();
        g.run(0, 5_001);

        // an action the gate never allow-listed is refused by the gate
        vm.prank(DEPLOYER);
        g.setAction(1, allocation, bytes4(keccak256("transferOwnership(address)")), true, 0, type(uint256).max, true);
        vm.prank(operator);
        vm.expectRevert();
        g.run(1, uint256(uint160(makeAddr("attacker"))));
        assertEq(IOwnableH(allocation).owner(), gate);

        // pause: the operator closes the vault; only an owner reopens it
        assertFalse(IAccessManagerH(AM).isTargetClosed(VAULT));
        vm.prank(operator);
        g.pauseVault();
        assertTrue(IAccessManagerH(AM).isTargetClosed(VAULT), "vault not closed by pauseVault");
        vm.prank(operator);
        vm.expectRevert();
        g.unpauseVault();
        assertTrue(IAccessManagerH(AM).isTargetClosed(VAULT));
        vm.prank(FEE_SAFE);
        g.unpauseVault();
        assertFalse(IAccessManagerH(AM).isTargetClosed(VAULT), "vault not reopened by an owner");
    }

    // ---------------------------------------------------------------- 4. rollback

    function _check4_rollback_restoresTheDeployer() internal {
        _run(address(new P3_99_Rollback()));
        // every contract is owned by the deployer again; router and custody back with the fee Safe
        for (uint256 i; i < gated.length; ++i) {
            address expected = (gated[i] == CUSTODY || gated[i] == ROUTER) ? FEE_SAFE : DEPLOYER;
            assertEq(IOwnableH(gated[i]).owner(), expected, string.concat("not rolled back: ", vm.toString(gated[i])));
        }
        uint64[11] memory roles = [uint64(1), 100, 200, 300, 600, 800, 900, 901, 902, 1000, 1200];
        for (uint256 i; i < roles.length; ++i) {
            assertTrue(_has(roles[i], DEPLOYER), string.concat("deployer missing role ", vm.toString(uint256(roles[i]))));
        }
        // the Admin plugin is still there after the rollback too
        assertTrue(IAragonDao(dao).hasPermission(adminPlugin, DEPLOYER, EXECUTE_PROPOSAL, ""));
        console2.log("rollback complete");
    }
}
