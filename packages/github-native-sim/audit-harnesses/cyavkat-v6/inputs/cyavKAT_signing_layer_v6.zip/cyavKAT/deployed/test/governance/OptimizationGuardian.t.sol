// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.30;

import {Test} from "forge-std/Test.sol";
import {CurveYieldGovernanceGate} from "../../src/governance/CurveYieldGovernanceGate.sol";
import {CurveYieldOptimizationGuardian} from "../../src/governance/CurveYieldOptimizationGuardian.sol";
import {GovMockTarget, MockAccessManager} from "./GovMocks.sol";

contract OptimizationGuardianTest is Test {
    CurveYieldGovernanceGate gate;
    CurveYieldOptimizationGuardian guard;
    GovMockTarget target;
    MockAccessManager am;
    address dao = makeAddr("dao");
    address fee = makeAddr("fee");
    address ownerA = makeAddr("ownerA");
    address ownerB = makeAddr("ownerB");
    address op = makeAddr("operator");
    address rnd = makeAddr("rnd");
    address vault = makeAddr("vault");

    function setUp() public {
        gate = new CurveYieldGovernanceGate(dao, fee);
        target = new GovMockTarget(address(gate));
        am = new MockAccessManager();
        address[] memory owners = new address[](2);
        owners[0] = ownerA;
        owners[1] = ownerB;
        guard = new CurveYieldOptimizationGuardian(address(gate), address(am), vault, owners, op);
        vm.startPrank(dao);
        gate.setGuardian(address(guard));
        gate.setGuardianCall(address(target), target.setter.selector, true);
        gate.setGuardianCall(address(target), target.ping.selector, true);
        vm.stopPrank();
        vm.prank(ownerA);
        guard.setAction(0, address(target), target.setter.selector, true, 10, 100, true);
        vm.prank(ownerA);
        guard.setAction(1, address(target), target.ping.selector, false, 0, 0, true);
    }

    // ---------------------------------------------------------------- owner / operator rights

    function test_ownerAndOperatorRights() public {
        assertTrue(guard.isOwner(ownerA));
        assertTrue(guard.isOwner(ownerB));
        assertEq(guard.ownerCount(), 2);
        assertEq(guard.operator(), op);

        // the operator can run, but cannot administrate
        vm.prank(op);
        guard.run(0, 50);
        vm.startPrank(op);
        vm.expectRevert(CurveYieldOptimizationGuardian.NotOwner.selector);
        guard.setOwner(rnd, true);
        vm.expectRevert(CurveYieldOptimizationGuardian.NotOwner.selector);
        guard.setOperator(rnd);
        vm.expectRevert(CurveYieldOptimizationGuardian.NotOwner.selector);
        guard.setAction(0, address(target), target.setter.selector, true, 0, type(uint256).max, true);
        vm.expectRevert(CurveYieldOptimizationGuardian.NotOwner.selector);
        guard.unpauseVault();
        vm.stopPrank();

        // strangers can do nothing
        vm.startPrank(rnd);
        vm.expectRevert(CurveYieldOptimizationGuardian.NotOperatorOrOwner.selector);
        guard.run(0, 50);
        vm.expectRevert(CurveYieldOptimizationGuardian.NotOperatorOrOwner.selector);
        guard.pauseVault();
        vm.expectRevert(CurveYieldOptimizationGuardian.NotOwner.selector);
        guard.setOwner(rnd, true);
        vm.stopPrank();

        // owners can run too, and change everything
        vm.prank(ownerB);
        guard.run(0, 60);
        assertEq(target.value(), 60);
        vm.prank(ownerB);
        guard.setOperator(rnd);
        assertEq(guard.operator(), rnd);
        vm.prank(rnd);
        guard.run(0, 70);
        assertEq(target.value(), 70);
        // the old operator lost its right
        vm.prank(op);
        vm.expectRevert(CurveYieldOptimizationGuardian.NotOperatorOrOwner.selector);
        guard.run(0, 50);
        vm.prank(ownerA);
        guard.setOwner(rnd, true);
        assertEq(guard.ownerCount(), 3);
    }

    // ---------------------------------------------------------------- bounded run through the gate

    function test_run_boundedValue_goesThroughTheGatesGuardianLane() public {
        vm.prank(op);
        guard.run(0, 10);
        assertEq(target.value(), 10);
        assertEq(target.lastCaller(), address(gate), "the call must come from the gate");
        vm.prank(op);
        guard.run(0, 100);
        assertEq(target.value(), 100);
        vm.startPrank(op);
        vm.expectRevert(abi.encodeWithSelector(CurveYieldOptimizationGuardian.OutOfBounds.selector, 9, 10, 100));
        guard.run(0, 9);
        vm.expectRevert(abi.encodeWithSelector(CurveYieldOptimizationGuardian.OutOfBounds.selector, 101, 10, 100));
        guard.run(0, 101);
        vm.stopPrank();
        assertEq(target.value(), 100, "an out-of-bounds value reached the target");

        // a no-argument action ignores the value and needs no bounds
        vm.prank(op);
        guard.run(1, 12345);
        assertEq(target.pings(), 1);
    }

    function test_run_disabledUnknownAndNotAllowListedByTheGate() public {
        vm.prank(ownerA);
        guard.setAction(0, address(target), target.setter.selector, true, 10, 100, false);
        vm.prank(op);
        vm.expectRevert(CurveYieldOptimizationGuardian.ActionDisabled.selector);
        guard.run(0, 50);
        vm.prank(op);
        vm.expectRevert(); // no such action
        guard.run(9, 50);

        // an action the DAO never allow-listed on the gate is refused by the gate
        vm.prank(ownerA);
        guard.setAction(2, address(target), target.setAdmin.selector, true, 0, type(uint256).max, true);
        vm.prank(op);
        vm.expectRevert(abi.encodeWithSelector(CurveYieldGovernanceGate.NotGuardianCall.selector, address(target), target.setAdmin.selector));
        guard.run(2, 1);
        // even when allow-listed, a protected call is refused: the gate protects the pair
        bytes4[] memory sels = new bytes4[](1);
        sels[0] = target.setAdmin.selector;
        vm.prank(fee);
        gate.setProtectedCalls(address(target), sels, true);
        vm.prank(dao);
        gate.setGuardianCall(address(target), target.setAdmin.selector, true);
        vm.prank(op);
        vm.expectRevert(abi.encodeWithSelector(CurveYieldGovernanceGate.ProtectedCall.selector, address(target), target.setAdmin.selector));
        guard.run(2, 1);
        // and once the DAO removes the guardian nothing runs (re-enable action 0 first)
        vm.prank(ownerA);
        guard.setAction(0, address(target), target.setter.selector, true, 10, 100, true);
        vm.prank(dao);
        gate.setGuardian(address(0));
        vm.prank(op);
        vm.expectRevert(abi.encodeWithSelector(CurveYieldGovernanceGate.NotGuardianCall.selector, address(target), target.setter.selector));
        guard.run(0, 50);
    }

    function test_setAction_appendUpdateAndValidation() public {
        assertEq(guard.actionsLength(), 2);
        vm.prank(ownerA);
        guard.setAction(2, address(target), target.setAdmin.selector, true, 1, 2, true); // id == length appends
        assertEq(guard.actionsLength(), 3);
        vm.prank(ownerA);
        guard.setAction(2, address(target), target.setAdmin.selector, true, 1, 5, true); // update in place
        assertEq(guard.actionsLength(), 3);
        assertEq(guard.actionOf(2).max, 5);
        vm.startPrank(ownerA);
        vm.expectRevert(CurveYieldOptimizationGuardian.InvalidAddress.selector);
        guard.setAction(3, address(0), target.setter.selector, true, 1, 2, true);
        vm.expectRevert(CurveYieldOptimizationGuardian.InvalidAddress.selector);
        guard.setAction(3, address(target), target.setter.selector, true, 3, 2, true);
        vm.stopPrank();
    }

    // ---------------------------------------------------------------- pause

    function test_operatorPauses_onlyOwnersUnpause() public {
        vm.prank(op);
        guard.pauseVault();
        assertEq(am.lastClosedTarget(), vault);
        assertTrue(am.lastClosed());
        assertEq(am.lastCloseCaller(), address(guard), "the guardian contract must be the caller (it holds GUARDIAN_ROLE)");
        assertEq(am.closeCalls(), 1);

        vm.prank(op);
        vm.expectRevert(CurveYieldOptimizationGuardian.NotOwner.selector);
        guard.unpauseVault();
        vm.prank(rnd);
        vm.expectRevert(CurveYieldOptimizationGuardian.NotOwner.selector);
        guard.unpauseVault();
        assertTrue(am.lastClosed(), "the vault was reopened by a non-owner");

        vm.prank(ownerB);
        guard.unpauseVault();
        assertFalse(am.lastClosed());
        assertEq(am.closeCalls(), 2);

        // owners can pause too
        vm.prank(ownerA);
        guard.pauseVault();
        assertTrue(am.lastClosed());
    }

    // ---------------------------------------------------------------- owners

    function test_lastOwnerCannotBeRemoved() public {
        vm.prank(ownerA);
        guard.setOwner(ownerB, false);
        assertEq(guard.ownerCount(), 1);
        assertFalse(guard.isOwner(ownerB));
        vm.prank(ownerA);
        vm.expectRevert(CurveYieldOptimizationGuardian.LastOwner.selector);
        guard.setOwner(ownerA, false);
        assertTrue(guard.isOwner(ownerA));
        // removing a non-owner is a no-op, adding an existing owner too
        vm.prank(ownerA);
        guard.setOwner(rnd, false);
        vm.prank(ownerA);
        guard.setOwner(ownerA, true);
        assertEq(guard.ownerCount(), 1);
        vm.prank(ownerA);
        vm.expectRevert(CurveYieldOptimizationGuardian.InvalidAddress.selector);
        guard.setOwner(address(0), true);
        // a removed owner has no rights
        vm.prank(ownerB);
        vm.expectRevert(CurveYieldOptimizationGuardian.NotOwner.selector);
        guard.setOwner(ownerB, true);
    }

    function test_constructorValidation() public {
        address[] memory none = new address[](0);
        vm.expectRevert(CurveYieldOptimizationGuardian.InvalidAddress.selector);
        new CurveYieldOptimizationGuardian(address(gate), address(am), vault, none, op);
        address[] memory dup = new address[](2);
        dup[0] = ownerA;
        dup[1] = ownerA;
        vm.expectRevert(CurveYieldOptimizationGuardian.InvalidAddress.selector);
        new CurveYieldOptimizationGuardian(address(gate), address(am), vault, dup, op);
        address[] memory zero = new address[](1);
        vm.expectRevert(CurveYieldOptimizationGuardian.InvalidAddress.selector);
        new CurveYieldOptimizationGuardian(address(gate), address(am), vault, zero, op);
        address[] memory one = new address[](1);
        one[0] = ownerA;
        vm.expectRevert(CurveYieldOptimizationGuardian.InvalidAddress.selector);
        new CurveYieldOptimizationGuardian(address(0), address(am), vault, one, op);
        vm.expectRevert(CurveYieldOptimizationGuardian.InvalidAddress.selector);
        new CurveYieldOptimizationGuardian(address(gate), address(0), vault, one, op);
        vm.expectRevert(CurveYieldOptimizationGuardian.InvalidAddress.selector);
        new CurveYieldOptimizationGuardian(address(gate), address(am), address(0), one, op);
    }
}
