// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.30;

import {Test} from "forge-std/Test.sol";
import {CurveYieldEngagementToken} from "../../src/governance/CurveYieldEngagementToken.sol";
import {CurveYieldEngagementRewards} from "../../src/governance/CurveYieldEngagementRewards.sol";
import {GovMockToken} from "./GovMocks.sol";

contract EngagementRewardsTest is Test {
    uint256 constant T = 1_800_000_000;

    CurveYieldEngagementToken eng;
    CurveYieldEngagementRewards rewards;
    GovMockToken r1;
    GovMockToken r2;
    address minter = makeAddr("minter");
    address alice = makeAddr("alice");
    address bob = makeAddr("bob");
    address carol = makeAddr("carol");

    function setUp() public {
        vm.warp(T);
        eng = new CurveYieldEngagementToken(address(this));
        rewards = new CurveYieldEngagementRewards(address(this), address(eng));
        eng.setMinter(minter, true);
        eng.setDistributor(address(rewards));
        r1 = new GovMockToken("R1");
        r2 = new GovMockToken("R2");
        rewards.setRewardToken(address(r1), true);
        vm.prank(minter);
        eng.mint(alice, 100e18);
        vm.prank(minter);
        eng.mint(bob, 300e18);
    }

    function test_openEpoch_locksUnreserved_pausesMinting_processClosesAndUnpauses() public {
        r1.mint(address(rewards), 1_000e18);
        uint256 id = rewards.openEpoch();
        assertEq(id, 0);
        assertEq(rewards.reserved(address(r1)), 1_000e18);
        assertTrue(eng.mintingPaused());
        vm.prank(minter);
        vm.expectRevert(CurveYieldEngagementToken.Paused.selector);
        eng.mint(alice, 1e18);
        (uint256 time, uint256 holders, uint256 cursor, bool closed, uint256 total) = rewards.epochInfo(0);
        assertEq(time, T);
        assertEq(holders, 2);
        assertEq(cursor, 0);
        assertFalse(closed);
        assertEq(total, 0);
        (address[] memory toks, uint256[] memory amts) = rewards.epochTokens(0);
        assertEq(toks.length, 1);
        assertEq(toks[0], address(r1));
        assertEq(amts[0], 1_000e18);

        vm.expectRevert(CurveYieldEngagementRewards.EpochStillOpen.selector);
        rewards.openEpoch();
        vm.expectRevert(CurveYieldEngagementRewards.EpochNotClosed.selector);
        rewards.claim(0, alice);

        rewards.processEpoch(1); // one holder per call
        (,, cursor, closed,) = rewards.epochInfo(0);
        assertEq(cursor, 1);
        assertFalse(closed);
        assertTrue(eng.mintingPaused(), "unpaused before the epoch closed");
        rewards.processEpoch(50); // the rest
        (,, cursor, closed, total) = rewards.epochInfo(0);
        assertEq(cursor, 2);
        assertTrue(closed);
        assertEq(total, 400e18);
        assertFalse(eng.mintingPaused(), "still paused after the epoch closed");
        rewards.processEpoch(5); // no-op once closed
        vm.prank(minter);
        eng.mint(alice, 1e18); // minting works again
    }

    function test_claims_proRataToBalanceAtEpochTime_onceOnly_exactReserved() public {
        r1.mint(address(rewards), 1_000e18);
        // a holder whose balance decays before the epoch opens
        vm.warp(T + 90 days);
        // alice: 50, bob: 150 at the epoch time
        rewards.openEpoch();
        rewards.processEpoch(10);
        vm.warp(T + 170 days); // later decay must not change the weights
        uint256 wA = eng.balanceAt(alice, T + 90 days);
        uint256 wB = eng.balanceAt(bob, T + 90 days);
        assertEq(wA, 50e18);
        assertEq(wB, 150e18);
        assertEq(rewards.weightOf(0, alice), wA);
        assertEq(rewards.weightOf(0, bob), wB);

        (address[] memory ct, uint256[] memory ca) = rewards.claimable(0, alice);
        assertEq(ct.length, 1);
        assertEq(ca[0], 1_000e18 * wA / (wA + wB));

        uint256 a0 = r1.balanceOf(alice);
        rewards.claim(0, alice); // anyone can claim for the holder; paid to the holder
        uint256 expA = 1_000e18 * wA / (wA + wB);
        assertEq(r1.balanceOf(alice) - a0, expA);
        assertEq(rewards.reserved(address(r1)), 1_000e18 - expA, "reserved not decremented exactly");
        vm.expectRevert(CurveYieldEngagementRewards.AlreadyClaimed.selector);
        rewards.claim(0, alice);
        (, ca) = rewards.claimable(0, alice);
        assertEq(ca[0], 0);

        vm.prank(bob);
        rewards.claim(0, bob);
        uint256 expB = 1_000e18 * wB / (wA + wB);
        assertEq(r1.balanceOf(bob), expB);
        assertEq(rewards.reserved(address(r1)), 1_000e18 - expA - expB);
        assertEq(r1.balanceOf(address(rewards)), rewards.reserved(address(r1)), "balance != reserved dust");
        // a holder with no weight: claim marks it and pays nothing
        rewards.claim(0, carol);
        assertEq(r1.balanceOf(carol), 0);
        vm.expectRevert(CurveYieldEngagementRewards.AlreadyClaimed.selector);
        rewards.claim(0, carol);
    }

    function test_minimumInterval_andSecondEpochUsesOnlyNewFunds() public {
        r1.mint(address(rewards), 1_000e18);
        rewards.openEpoch();
        rewards.processEpoch(10);
        rewards.claim(0, alice); // bob leaves his epoch-0 share unclaimed
        uint256 reservedAfter = rewards.reserved(address(r1));
        assertGt(reservedAfter, 0);

        r1.mint(address(rewards), 500e18);
        vm.warp(T + 3 days);
        vm.expectRevert(CurveYieldEngagementRewards.TooSoon.selector);
        rewards.openEpoch();
        vm.warp(T + 7 days);
        rewards.openEpoch();
        (address[] memory toks, uint256[] memory amts) = rewards.epochTokens(1);
        assertEq(toks[0], address(r1));
        assertEq(amts[0], 500e18, "second epoch used old (reserved) funds");
        assertEq(rewards.reserved(address(r1)), reservedAfter + 500e18);
        rewards.processEpoch(10);

        // bob can still claim epoch 0, and epoch 1
        (, uint256[] memory c0) = rewards.claimable(0, bob);
        rewards.claim(0, bob);
        assertEq(r1.balanceOf(bob), c0[0]);
        rewards.claim(1, bob);
        rewards.claim(1, alice);
        assertLe(rewards.reserved(address(r1)), 2, "reserved dust larger than rounding");
        assertEq(r1.balanceOf(address(rewards)), rewards.reserved(address(r1)));
    }

    function test_minEpochIntervalBoundsAndOwnerOnly() public {
        vm.expectRevert(bytes("interval"));
        rewards.setMinEpochInterval(1 days - 1);
        vm.expectRevert(bytes("interval"));
        rewards.setMinEpochInterval(90 days + 1);
        rewards.setMinEpochInterval(1 days);
        rewards.setMinEpochInterval(90 days);
        assertEq(rewards.minEpochInterval(), 90 days);
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSignature("OwnableUnauthorizedAccount(address)", alice));
        rewards.setMinEpochInterval(2 days);
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSignature("OwnableUnauthorizedAccount(address)", alice));
        rewards.setRewardToken(address(r2), true);
    }

    function test_nothingToDistribute_noFunds_orNoHolders() public {
        vm.expectRevert(CurveYieldEngagementRewards.NothingToDistribute.selector);
        rewards.openEpoch(); // no funds
        // an unwhitelisted token is ignored
        r2.mint(address(rewards), 10e18);
        vm.expectRevert(CurveYieldEngagementRewards.NothingToDistribute.selector);
        rewards.openEpoch();
        // funds but no holders
        CurveYieldEngagementToken eng2 = new CurveYieldEngagementToken(address(this));
        CurveYieldEngagementRewards rw2 = new CurveYieldEngagementRewards(address(this), address(eng2));
        rw2.setRewardToken(address(r1), true);
        r1.mint(address(rw2), 5e18);
        vm.expectRevert(CurveYieldEngagementRewards.NothingToDistribute.selector);
        rw2.openEpoch();
    }

    function test_twoRewardTokens_eachProRata() public {
        rewards.setRewardToken(address(r2), true);
        r1.mint(address(rewards), 400e18);
        r2.mint(address(rewards), 8e18);
        rewards.openEpoch();
        rewards.processEpoch(10);
        rewards.claim(0, alice); // 25%
        assertEq(r1.balanceOf(alice), 100e18);
        assertEq(r2.balanceOf(alice), 2e18);
        rewards.claim(0, bob); // 75%
        assertEq(r1.balanceOf(bob), 300e18);
        assertEq(r2.balanceOf(bob), 6e18);
        assertEq(rewards.reserved(address(r1)), 0);
        assertEq(rewards.reserved(address(r2)), 0);
        // de-listing a token excludes it from later epochs
        rewards.setRewardToken(address(r2), false);
        vm.warp(T + 8 days);
        r2.mint(address(rewards), 1e18);
        r1.mint(address(rewards), 1e18);
        rewards.openEpoch();
        (address[] memory toks,) = rewards.epochTokens(1);
        assertEq(toks.length, 1);
        assertEq(toks[0], address(r1));
    }
}
