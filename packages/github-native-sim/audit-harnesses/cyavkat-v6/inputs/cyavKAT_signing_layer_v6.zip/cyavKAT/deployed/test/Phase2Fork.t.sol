// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.30;

import {Test, console2} from "forge-std/Test.sol";
import {FuseAction} from "../src/interfaces/CurveYieldPhase2Interfaces.sol";
import {UpdateWithdrawManagerMaintenanceFuse} from "contracts/fuses/maintenance/UpdateWithdrawManagerMaintenanceFuse.sol";
import {BurnRequestFeeFuse} from "contracts/fuses/burn_request_fee/BurnRequestFeeFuse.sol";
import {CallbackHandlerMorpho} from "contracts/handlers/callbacks/CallbackHandlerMorpho.sol";
import {CyBound, CurveYieldBounds} from "../src/libraries/CurveYieldBounds.sol";
import {CurveYieldLoopProfitSplitter} from "../src/morpho/CurveYieldLoopProfitSplitter.sol";
import {
    CurveYieldMorphoLoopController, CyLoopParams, CyLoopParamBounds, CyLoopFuses
} from "../src/morpho/CurveYieldMorphoLoopController.sol";
import {CyLoopEnv, CyLoopSnapshot} from "../src/morpho/CurveYieldMorphoLoopLib.sol";
import {
    CurveYieldMorphoLoopWindupFuse,
    CurveYieldMorphoLoopLtvRebalanceFuse,
    CurveYieldMorphoLoopUnwindFuse,
    CurveYieldMorphoLoopEmergencyFuse
} from "../src/morpho/CurveYieldMorphoLoopFuses.sol";
import {CurveYieldMorphoLoopFuseBase} from "../src/morpho/CurveYieldMorphoLoopFuseBase.sol";
import {CurveYieldAllocationController, CySets} from "../src/allocation/CurveYieldAllocationController.sol";
import {CurveYieldExecutorPayFuse, CurveYieldProfitSplitFuse} from "../src/executor/CurveYieldExecutorFuses.sol";
import {CurveYieldVaultExecutor, CyExecutorDeps} from "../src/executor/CurveYieldVaultExecutor.sol";
import {CurveYieldWithdrawalManagerV2} from "../src/withdraw/CurveYieldWithdrawalManagerV2.sol";
import {
    CurveYieldVkatController, CyVkatEnv, CyVkatParams, CyVkatParamBounds, CyVkatFuses
} from "../src/vkat/CurveYieldVkatController.sol";
import {
    CurveYieldVkatLockFuse,
    CurveYieldVkatConvertFuse,
    CurveYieldVkatVoteFuse,
    CurveYieldVkatExitPrepareFuse,
    CurveYieldVkatExitBeginFuse,
    CurveYieldVkatExitCompleteFuse
} from "../src/vkat/CurveYieldVkatFuses.sol";
import {Vm} from "forge-std/Vm.sol";
import {LendingForkSetup} from "./helpers/LendingForkSetup.sol";
import {CurveYieldErc20BalanceFuse} from "../src/accounting/CurveYieldErc20BalanceFuse.sol";
import {MorphoSupplyFuse} from "contracts/fuses/morpho/MorphoSupplyFuse.sol";
import {MorphoBalanceFuse} from "contracts/fuses/morpho/MorphoBalanceFuse.sol";
import {IMorpho, MarketParams, Id} from "@morpho-org/morpho-blue/src/interfaces/IMorpho.sol";
import {CurveYieldAvkatLendController, CyLendParams, CyLendParamBounds} from "../src/lend/CurveYieldAvkatLendController.sol";
import {CurveYieldAvkatLendReduceFuse} from "../src/lend/CurveYieldAvkatLendReduceFuse.sol";
import {CurveYieldSushiLpHolder, CyLpPosition} from "../src/lp/CurveYieldSushiLpHolder.sol";
import {
    CurveYieldSushiLpController, CyLpParams, CyLpParamBounds, CyLpFuses
} from "../src/lp/CurveYieldSushiLpController.sol";
import {
    CurveYieldSushiLpOpenFuse,
    CurveYieldSushiLpIncreaseFuse,
    CurveYieldSushiLpWithdrawFuse,
    CurveYieldSushiLpRebalanceFuse,
    CurveYieldSushiLpEmergencyFuse
} from "../src/lp/CurveYieldSushiLpFuses.sol";

interface IVaultT {
    function execute(FuseAction[] calldata) external;
    function addFuses(address[] calldata) external;
    function removeFuses(address[] calldata) external;
    function totalAssets() external view returns (uint256);
    function totalSupply() external view returns (uint256);
    function convertToAssets(uint256) external view returns (uint256);
    function balanceOf(address) external view returns (uint256);
    function deposit(uint256, address) external returns (uint256);
    function approve(address, uint256) external returns (bool);
    function redeemFromRequest(uint256, address, address) external returns (uint256);
    function getFuses() external view returns (address[] memory);
    function updateCallbackHandler(address handler, address sender, bytes4 sig) external;
    function addBalanceFuse(uint256 marketId, address fuse) external;
    function updateDependencyBalanceGraphs(uint256[] calldata marketIds, uint256[][] calldata dependencies) external;
    function grantMarketSubstrates(uint256 marketId, bytes32[] calldata substrates) external;
}

interface IVaultUM {
    function getActiveMarketsInBalanceFuses() external view returns (uint256[] memory);
    function updateMarketsBalances(uint256[] calldata marketIds) external returns (uint256);
}

interface IAccessManagerT {
    function grantRole(uint64, address, uint32) external;
    function hasRole(uint64, address) external view returns (bool, uint32);
}

interface IErc20T {
    function balanceOf(address) external view returns (uint256);
    function approve(address, uint256) external returns (bool);
}

interface ICallerRewardFuseT {
    function setWithdrawManager(address) external;
}

interface IOldWmT {
    function activeRequestedShares() external view returns (uint256);
}

interface ICyAvKatT {
    function convertToShares(uint256) external view returns (uint256);
}

interface IWmReqT {
    function requestShares(uint256) external;
    function requestInfo(address) external view returns (uint256, uint256, bool, uint256, uint256);
}

/// @notice Katana fork tests for Phase 2 step 1 (executor, allocation, Morpho loop set, splitter, WM v2).
/// Run: KATANA_RPC_URL=<rpc> forge test --match-contract Phase2Fork -vv
contract Phase2Fork is LendingForkSetup {
    LendingState internal lendState; // what the live vault looked like before the fork setup
    address internal lendSupplyFuse; // the market 41 supply fuse (live, or installed by L1 on an older fork)
    address constant VAULT = 0xEd83daf48429cfb2C650Fd721b9241e180fd4548;
    address constant AM = 0xd7f408f203c5c6a76c9c55c9f6b015929F151fAA;
    address constant RCM = 0xA77470B748A8Fb50056Ca3c07375dC76Aa3A72Cb;
    address constant WM_OLD = 0x59B340EAb30AFE0cecD51C609d3190e8C75C40AE;
    address constant WM_TEMPLATE = 0x7a0928c0E99e50b2D51C8db7DC400123982687CF;
    address constant CUSTODY = 0xe7D109Ce6b34447Dd45B54e5615F4177291D5ADf;
    address constant LEGACY_VKAT = 0x987C05943855B22552898F032c1AEa7930E340da;
    address constant CALLER_REWARD = 0x70a2f848E21c912D660FE2263E5Be538268A41Ec;
    address constant SWAP_FUSE = 0x1fB8b83bAf40c90F0b450A3fd7A8b2E97Ab2a3Ff;
    address constant MERKL_AH = 0xb62241b19995Dac16D5905050804e1f06caC9704;
    address constant COLLATERAL_FUSE = 0xda9a20690a185DAA3b0fD198C6232234835B6929;
    address constant BORROW_FUSE = 0x08095Aef82A5B33b5B478d254052618A5366cd78;
    address constant FLASH_FUSE = 0x84927bFf2a35a543ed94A7d96D5ccd162a167947;
    address constant BURN_FEE_FUSE = 0x44D368e85f419C59aC01b7270D234d8BF19Df36e;
    address constant AVKAT = 0x7231dbaCdFc968E07656D12389AB20De82FbfCeB;
    address constant KAT = 0x7F1f4b4b29f5058fA32CC7a97141b8D7e5ABDC2d;
    address constant MORPHO = 0xD50F2DffFd62f94Ee4AEd9ca05C61d0753268aBc;
    address constant ESCROW = 0x4d6fC15Ca6258b168225D283262743C623c13Ead;
    bytes32 constant LOOP_MARKET = 0x80e60fe453223b0f84a567724f88190bef708420d24397157067d424429783e9;
    address constant DEPLOYER = 0x11b78837cadC8E894F1c6e13fA9f3A085a75FA35;
    address constant VKAT_NFT = 0x106F7D67Ea25Cb9eFf5064CF604ebf6259Ff296d;
    address constant EXIT_QUEUE = 0x6dE9cAAb658C744aD337Ca5d92D084c97ffF578d;
    address constant EPOCH_CLOCK = 0x17049d374A2bcdA70F8939C21ad92bcF6B2A95ab;
    address constant GAUGE_VOTER = 0x5e755A3C5dc81A79DE7a7cEF192FFA60964c9352;
    address constant DELEGATION = 0xB67Ac05e2C1d8592692a90BF61712274b988f25A;
    address constant GAUGE = 0x744676B3CeD942D78F9b8e9cd22246Db5c32395c;
    CurveYieldVkatController vkat;
    bytes32 constant LEND_MARKET = 0xe0e57a9a96ef56292b1400db02b19995147b1f39ff9dc1673b4618beba1cb159;
    CurveYieldAvkatLendController lend;
    address supplier = makeAddr("supplier");
    address constant NPM = 0x2659C6085D26144117D904C46B48B6d180393d27;
    address constant POOL_1PCT = 0x8640e1867BD563B2Ab865160E77Cb7B875243B13;
    address constant ROUTER = 0x01F9894f92ea9224fECc8C35482E20a05De13582;
    address constant QUOTER = 0x92dea23ED1C683940fF1a2f8fE23FE98C5d3041c;
    CurveYieldSushiLpController lpc;

    CurveYieldLoopProfitSplitter splitter;
    CurveYieldMorphoLoopController loop;
    CurveYieldAllocationController allocation;
    CurveYieldVaultExecutor executor;
    CurveYieldWithdrawalManagerV2 wm;
    CurveYieldMorphoLoopWindupFuse windup;
    address keeper = makeAddr("keeper");
    address user = makeAddr("user");

    function setUp() public {
        vm.createSelectFork(vm.envString("KATANA_RPC_URL"), vm.envUint("FORK_BLOCK"));
        string memory lendPath = _tmpPath("p2fork");
        (lendState, lendSupplyFuse) = _prepareLending(lendPath, "deployments/unused-p2fork.json");
        vm.startPrank(DEPLOYER);

        splitter = new CurveYieldLoopProfitSplitter(
            DEPLOYER, AVKAT, RCM, CUSTODY, CyBound(0, 5_000), [uint16(3_500), 2_000, 2_000, 2_500]
        );
        loop = new CurveYieldMorphoLoopController(DEPLOYER, _env(address(0)), _loopBounds(), _loopParams());
        allocation = new CurveYieldAllocationController(
            DEPLOYER, VAULT, AVKAT, RCM, ESCROW, CyBound(1_000, 5_000), 3_000
        );
        windup = new CurveYieldMorphoLoopWindupFuse(14, VAULT, address(loop), 1e15);
        CyLoopFuses memory f = CyLoopFuses({
            windup: address(windup),
            unwind: address(new CurveYieldMorphoLoopUnwindFuse(14, VAULT, address(loop))),
            ltvRebalance: address(new CurveYieldMorphoLoopLtvRebalanceFuse(14, VAULT, address(loop), 1e15)),
            emergency: address(new CurveYieldMorphoLoopEmergencyFuse(14, VAULT, address(loop)))
        });
        CurveYieldExecutorPayFuse pay = new CurveYieldExecutorPayFuse(VAULT, AVKAT, address(allocation), 50e18);
        CurveYieldProfitSplitFuse splitFuse =
            new CurveYieldProfitSplitFuse(VAULT, AVKAT, address(allocation), address(splitter));

        wm = new CurveYieldWithdrawalManagerV2(AM, WM_TEMPLATE);
        executor = new CurveYieldVaultExecutor(
            DEPLOYER, VAULT, AVKAT,
            CyExecutorDeps({
                allocation: address(allocation),
                withdrawManager: address(wm),
                rewardsClaimManager: RCM,
                merklAutoHarvestFuse: MERKL_AH,
                payFuse: address(pay),
                profitSplitFuse: address(splitFuse),
                kat: KAT
            }),
            CyBound(0, 300), CyBound(0, 100e18), 10, 3e18
        );

        // Loop env points at the new manager (for #11 checks).
        loop = _redeployLoopWithWm(address(wm), f);
        allocation.setSets(CySets({loop: address(loop), vkat: address(0), lend: address(0), lp: address(0), pol: address(0)}));
        allocation.setLegacyVkatFuse(LEGACY_VKAT);
        allocation.setExecutor(address(executor));

        // Vault: fuses, ALPHA for the executor and the new manager.
        // Fresh burn fuse: the live 0x44D3 is a pre-IL-6952 build that reads the old withdraw-manager slot.
        BurnRequestFeeFuse burnFuse = new BurnRequestFeeFuse(type(uint256).max);
        address[] memory add = new address[](8);
        add[7] = address(burnFuse);
        add[0] = loop.fuses().windup;
        add[1] = loop.fuses().unwind;
        add[2] = loop.fuses().ltvRebalance;
        add[3] = loop.fuses().emergency;
        add[4] = address(pay);
        add[5] = address(splitFuse);
        UpdateWithdrawManagerMaintenanceFuse maint = new UpdateWithdrawManagerMaintenanceFuse(0);
        add[6] = address(maint);
        IVaultT(VAULT).addFuses(add);
        // The vault has never had a Morpho flash-loan callback handler: without it every flash unwind reverts
        // (HandlerNotFound), including the live v1 emergencyRepay.
        IVaultT(VAULT).updateCallbackHandler(
            address(new CallbackHandlerMorpho()), MORPHO, bytes4(keccak256("onMorphoFlashLoan(uint256,bytes)"))
        );
        IAccessManagerT(AM).grantRole(200, address(executor), 0);
        IAccessManagerT(AM).grantRole(1000, address(executor), 0); // updateMarketsBalances before loss measurement
        IAccessManagerT(AM).grantRole(200, address(wm), 0);

        // Withdraw manager v2 migration (no open requests on the old manager).
        assertEq(IOldWmT(WM_OLD).activeRequestedShares(), 0, "old manager has open requests");
        wm.updatePlasmaVaultAddress(VAULT);
        wm.updateWithdrawWindow(90 days);
        wm.updateWithdrawFee(0.0125e18);
        wm.updateRequestFee(0.0875e18);
        wm.setProfitCustody(CUSTODY);
        FuseAction[] memory sw = new FuseAction[](1);
        sw[0] = FuseAction(address(maint), abi.encodeWithSignature("enter((address))", address(wm)));
        IVaultT(VAULT).execute(sw);
        ICallerRewardFuseT(CALLER_REWARD).setWithdrawManager(address(wm));
        wm.setDependencies(address(executor), address(burnFuse), CALLER_REWARD, WM_OLD);
        address[] memory rm = new address[](1);
        rm[0] = address(maint);
        IVaultT(VAULT).removeFuses(rm);
        vm.stopPrank();

        // A depositor with avKAT.
        deal(AVKAT, user, 5_000e18);
        vm.startPrank(user);
        IErc20T(AVKAT).approve(VAULT, type(uint256).max);
        IVaultT(VAULT).deposit(2_000e18, user);
        vm.stopPrank();
    }

    // ---------------------------------------------------------------- tests

    function test_deployAssets_windsUpAndSplitsProfit() public {
        CyLoopParams memory p = _loopParams();
        p.rampStartProfitBps = 250;
        p.rampEndProfitBps = 400; // current fuse profit ~4.4% after slippage clears this
        vm.prank(DEPLOYER);
        loop.setParams(p);
        CyLoopSnapshot memory before = loop.snapshot();
        uint256 custodyBefore = IErc20T(AVKAT).balanceOf(CUSTODY);
        uint256 splitterBefore = IErc20T(AVKAT).balanceOf(address(splitter));
        CurveYieldAllocationController.Budgets memory b = allocation.budgets();
        console2.log("managed / idle", b.managed, b.idle);
        console2.log("strategic budget / floor", b.strategicBudget, b.vaultFloor);

        vm.prank(keeper);
        executor.deployAssets();

        CyLoopSnapshot memory afterS = loop.snapshot();
        console2.log("collateral before/after", before.collateralAvkat, afterS.collateralAvkat);
        console2.log("LTV after", afterS.ltvBps);
        assertGt(afterS.collateralAvkat, before.collateralAvkat, "loop did not grow");
        assertLe(afterS.ltvBps, 7_500, "LTV above target");
        assertGe(afterS.ltvBps, 7_400, "LTV not near target");
        assertGt(IErc20T(AVKAT).balanceOf(CUSTODY), custodyBefore, "no growth share");
        assertGt(IErc20T(AVKAT).balanceOf(address(splitter)), splitterBefore, "no contributors share held");
        assertGt(IErc20T(AVKAT).balanceOf(keeper), 0, "no caller reward");
        assertGe(IErc20T(AVKAT).balanceOf(VAULT), b.vaultFloor, "vault floor breached");
    }

    function test_requestsBlockWindup_andReleaseFromIdleWithSameTxFeeBurn() public {
        uint256 shares = IVaultT(VAULT).balanceOf(user) / 4;
        vm.prank(user);
        IWmReqT(address(wm)).requestShares(shares);
        vm.warp(block.timestamp + 60);
        CyLoopSnapshot memory before = loop.snapshot();
        uint256 supplyBefore = IVaultT(VAULT).totalSupply();
        uint256 ppsBefore = IVaultT(VAULT).convertToAssets(1e20);

        vm.prank(keeper);
        executor.deployAssets();

        CyLoopSnapshot memory afterS = loop.snapshot();
        assertLe(afterS.collateralAvkat, before.collateralAvkat, "wound up while requests exist (#11)");
        assertLt(IVaultT(VAULT).totalSupply(), supplyBefore, "fee shares not burned in the release tx (#3b)");
        assertGe(IVaultT(VAULT).convertToAssets(1e20), ppsBefore, "share price dropped");
        (,, bool canWithdraw,,) = IWmReqT(address(wm)).requestInfo(user);
        assertTrue(canWithdraw, "request not released");
    }

    function test_fulfillAll_unwindsLoop_sharePriceDoesNotDrop() public {
        // Request more than idle so the loop has to unwind.
        uint256 idle = IErc20T(AVKAT).balanceOf(VAULT);
        uint256 shares = IVaultT(VAULT).balanceOf(user);
        vm.prank(user);
        IWmReqT(address(wm)).requestShares(shares);
        vm.warp(block.timestamp + 60);
        uint256 needed = IVaultT(VAULT).convertToAssets(shares);
        console2.log("idle / needed", idle, needed);
        // Drain most idle into the loop first so an unwind is required.
        uint256 ppsBefore = IVaultT(VAULT).convertToAssets(1e20);
        CyLoopSnapshot memory before = loop.snapshot();
        uint256 splitterBefore = IErc20T(AVKAT).balanceOf(address(splitter));

        vm.prank(keeper);
        executor.fulfillAll();

        CyLoopSnapshot memory afterS = loop.snapshot();
        console2.log("collateral before/after", before.collateralAvkat, afterS.collateralAvkat);
        console2.log("pps before/after", ppsBefore, IVaultT(VAULT).convertToAssets(1e20));
        assertGe(IVaultT(VAULT).convertToAssets(1e20), ppsBefore, "share price dropped on fulfil (#3b)");
        // Split comes only from profit: here no unwind was needed, so profit <= the fee on the released shares, and the
        // contributors' 20% can be at most 20% of that fee.
        uint256 feeCap = needed * 875 / 10_000;
        uint256 contributors = IErc20T(AVKAT).balanceOf(address(splitter)) - splitterBefore;
        console2.log("fee cap / contributors share", feeCap, contributors);
        assertGt(contributors, 0, "no profit split");
        assertLe(contributors, feeCap * 2_000 / 10_000 + 1, "split exceeded 20% of the fee");
        (,, bool canWithdraw,,) = IWmReqT(address(wm)).requestInfo(user);
        assertTrue(canWithdraw, "request not released");
    }

    /// @notice Idle cannot cover the request, so the loop must unwind. Measures the booked unwind loss vs the 4% buffer.
    function test_fulfillAll_requiringLoopUnwind() public {
        // Big depositor, loop absorbs it (permissive ramp), then the depositor exits via a scheduled request.
        deal(AVKAT, user, 25_000e18);
        vm.prank(user);
        IVaultT(VAULT).deposit(20_000e18, user);
        CyLoopParams memory p = _loopParams();
        p.rampStartProfitBps = 250;
        p.rampEndProfitBps = 400;
        vm.prank(DEPLOYER);
        loop.setParams(p);
        vm.prank(keeper);
        executor.deployAssets();
        uint256 idle = IErc20T(AVKAT).balanceOf(VAULT);

        uint256 shares = IVaultT(VAULT).balanceOf(user);
        vm.prank(user);
        IWmReqT(address(wm)).requestShares(shares);
        vm.warp(block.timestamp + 60);
        uint256 needed = IVaultT(VAULT).convertToAssets(shares);
        console2.log("idle / needed after wind-up", idle, needed);
        uint256 ppsBefore = IVaultT(VAULT).convertToAssets(1e20);
        uint256 collateralBefore = loop.snapshot().collateralAvkat;

        // Allow up to the bound (10%) so a too-high loss surfaces its size in the revert instead of a generic error.
        p.lossBufferBps = 1_000;
        vm.prank(DEPLOYER);
        loop.setParams(p);
        vm.prank(keeper);
        try executor.fulfillAll() {
            console2.log("fulfilled; collateral before/after", collateralBefore, loop.snapshot().collateralAvkat);
            console2.log("pps before/after", ppsBefore, IVaultT(VAULT).convertToAssets(1e20));
            assertGe(IVaultT(VAULT).convertToAssets(1e20), ppsBefore, "share price dropped");
        } catch (bytes memory err) {
            console2.log("fulfillAll reverted (expected when the unwind loss exceeds the fee buffer):");
            console2.logBytes(err);
            assertEq(loop.snapshot().collateralAvkat, collateralBefore, "state changed on revert");
        }
    }

    function test_overTarget_neverReverts() public {
        CyLoopParams memory p = _loopParams();
        p.allocationBps = 5_000; // loop is ~73% of managed: now over target
        vm.prank(DEPLOYER);
        loop.setParams(p);
        uint256 collateralBefore = loop.snapshot().collateralAvkat;
        vm.prank(keeper);
        executor.deployAssets(); // must not revert (#18)
        assertLe(loop.snapshot().collateralAvkat, collateralBefore, "over-target loop grew");
    }

    function test_specDefaults_rampStopsWindupWithoutRevertOrReward() public {
        // #14 defaults: 3% -> 7% over the last 40%. The loop is ~80% of its limit, so ~6%+ is required: no wind-up.
        uint256 collateralBefore = loop.snapshot().collateralAvkat;
        vm.prank(keeper);
        executor.deployAssets();
        assertEq(loop.snapshot().collateralAvkat, collateralBefore, "wound up below required profit");
        assertEq(IErc20T(AVKAT).balanceOf(keeper), 0, "rewarded for no work");
    }

    function test_emergencyDeleveragesToTarget() public {
        // Make the live 75% LTV an "emergency" by lowering target / emergency levels, then de-lever to 70%.
        CyLoopParams memory p = _loopParams();
        p.targetLtvBps = 7_000;
        p.emergencyTargetLtvBps = 7_000;
        p.emergencyLtvBps = 7_400;
        vm.prank(DEPLOYER);
        loop.setParams(p);
        uint256 ltvBefore = loop.snapshot().ltvBps;
        vm.prank(keeper);
        executor.emergencyRepay(0);
        CyLoopSnapshot memory s = loop.snapshot();
        console2.log("LTV before/after emergency", ltvBefore, s.ltvBps);
        assertLe(s.ltvBps, 7_010, "not back near target");
        assertGe(s.ltvBps, 6_900, "over-deleveraged");
    }

    function test_emergencyIsNoopBelowThreshold() public {
        uint256 collateralBefore = loop.snapshot().collateralAvkat;
        vm.prank(keeper);
        executor.emergencyRepay(0);
        assertEq(loop.snapshot().collateralAvkat, collateralBefore);
    }

    function test_paramsOutsideBoundsRevert() public {
        CyLoopParams memory p = _loopParams();
        p.rampZoneBps = 6_000; // bound max 5,000
        vm.prank(DEPLOYER);
        vm.expectRevert();
        loop.setParams(p);
    }

    function test_onlyExecutorCanDriveLoopFuses() public {
        FuseAction[] memory a = new FuseAction[](1);
        a[0] = FuseAction(loop.fuses().windup, abi.encodeWithSignature("enter(uint256)", 1e18));
        vm.prank(DEPLOYER); // holds ALPHA, but is not the executor
        vm.expectRevert();
        IVaultT(VAULT).execute(a);
    }

    // ---------------------------------------------------------------- native-exit lane (spec §2.8)

    function test_nativeExitLane_fullCycle() public {
        _installVkatSet();
        uint256 shares = _bigScheduledRequest();
        uint256 pps0 = IVaultT(VAULT).convertToAssets(1e20);
        uint256 total0 = IVaultT(VAULT).totalAssets();
        assertEq(executor.laneBookedLoss(), 0);

        vm.prank(keeper);
        executor.startNativeExit();
        uint256[] memory prepared = vkat.preparedTokens();
        CyLoopSnapshot memory afterStart = loop.snapshot();
        console2.log("prepared lane NFTs", prepared.length);
        console2.log("loop LTV after start (cap 7620)", afterStart.ltvBps);
        assertGt(prepared.length, 0, "nothing prepared");
        assertLe(afterStart.ltvBps, 7_620, "lane lifted LTV above 76.2%");
        _assertNoStep(pps0, "share price step at start");

        vm.roll(block.number + 1);
        vm.warp(block.timestamp + 2);
        vm.prank(keeper);
        executor.beginNativeExits();
        uint256[] memory exiting = vkat.exitingTokens();
        uint256 ticketKat = vkat.exitingKat();
        console2.log("exit tickets / KAT in tickets", exiting.length, ticketKat);
        assertEq(vkat.preparedTokens().length, 0, "prepared not begun");
        // Market 7 values exiting KAT net of the queue's 2.5% minimum fee, so that fee is booked at begin (not at completion):
        // the share price steps down by at most that fee.
        uint256 fee0 = _avkat(ticketKat) * 250 / 10_000;
        assertGe(
            IVaultT(VAULT).convertToAssets(1e20) + pps0 * fee0 * 101 / 100 / IVaultT(VAULT).totalAssets(), pps0,
            "share price step at begin beyond the 2.5% fee"
        );

        // the measured lane cost (start + begin) is remembered until the exits complete
        uint256 booked = executor.laneBookedLoss();
        uint256 dropBegin = total0 > IVaultT(VAULT).totalAssets() ? total0 - IVaultT(VAULT).totalAssets() : 0;
        console2.log("start+begin totalAssets drop", dropBegin);
        console2.log("laneBookedLoss after begin / 2.5% of the tickets", booked, fee0);
        assertApproxEqRel(booked, fee0, 0.3e18, "booked lane loss != ~2.5% of the tickets (+ start conversion difference)");

        vm.warp(block.timestamp + 60 days + 1);
        uint256 preComplete = _refreshedTotal();
        vm.recordLogs();
        vm.prank(keeper);
        executor.completeNativeExits();
        LaneEvents memory ev = _laneEvents();
        uint256 loss = ev.completedLoss;
        console2.log("completion event loss / fulfilled loss / profit", loss, ev.fulfilledLoss, ev.profit);
        assertEq(executor.laneBookedLoss(), 0, "booked lane loss not consumed by the completion");
        assertGe(loss, booked, "completion loss does not include the booked lane loss");
        assertApproxEqRel(loss, booked, 0.05e18, "completion loss != booked + ~0 measured at completion");
        if (ev.fulfilled) {
            assertEq(ev.fulfilledLoss, loss, "WithdrawalsFulfilled.lossAvkat != the completion loss");
            uint256 feeAssets = ev.feeShares == 0 ? 0 : IVaultT(VAULT).convertToAssets(ev.feeShares);
            console2.log("fee assets (approx) / profit", feeAssets, ev.profit);
            if (feeAssets > loss) assertApproxEqRel(ev.profit + loss, feeAssets, 0.02e18, "profit != fee - loss");
            else assertEq(ev.profit, 0, "profit paid although the loss exceeds the fee");
            // the lane's cost was booked at begin; completion only pays out the profit split (the vault keeps its 20%) + reward
            uint256 dropComplete = preComplete > IVaultT(VAULT).totalAssets() ? preComplete - IVaultT(VAULT).totalAssets() : 0;
            uint256 distributed = ev.profit > ev.reward ? (ev.profit - ev.reward) * 80 / 100 : 0;
            console2.log("completion drop / distributed / reward", dropComplete, distributed, ev.reward);
            assertApproxEqRel(dropComplete, distributed + ev.reward, 0.05e18, "completion drop != distributed profit + reward");
            assertApproxEqRel(dropBegin, booked, 0.3e18, "start+begin drop != booked lane loss");
        }
        CyLoopSnapshot memory done = loop.snapshot();
        console2.log("booked loss avKAT / ticket avKAT", loss, _avkat(ticketKat));
        console2.log("loop LTV after completion", done.ltvBps);
        assertEq(vkat.exitingTokens().length, 0, "tickets left");
        // The fork cannot grow avKAT's conversion rate (~7% per 60 days live), so 60 days of KAT borrow interest are not
        // offset here: the repayment must lower LTV from where the lane left it; reaching 75% (and releasing shares)
        // then depends on avKAT's growth outpacing the interest, which the #15 re-lever also captures.
        assertLt(done.ltvBps, afterStart.ltvBps, "exit KAT did not reduce loop LTV");
        (uint256 reqShares,, bool canWithdraw,,) = IWmReqT(address(wm)).requestInfo(user);
        console2.log("released shares / requested", canWithdraw ? reqShares : 0, shares);
    }

    function test_nativeExitLane_earlyCompletionCallerPaysPremium() public {
        _installVkatSet();
        _bigScheduledRequest();
        uint256 total0 = IVaultT(VAULT).totalAssets();
        assertEq(executor.laneBookedLoss(), 0);
        vm.prank(keeper);
        executor.startNativeExit();
        vm.roll(block.number + 1);
        vm.warp(block.timestamp + 2);
        vm.prank(keeper);
        executor.beginNativeExits();
        uint256 id = vkat.exitingTokens()[0];
        uint256 ticketKat = vkat.exitingKat();
        uint256 booked = executor.laneBookedLoss();
        uint256 dropBegin = total0 > IVaultT(VAULT).totalAssets() ? total0 - IVaultT(VAULT).totalAssets() : 0;
        console2.log("start+begin totalAssets drop", dropBegin);
        console2.log("laneBookedLoss after begin / 2.5% of the ticket", booked, _avkat(ticketKat) * 250 / 10_000);
        assertApproxEqRel(booked, _avkat(ticketKat) * 250 / 10_000, 0.3e18, "booked != ~2.5% of the ticket");

        vm.warp(block.timestamp + 30 days);
        uint256 premium = vkat.earlyExitPremiumKat(id);
        console2.log("day-30 premium KAT / ticket KAT", premium, ticketKat);
        assertApproxEqRel(premium, ticketKat * 1_125 / 10_000, 0.02e18, "premium not ~11.25% (13.75% - 2.5%)");

        deal(KAT, keeper, premium);
        uint256 preComplete = _refreshedTotal();
        vm.startPrank(keeper);
        IErc20T(KAT).approve(address(executor), premium);
        vm.expectRevert();
        executor.completeNativeExitEarly(id, premium - 1); // cap below the quote reverts
        vm.recordLogs();
        executor.completeNativeExitEarly(id, premium);
        vm.stopPrank();
        LaneEvents memory ev = _laneEvents();
        uint256 loss = ev.completedLoss;
        // The vault's 2.5% was booked at begin (market 7 counts exiting KAT net of it) and carried in laneBookedLoss;
        // completing consumes that whole booking (this is the only ticket) and adds ~0 measured loss.
        console2.log("completion loss (booked + measured) / booked", loss, booked);
        assertEq(executor.laneBookedLoss(), 0, "booked lane loss not consumed");
        assertApproxEqRel(loss, booked, 0.05e18, "completion loss != booked + ~0");
        if (ev.fulfilled) {
            assertEq(ev.fulfilledLoss, loss);
            uint256 feeAssets = ev.feeShares == 0 ? 0 : IVaultT(VAULT).convertToAssets(ev.feeShares);
            if (feeAssets > loss) assertApproxEqRel(ev.profit + loss, feeAssets, 0.02e18, "profit != fee - loss");
            else assertEq(ev.profit, 0);
            uint256 dropComplete = preComplete > IVaultT(VAULT).totalAssets() ? preComplete - IVaultT(VAULT).totalAssets() : 0;
            uint256 distributed = ev.profit > ev.reward ? (ev.profit - ev.reward) * 80 / 100 : 0;
            console2.log("completion drop / distributed / reward", dropComplete, distributed, ev.reward);
            assertApproxEqRel(dropComplete, distributed + ev.reward, 0.05e18, "completion drop != distributed profit + reward");
            assertApproxEqRel(dropBegin, booked, 0.3e18, "start+begin drop != booked lane loss");
        }
    }

    function _bigScheduledRequest() internal returns (uint256 shares_) {
        deal(AVKAT, user, 25_000e18);
        vm.prank(user);
        IVaultT(VAULT).deposit(20_000e18, user);
        CyLoopParams memory p = _loopParams();
        p.rampStartProfitBps = 250;
        p.rampEndProfitBps = 400;
        vm.prank(DEPLOYER);
        loop.setParams(p);
        vm.prank(keeper);
        executor.deployAssets();
        shares_ = IVaultT(VAULT).balanceOf(user);
        vm.prank(user);
        IWmReqT(address(wm)).requestShares(shares_);
        vm.warp(block.timestamp + 60);
    }

    function _installVkatSet() internal {
        vm.startPrank(DEPLOYER);
        address[] memory gauges = new address[](1);
        gauges[0] = GAUGE;
        uint256[] memory weights = new uint256[](1);
        weights[0] = 10_000;
        vkat = new CurveYieldVkatController(
            DEPLOYER,
            CyVkatEnv({
                vault: VAULT, avkat: AVKAT, nft: VKAT_NFT, escrow: ESCROW, exitQueue: EXIT_QUEUE,
                epochClock: EPOCH_CLOCK, gaugeVoter: GAUGE_VOTER, delegationAdapter: DELEGATION,
                loopController: address(loop)
            }),
            CyVkatParamBounds({
                allocationBps: CyBound(0, 9_000), nativeExitMaxLtvBps: CyBound(7_500, 7_620), deployWindow: CyBound(0, 7 days)
            }),
            CyVkatParams({allocationBps: 0, nativeExitMaxLtvBps: 7_620, deployWindow: 3 days}),
            gauges, weights
        );
        vkat.setExecutor(address(executor));
        CyVkatFuses memory vf = CyVkatFuses({
            lock: address(new CurveYieldVkatLockFuse(7, VAULT, address(vkat))),
            convert: address(new CurveYieldVkatConvertFuse(7, VAULT, address(vkat))),
            vote: address(new CurveYieldVkatVoteFuse(7, VAULT, address(vkat))),
            exitPrepare: address(new CurveYieldVkatExitPrepareFuse(14, VAULT, address(vkat))),
            exitBegin: address(new CurveYieldVkatExitBeginFuse(7, VAULT, address(vkat))),
            exitComplete: address(new CurveYieldVkatExitCompleteFuse(14, VAULT, address(vkat)))
        });
        vkat.setFuses(vf);
        address[] memory add = new address[](6);
        (add[0], add[1], add[2], add[3], add[4], add[5]) =
            (vf.lock, vf.convert, vf.vote, vf.exitPrepare, vf.exitBegin, vf.exitComplete);
        IVaultT(VAULT).addFuses(add);
        allocation.setSets(CySets({loop: address(loop), vkat: address(vkat), lend: address(0), lp: address(0), pol: address(0)}));
        _refreshErc20Fuse();
        vm.stopPrank();
    }

    function _assertNoStep(uint256 pps0_, string memory what_) internal view {
        assertApproxEqRel(IVaultT(VAULT).convertToAssets(1e20), pps0_, 0.001e18, what_);
    }

    function _avkat(uint256 kat_) internal view returns (uint256) {
        return ICyAvKatT(AVKAT).convertToShares(kat_);
    }

    struct LaneEvents {
        uint256 completedLoss; // NativeExitsCompleted.lossAvkat
        uint256 fulfilledLoss; // WithdrawalsFulfilled.lossAvkat
        uint256 feeShares;
        uint256 profit;
        uint256 reward;
        bool fulfilled;
    }

    function _laneEvents() internal returns (LaneEvents memory e_) {
        bytes32 done = keccak256("NativeExitsCompleted(address,uint256,uint256,uint256)");
        bytes32 ful = keccak256("WithdrawalsFulfilled(address,address,uint256,uint256,uint256,uint256,uint256)");
        Vm.Log[] memory logs = vm.getRecordedLogs();
        for (uint256 i; i < logs.length; ++i) {
            if (logs[i].emitter != address(executor)) continue;
            if (logs[i].topics[0] == done) {
                (, e_.completedLoss,) = abi.decode(logs[i].data, (uint256, uint256, uint256));
            } else if (logs[i].topics[0] == ful) {
                uint256 shares_;
                (shares_, e_.fulfilledLoss, e_.feeShares, e_.profit, e_.reward) =
                    abi.decode(logs[i].data, (uint256, uint256, uint256, uint256, uint256));
                e_.fulfilled = true;
            }
        }
    }

    /// @dev Revalues every market first (interest accrued during a warp is not part of a lane step), then returns totalAssets.
    function _refreshedTotal() internal returns (uint256) {
        uint256[] memory ms = IVaultUM(VAULT).getActiveMarketsInBalanceFuses();
        vm.prank(DEPLOYER); // holds UPDATE_MARKETS_BALANCES
        IVaultUM(VAULT).updateMarketsBalances(ms);
        return IVaultT(VAULT).totalAssets();
    }

    function _laneLoss() internal returns (uint256 loss_) {
        bytes32 sig = keccak256("NativeExitsCompleted(address,uint256,uint256,uint256)");
        Vm.Log[] memory logs = vm.getRecordedLogs();
        for (uint256 i; i < logs.length; ++i) {
            if (logs[i].emitter == address(executor) && logs[i].topics[0] == sig) {
                (, loss_,) = abi.decode(logs[i].data, (uint256, uint256, uint256));
            }
        }
    }

    // ---------------------------------------------------------------- lending set (#13, D3)

    function test_lend_deploysWithinCapAndOwnership() public {
        _installLendSet();
        _outsideSupply(10_000e18);
        vm.prank(keeper);
        executor.deployAssets();
        CurveYieldAvkatLendController.MarketState memory m = lend.marketState();
        uint256 managed = allocation.managedAvkat();
        console2.log("vault lent / market supply / share bps", m.vaultSupply, m.totalSupply, m.vaultShareBps);
        assertGt(m.vaultSupply, 0, "nothing lent");
        assertTrue(m.vaultShareBps <= 2_000 || m.vaultSupply <= 10_000e18, "above 20% ownership beyond the 10k exemption");
        assertLe(m.vaultSupply, managed * 2_000 / 10_000 + 1, "above the 20% cap");
        assertGe(IErc20T(AVKAT).balanceOf(VAULT), allocation.budgets().vaultFloor, "vault floor breached");
    }

    function test_lend_decaysTenPercentPerTwelveHoursWhenTriggered() public {
        _installLendSet();
        _outsideSupply(10_000e18);
        vm.prank(keeper);
        executor.deployAssets();
        uint256 lent0 = lend.marketState().vaultSupply;
        assertGt(lent0, 0, "nothing lent");

        CyLendParams memory p = lend.params();
        p.ownershipTriggerBps = 500; // vault now owns > 5%: #13 trigger fires
        p.ownershipExemptAvkat = 1_000e18; // exemption below the lent amount so ownership decay applies
        vm.prank(DEPLOYER);
        lend.setParams(p);
        assertTrue(lend.marketState().triggered, "trigger not firing");

        vm.prank(keeper);
        executor.rebalance();
        uint256 lent1 = lend.marketState().vaultSupply;
        console2.log("lent before / after first decay", lent0, lent1);
        assertApproxEqRel(lent0 - lent1, lent0 / 10, 0.01e18, "first step not ~10%");

        vm.prank(keeper);
        executor.rebalance();
        assertEq(lend.marketState().vaultSupply, lent1, "reduced again inside the 12h interval");

        vm.warp(block.timestamp + 12 hours + 1);
        vm.prank(keeper);
        executor.rebalance();
        uint256 lent2 = lend.marketState().vaultSupply;
        console2.log("after 12h second decay", lent2);
        assertApproxEqRel(lent1 - lent2, lent1 / 10, 0.02e18, "second step not ~10%");
    }

    function test_lend_isAFulfilSourceBeforeTheLoop() public {
        _installLendSet();
        _outsideSupply(10_000e18);
        // A large depositor; a permissive ramp lets the loop absorb most of it, so idle < what this user owns.
        deal(AVKAT, user, 25_000e18);
        vm.prank(user);
        IVaultT(VAULT).deposit(20_000e18, user);
        CyLoopParams memory lp = _loopParams();
        lp.rampStartProfitBps = 250;
        lp.rampEndProfitBps = 400;
        vm.prank(DEPLOYER);
        loop.setParams(lp);
        vm.prank(keeper);
        executor.deployAssets();
        uint256 lent0 = lend.marketState().vaultSupply;
        uint256 idle = IErc20T(AVKAT).balanceOf(VAULT);
        uint256 collateral0 = loop.snapshot().collateralAvkat;
        // Request what idle covers plus half of what is lent.
        uint256 shares = IVaultT(VAULT).balanceOf(user);
        uint256 wantAssets = idle + lent0 / 2;
        uint256 userAssets = IVaultT(VAULT).convertToAssets(shares);
        uint256 reqShares = wantAssets >= userAssets ? shares : shares * wantAssets / userAssets;
        vm.prank(user);
        IWmReqT(address(wm)).requestShares(reqShares);
        vm.warp(block.timestamp + 60);
        vm.prank(keeper);
        executor.fulfillAll();
        uint256 lent1 = lend.marketState().vaultSupply;
        console2.log("lent before / after fulfil", lent0, lent1);
        (,, bool canWithdraw,,) = IWmReqT(address(wm)).requestInfo(user);
        assertTrue(canWithdraw, "request not released");
        assertLt(lent1, lent0, "lending not used as a source");
        assertEq(loop.snapshot().collateralAvkat, collateral0, "loop touched although lending covered it");
    }

    function test_lend_firstTenThousandExemptFromOwnershipRule() public {
        _installLendSet();
        // Live market: 1.01 avKAT supplied. Without the exemption the vault could add ~0.25 avKAT.
        vm.prank(keeper);
        executor.deployAssets();
        CurveYieldAvkatLendController.MarketState memory m = lend.marketState();
        uint256 cap = allocation.managedAvkat() * 2_000 / 10_000;
        console2.log("lent into the seed market / share bps / cap", m.vaultSupply, m.vaultShareBps, cap);
        assertGt(m.vaultSupply, 1_000e18, "exemption not applied");
        assertLe(m.vaultSupply, 10_000e18, "beyond the exemption");
        assertLe(m.vaultSupply, cap + 1, "above the 20% cap");
        assertFalse(m.ownershipTriggered, "ownership trigger fired inside the exemption");
        vm.prank(keeper);
        executor.rebalance();
        assertEq(lend.marketState().vaultSupply, m.vaultSupply, "decayed inside the exemption");
    }

    function _installLendSet() internal {
        vm.startPrank(DEPLOYER);
        lend = new CurveYieldAvkatLendController(
            DEPLOYER, VAULT, MORPHO, LEND_MARKET,
            CyLendParamBounds({
                capBps: CyBound(0, 5_500), ownershipTriggerBps: CyBound(500, 5_000), decayBps: CyBound(0, 2_500),
                decayInterval: CyBound(1 hours, 48 hours), liquidityFloorBps: CyBound(0, 2_000),
                ownershipExemptAvkat: CyBound(0, 50_000e18)
            }),
            CyLendParams({
                capBps: 2_000, ownershipTriggerBps: 2_000, decayBps: 1_000, decayInterval: 12 hours, liquidityFloorBps: 300,
                ownershipExemptAvkat: 10_000e18
            })
        );
        CurveYieldAvkatLendReduceFuse reduceFuse = new CurveYieldAvkatLendReduceFuse(41, VAULT, address(lend));
        address supplyFuse = lendSupplyFuse; // IPOR MorphoSupplyFuse(41) from the lending JSON (already installed)
        address[] memory add;
        if (supplyFuse == address(0)) {
            supplyFuse = address(new MorphoSupplyFuse(41, MORPHO));
            add = new address[](2);
            (add[0], add[1]) = (supplyFuse, address(reduceFuse));
            bytes32[] memory subs = new bytes32[](1);
            subs[0] = LEND_MARKET;
            IVaultT(VAULT).addFuses(add);
            IVaultT(VAULT).grantMarketSubstrates(41, subs);
        } else {
            add = new address[](1);
            add[0] = address(reduceFuse);
            IVaultT(VAULT).addFuses(add);
        }
        lend.setFuses(supplyFuse, address(reduceFuse));
        lend.setExecutor(address(executor));
        allocation.setSets(CySets({loop: address(loop), vkat: address(0), lend: address(lend), lp: address(0), pol: address(0)}));
        vm.stopPrank();
    }

    /// @notice An outside lender supplies avKAT so market 0x5c60 has room (live it holds only 1.01 avKAT).
    function _outsideSupply(uint256 amount_) internal {
        deal(AVKAT, supplier, amount_);
        vm.startPrank(supplier);
        IErc20T(AVKAT).approve(MORPHO, amount_);
        MarketParams memory mp = IMorpho(MORPHO).idToMarketParams(Id.wrap(LEND_MARKET));
        IMorpho(MORPHO).supply(mp, amount_, 0, supplier, "");
        vm.stopPrank();
    }

    // ---------------------------------------------------------------- Sushi LP set (#19, D3, D4)

    function test_lp_opensAtOptimalRangeWithinTwoToFivePercent() public {
        _installLpSet();
        (int24 lo, int24 hi, bool valid) = lpc.optimalRange();
        console2.log("optimal range lower / upper / KAT share bps");
        console2.logInt(lo);
        console2.logInt(hi);
        console2.log(lpc.holder().katShareBps(lo, hi));
        assertTrue(valid, "no valid range");
        assertGe(lpc.holder().katShareBps(lo, hi), 500, "KAT share under 5%");

        vm.prank(keeper);
        executor.deployAssets();
        CurveYieldSushiLpHolder h = lpc.holder();
        CyLpPosition memory p = h.position();
        uint256 managed = allocation.managedAvkat();
        console2.log("LP basis / value (conversion basis) / close value", p.basisAvkat, lpc.managedAvkat(), lpc.closeValueAvkat());
        console2.log("holder LTV bps / managed", p.ltvBps, managed);
        assertGt(p.tokenId, 0, "no position");
        assertEq(p.tickLower, lo);
        assertEq(p.tickUpper, hi);
        assertApproxEqAbs(p.ltvBps, 7_500, 10, "holder LTV not ~75%");
        assertLe(p.basisAvkat, managed * 200 / 10_000 + 1e18, "above the 2% floor allocation (no yield history yet)");
        assertFalse(lpc.needsRebalance(), "fresh position wants a rebalance");
    }

    function test_lp_withdrawGates_andWithdrawWithLoss() public {
        _installLpSet();
        vm.prank(keeper);
        executor.deployAssets();
        CurveYieldSushiLpHolder h = lpc.holder();
        uint256 basis0 = h.basisAvkat();
        CyLpFuses memory fz = lpc.fuses();

        // Half out through the 1% gate (fresh position: only the 1% pool fee on the KAT side is lost).
        FuseAction[] memory a = new FuseAction[](1);
        a[0] = FuseAction(fz.withdraw, abi.encodeWithSignature("enter(uint256,uint256)", 5_000, 100));
        uint256 idle0 = IErc20T(AVKAT).balanceOf(VAULT);
        vm.prank(address(executor));
        IVaultT(VAULT).execute(a);
        uint256 got = IErc20T(AVKAT).balanceOf(VAULT) - idle0;
        console2.log("half withdrawn: basis share / avKAT returned", basis0 / 2, got);
        assertGe(got * 10_000, (basis0 / 2) * 9_900, "loss above 1% passed the gate");

        // A zero-loss gate must refuse (some cost is always paid).
        a[0] = FuseAction(fz.withdraw, abi.encodeWithSignature("enter(uint256,uint256)", 5_000, 0));
        vm.prank(address(executor));
        vm.expectRevert();
        IVaultT(VAULT).execute(a);

        // Owner-triggered withdrawWithLoss closes everything regardless of cost.
        a[0] = FuseAction(fz.withdraw, abi.encodeWithSignature("enterWithLoss(uint256)", 10_000));
        vm.prank(DEPLOYER);
        IVaultT(VAULT).execute(a);
        assertEq(h.tokenId(), 0, "position not closed");
        assertEq(h.basisAvkat(), 0, "basis not cleared");
    }

    function test_lp_emergencyOnlyAboveTrigger_deleveragesToTarget() public {
        _installLpSet();
        vm.prank(keeper);
        executor.deployAssets();
        CurveYieldSushiLpHolder h = lpc.holder();
        uint256 collateral0 = h.position().collateralAvkat;
        vm.prank(keeper);
        executor.lpEmergency(); // 75% < 76.6%: no-op
        assertEq(h.position().collateralAvkat, collateral0, "acted below the trigger");

        CyLpParams memory p = lpc.params();
        (p.targetLtvBps, p.emergencyTargetLtvBps, p.emergencyLtvBps) = (7_000, 7_000, 7_400);
        vm.prank(DEPLOYER);
        lpc.setParams(p);
        vm.prank(keeper);
        executor.lpEmergency();
        uint256 ltv = h.position().ltvBps;
        console2.log("holder LTV after emergency", ltv);
        assertApproxEqAbs(ltv, 7_000, 15, "not de-levered to the emergency target");
        assertGt(h.tokenId(), 0, "LP should be untouched by the emergency");
    }

    function _installLpSet() internal {
        vm.startPrank(DEPLOYER);
        lpc = new CurveYieldSushiLpController(
            DEPLOYER, VAULT, AVKAT, MORPHO, LEND_MARKET,
            CyLpParamBounds({
                allocationBps: CyBound(0, 5_500), advantageBps: CyBound(0, 50_000), minKatBps: CyBound(0, 2_000),
                lossBps: CyBound(0, 1_000), ltvBps: CyBound(5_000, 7_690), slippageBps: CyBound(0, 100),
                yieldWindow: CyBound(1 days, 30 days)
            }),
            CyLpParams({
                minBps: 200, maxBps: 500, advantageStartBps: 3_000, advantageFullBps: 10_000, minKatBps: 500,
                standardLossBps: 100, scheduledLossBps: 400, targetLtvBps: 7_500, emergencyLtvBps: 7_660,
                emergencyTargetLtvBps: 7_620, slippageBps: 30, yieldWindow: 7 days
            })
        );
        lpc.setExecutor(address(executor));
        CurveYieldSushiLpHolder holder = new CurveYieldSushiLpHolder(
            VAULT, address(lpc), MORPHO, LOOP_MARKET, AVKAT, KAT, NPM, POOL_1PCT, ROUTER, QUOTER
        );
        CyLpFuses memory fz = CyLpFuses({
            open: address(new CurveYieldSushiLpOpenFuse(7, VAULT, address(lpc), AVKAT)),
            increase: address(new CurveYieldSushiLpIncreaseFuse(7, VAULT, address(lpc), AVKAT)),
            withdraw: address(new CurveYieldSushiLpWithdrawFuse(7, VAULT, address(lpc), AVKAT)),
            rebalance: address(new CurveYieldSushiLpRebalanceFuse(7, VAULT, address(lpc), AVKAT)),
            emergency: address(new CurveYieldSushiLpEmergencyFuse(7, VAULT, address(lpc), AVKAT))
        });
        lpc.wire(address(holder), fz);
        address[] memory add = new address[](5);
        (add[0], add[1], add[2], add[3], add[4]) = (fz.open, fz.increase, fz.withdraw, fz.rebalance, fz.emergency);
        IVaultT(VAULT).addFuses(add);
        allocation.setSets(CySets({loop: address(loop), vkat: address(0), lend: address(0), lp: address(lpc), pol: address(0)}));
        _refreshErc20Fuse();
        vm.stopPrank();
    }

    /// @dev Market 7's balance fuse (IPOR ERC20 logic + LP holder + exiting avKAT) reads the LP and vKAT controllers;
    /// deploy it against whichever exist (a stub reports nothing) and swap it in. Call inside a DEPLOYER prank.
    function _refreshErc20Fuse() internal {
        address l = address(lpc) != address(0) ? address(lpc) : address(new StubLpForBalance());
        address v = address(vkat) != address(0) ? address(vkat) : address(new StubVkatForBalance());
        IVaultT(VAULT).addBalanceFuse(7, address(new CurveYieldErc20BalanceFuse(7, l, v, AVKAT, KAT)));
    }

    // ---------------------------------------------------------------- helpers

    function _env(address wm_) internal pure returns (CyLoopEnv memory) {
        return CyLoopEnv({
            vault: VAULT,
            morpho: MORPHO,
            marketId: LOOP_MARKET,
            avkat: AVKAT,
            kat: KAT,
            collateralFuse: COLLATERAL_FUSE,
            borrowFuse: BORROW_FUSE,
            flashLoanFuse: FLASH_FUSE,
            swapFuse: SWAP_FUSE,
            splitter: address(1),
            withdrawManager: wm_ == address(0) ? WM_OLD : wm_
        });
    }

    function _redeployLoopWithWm(address wm_, CyLoopFuses memory)
        internal returns (CurveYieldMorphoLoopController c_)
    {
        CyLoopEnv memory e = _env(wm_);
        e.splitter = address(splitter);
        c_ = new CurveYieldMorphoLoopController(DEPLOYER, e, _loopBounds(), _loopParams());
        c_.setExecutor(address(executor));
        c_.setAllocation(address(allocation));
        CyLoopFuses memory fuses = CyLoopFuses({
            windup: address(new CurveYieldMorphoLoopWindupFuse(14, VAULT, address(c_), 1e15)),
            unwind: address(new CurveYieldMorphoLoopUnwindFuse(14, VAULT, address(c_))),
            ltvRebalance: address(new CurveYieldMorphoLoopLtvRebalanceFuse(14, VAULT, address(c_), 1e15)),
            emergency: address(new CurveYieldMorphoLoopEmergencyFuse(14, VAULT, address(c_)))
        });
        c_.setFuses(fuses);
    }

    function _loopBounds() internal pure returns (CyLoopParamBounds memory) {
        return CyLoopParamBounds({
            allocationBps: CyBound(0, 8_000),
            rampZoneBps: CyBound(0, 5_000),
            profitBps: CyBound(0, 1_000),
            lossBufferBps: CyBound(0, 1_000),
            targetLtvBps: CyBound(5_000, 7_600),
            emergencyLtvBps: CyBound(5_001, 7_690),
            emergencyTargetLtvBps: CyBound(5_000, 7_680),
            ltvRebalanceToleranceBps: CyBound(0, 500),
            reduceLossBps: CyBound(0, 400),
            maxCycles: CyBound(1, 16)
        });
    }

    function _loopParams() internal pure returns (CyLoopParams memory) {
        return CyLoopParams({
            allocationBps: 7_500,
            rampZoneBps: 4_000,
            baseWindupProfitBps: 225,
            rampStartProfitBps: 300,
            rampEndProfitBps: 700,
            minUnwindProfitBps: 40,
            lossBufferBps: 835,
            targetLtvBps: 7_500,
            emergencyLtvBps: 7_660,
            emergencyTargetLtvBps: 7_620,
            ltvRebalanceToleranceBps: 25,
            reduceLossBps: 0,
            maxCycles: 8
        });
    }
}

contract StubLpForBalance {
    function holder() external pure returns (address) {
        return address(0);
    }
}

contract StubVkatForBalance {
    function exitingKat() external pure returns (uint256) {
        return 0;
    }

    function exitMinFeeBps() external pure returns (uint256) {
        return 250;
    }
}
