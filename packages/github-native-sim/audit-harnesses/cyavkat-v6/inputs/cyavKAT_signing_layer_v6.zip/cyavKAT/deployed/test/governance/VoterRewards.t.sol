// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.30;

import {Test} from "forge-std/Test.sol";
import {CurveYieldEngagementToken} from "../../src/governance/CurveYieldEngagementToken.sol";
import {CurveYieldVoterRewards} from "../../src/governance/CurveYieldVoterRewards.sol";
import {CurveYieldVotingLock} from "../../src/governance/CurveYieldVotingLock.sol";
import {GovMockToken, MockTokenVoting} from "./GovMocks.sol";

/// @notice VoterRewards with a mock voting plugin and the real CurveYieldVotingLock.
/// Locks at T0 (day boundary + 1h): ramp start S0 = next day; the proposal snapshot is S0 + 30 days = 50% ramp, so every
/// account's own power at the snapshot is half its locked amount (exact).
contract VoterRewardsTest is Test {
    uint256 constant DAY = 1 days;
    uint256 constant D0 = 20_000 * 1 days;
    uint256 constant S0 = D0 + 1 days;
    uint256 constant SNAP = S0 + 30 days;
    uint256 constant PID = 7;

    GovMockToken cy;
    CurveYieldVotingLock lock;
    MockTokenVoting voting;
    CurveYieldEngagementToken eng;
    CurveYieldVoterRewards vr;

    address a = makeAddr("a"); // self voter, 100 locked -> 50 power
    address b = makeAddr("b"); // delegatee that votes, 200 -> 100 own
    address c = makeAddr("c"); // delegates to b, 60 -> 30
    address d = makeAddr("d"); // delegates to e, 40 -> 20
    address e = makeAddr("e"); // does not vote, 10 -> 5
    address f = makeAddr("f"); // never locked

    function setUp() public {
        vm.warp(D0 + 1 hours);
        cy = new GovMockToken("cy");
        lock = new CurveYieldVotingLock(address(cy), 60 days, "lock", "vlock");
        voting = new MockTokenVoting();
        eng = new CurveYieldEngagementToken(address(this));
        vr = new CurveYieldVoterRewards(address(this), address(voting), address(lock), address(eng));
        eng.setMinter(address(vr), true);

        address[5] memory ws = [a, b, c, d, e];
        uint256[5] memory amounts = [uint256(100e18), 200e18, 60e18, 40e18, 10e18];
        for (uint256 i; i < 5; ++i) {
            cy.mint(ws[i], amounts[i]);
            vm.startPrank(ws[i]);
            cy.approve(address(lock), amounts[i]);
            lock.lock(amounts[i]);
            vm.stopPrank();
        }
        vm.prank(c);
        lock.delegate(b);
        vm.prank(d);
        lock.delegate(e);

        // votes: a and b voted (b carries c's power), e did not. cast = 50 + (100 + 30) = 180
        voting.setProposal(PID, false, true, uint64(SNAP), uint64(SNAP + 7 days), 130e18, 0, 50e18);
        voting.setVote(PID, a, 2);
        voting.setVote(PID, b, 2);
        vm.warp(SNAP + 8 days);
    }

    function _md(uint256 a_, uint256 b_, uint256 c_) internal pure returns (uint256) {
        return a_ * b_ / c_;
    }

    function test_selfVoter_getsPoolTimesOwnOverCast() public {
        assertEq(lock.ownPowerAt(a, SNAP), 50e18);
        (uint256 amt, bool asDelegator) = vr.earned(PID, a);
        assertEq(amt, _md(100e18, 50e18, 180e18));
        assertFalse(asDelegator);
        uint256 got = vr.claim(PID, a);
        assertEq(got, amt);
        assertEq(eng.balanceOf(a), amt);
    }

    function test_delegateeVoter_getsOwnPlusDelegatedInTimesHaircutTimesCut() public {
        assertEq(lock.getPastVotes(b, SNAP), 130e18);
        assertEq(lock.ownPowerAt(b, SNAP), 100e18);
        (uint256 amt, bool asDelegator) = vr.earned(PID, b);
        // weight = own 100 + delegatedIn 30 x 50% x 20% = 103
        assertEq(amt, _md(100e18, 103e18, 180e18));
        assertFalse(asDelegator);
        assertEq(vr.claim(PID, b), amt);
    }

    function test_delegatorOfVotingDelegatee_getsPoolTimesOwnTimesHalfOverCast() public {
        (uint256 amt, bool asDelegator) = vr.earned(PID, c);
        assertTrue(asDelegator);
        assertEq(amt, _md(100e18 * 30e18, 5_000, 10_000 * 180e18));
        assertEq(vr.claim(PID, c), amt);
        assertEq(eng.balanceOf(c), amt);
    }

    function test_delegatorOfNonVotingDelegatee_getsNothing() public {
        (uint256 amt, bool asDelegator) = vr.earned(PID, d);
        assertEq(amt, 0);
        assertTrue(asDelegator);
        vm.expectRevert(CurveYieldVoterRewards.NothingEarned.selector);
        vr.claim(PID, d);
        // and the delegatee itself did not vote: nothing either
        (amt,) = vr.earned(PID, e);
        assertEq(amt, 0);
        vm.expectRevert(CurveYieldVoterRewards.NothingEarned.selector);
        vr.claim(PID, e);
        // an account that never locked
        vm.expectRevert(CurveYieldVoterRewards.NothingEarned.selector);
        vr.claim(PID, f);
    }

    function test_notExecutedProposalGivesNothing() public {
        voting.setProposal(8, false, false, uint64(SNAP), uint64(SNAP + 7 days), 130e18, 0, 50e18);
        voting.setVote(8, a, 2);
        (uint256 amt,) = vr.earned(8, a);
        assertEq(amt, 0);
        vm.expectRevert(CurveYieldVoterRewards.NothingEarned.selector);
        vr.claim(8, a);
        // executed but nobody cast
        voting.setProposal(9, false, true, uint64(SNAP), uint64(SNAP + 7 days), 0, 0, 0);
        (amt,) = vr.earned(9, a);
        assertEq(amt, 0);
    }

    function test_claimOnlyOnce_perProposalAndAccount_anyoneCanClaimForAnyone() public {
        vm.prank(makeAddr("anyone"));
        uint256 got = vr.claim(PID, a);
        assertEq(eng.balanceOf(a), got, "paid to the account, not the caller");
        vm.expectRevert(CurveYieldVoterRewards.AlreadyClaimed.selector);
        vr.claim(PID, a);
        (uint256 amt,) = vr.earned(PID, a);
        assertEq(amt, 0, "earned still positive after the claim");
        // a second proposal is claimable separately
        voting.setProposal(10, false, true, uint64(SNAP), uint64(SNAP + 7 days), 130e18, 0, 50e18);
        voting.setVote(10, a, 3);
        assertEq(vr.claim(10, a), got);
    }

    function test_setParams_bounds_ownerOnly_andChangesRewards() public {
        vm.expectRevert(CurveYieldVoterRewards.OutOfBounds.selector);
        vr.setParams(1_000e18 + 1, 5_000, 2_000);
        vm.expectRevert(CurveYieldVoterRewards.OutOfBounds.selector);
        vr.setParams(100e18, 10_001, 2_000);
        vm.expectRevert(CurveYieldVoterRewards.OutOfBounds.selector);
        vr.setParams(100e18, 5_000, 10_001);
        vm.prank(a);
        vm.expectRevert(abi.encodeWithSignature("OwnableUnauthorizedAccount(address)", a));
        vr.setParams(100e18, 5_000, 2_000);

        vr.setParams(1_000e18, 10_000, 10_000); // maxima are accepted
        // pool 1000, haircut 100%: the voting delegatee takes all delegated-in power, the delegator gets nothing
        (uint256 amtB,) = vr.earned(PID, b);
        assertEq(amtB, _md(1_000e18, 130e18, 180e18));
        vm.expectRevert(CurveYieldVoterRewards.NothingEarned.selector);
        vr.claim(PID, c);
        vr.setParams(0, 5_000, 2_000); // pool 0: nothing to earn
        vm.expectRevert(CurveYieldVoterRewards.NothingEarned.selector);
        vr.claim(PID, a);
    }

    function test_powerIsReadAtTheSnapshot_notNow() public {
        // a unlocks after the snapshot: the reward still uses the snapshot power
        vm.prank(a);
        lock.unlock(100e18);
        (uint256 amt,) = vr.earned(PID, a);
        assertEq(amt, _md(100e18, 50e18, 180e18));
    }
}
