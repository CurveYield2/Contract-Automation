// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.30;

import {Test, console2} from "forge-std/Test.sol";
import {P3_01_DeployGovernanceTokens} from "../../script/P3_01_DeployGovernanceTokens.s.sol";
import {P3_02_DeployDao, DaoAction, IAragonDao, IAragonAdminPlugin, ISafe} from "../../script/P3_02_DeployDao.s.sol";
import {CurveYieldVotingLock} from "../../src/governance/CurveYieldVotingLock.sol";
import {IAragonTokenVoting, AragonProposalParameters, AragonTally, AragonAction, AragonTargetConfig} from "../../src/governance/CurveYieldAragonInterfaces.sol";
import {GovMockTarget} from "./GovMocks.sol";

interface ITokenVotingT {
    function createProposal(
        bytes calldata metadata, DaoAction[] calldata actions, uint256 allowFailureMap, uint64 startDate, uint64 endDate,
        uint8 voteOption, bool tryEarlyExecution
    ) external returns (uint256 proposalId);
    function vote(uint256 proposalId, uint8 voteOption, bool tryEarlyExecution) external;
    function execute(uint256 proposalId) external;
    function canExecute(uint256 proposalId) external view returns (bool);
}

interface IVaultDF {
    function deposit(uint256 assets, address receiver) external returns (uint256);
    function approve(address, uint256) external returns (bool);
    function balanceOf(address) external view returns (uint256);
}

interface IErc20DF {
    function approve(address, uint256) external returns (bool);
}

interface IScriptDF {
    function run() external;
}

/// @notice Runs P3_01 then P3_02 on a Katana fork and proves the DAO works end to end: only the Safe creates proposals,
/// lockers vote once the ramp gives them power, a passed proposal executes through the DAO, the Admin plugin is intact.
/// Bot owners are placeholders. Run: RAYON_NUM_THREADS=2 forge test --match-path test/governance/DaoDeployFork.t.sol -vv
contract DaoDeployForkTest is Test {
    address constant VAULT = 0xEd83daf48429cfb2C650Fd721b9241e180fd4548;
    address constant AVKAT = 0x7231dbaCdFc968E07656D12389AB20De82FbfCeB;
    address constant DEPLOYER = 0x11b78837cadC8E894F1c6e13fA9f3A085a75FA35;
    address constant USER_OWNER = 0x9f2B20A772246960810045905B7daccf960eE288;
    address constant ANY_ADDR = address(type(uint160).max);
    bytes32 constant CREATE_PROPOSAL = keccak256("CREATE_PROPOSAL_PERMISSION");
    bytes32 constant EXECUTE_PROPOSAL = keccak256("EXECUTE_PROPOSAL_PERMISSION");
    string constant P3_PATH = "deployments/tmp-p3-dao-fork.json";

    address safe;
    address dao;
    address tokenVoting;
    address adminPlugin;
    CurveYieldVotingLock lock;
    GovMockTarget target;
    address alice = makeAddr("alice");
    address bob = makeAddr("bob");
    address rnd = makeAddr("rnd");
    address bot1 = makeAddr("bot1");
    address bot2 = makeAddr("bot2");

    function setUp() public {
        vm.createSelectFork(vm.envString("KATANA_RPC_URL"), vm.envUint("FORK_BLOCK"));
        vm.setEnv("PRIVATE_KEY", "0");
        vm.setEnv("PHASE3_DEPLOYMENTS", P3_PATH);
        vm.setEnv("SAFE_OWNER_BOT1", vm.toString(bot1));
        vm.setEnv("SAFE_OWNER_BOT2", vm.toString(bot2));
        IScriptDF(address(new P3_01_DeployGovernanceTokens())).run();
        IScriptDF(address(new P3_02_DeployDao())).run();
        string memory j = vm.readFile(P3_PATH);
        safe = vm.parseJsonAddress(j, ".safe");
        dao = vm.parseJsonAddress(j, ".dao");
        tokenVoting = vm.parseJsonAddress(j, ".tokenVoting");
        adminPlugin = vm.parseJsonAddress(j, ".adminPlugin");
        lock = CurveYieldVotingLock(vm.parseJsonAddress(j, ".votingLock"));
        target = new GovMockTarget(address(this));
    }

    // ---------------------------------------------------------------- helpers

    function _lockAll(address who_, uint256 avkat_) internal {
        deal(AVKAT, who_, avkat_);
        vm.startPrank(who_);
        IErc20DF(AVKAT).approve(VAULT, avkat_);
        uint256 shares = IVaultDF(VAULT).deposit(avkat_, who_);
        IVaultDF(VAULT).approve(address(lock), shares);
        lock.lock(shares);
        vm.stopPrank();
    }

    function _actions() internal view returns (DaoAction[] memory a_) {
        a_ = new DaoAction[](1);
        a_[0] = DaoAction(address(target), 0, abi.encodeCall(GovMockTarget.setter, (42)));
    }

    function _create() internal returns (uint256 id_) {
        vm.roll(block.number + 1); // proposal ids derive from the block number
        vm.prank(safe);
        id_ = ITokenVotingT(tokenVoting).createProposal("", _actions(), 0, 0, 0, 0, false);
    }

    // ---------------------------------------------------------------- deployment

    function test_deployedState_matchesTheRequestedSetup() public view {
        assertEq(ISafe(safe).getThreshold(), 2);
        assertEq(ISafe(safe).getOwners().length, 3);
        assertEq(keccak256(bytes(ISafe(safe).VERSION())), keccak256("1.4.1"));
        // JSON keeps the P3_01 keys and adds the new ones
        string memory j = vm.readFile(P3_PATH);
        assertTrue(vm.parseJsonAddress(j, ".engagementToken") != address(0));
        assertTrue(vm.parseJsonAddress(j, ".engagementRewards") != address(0));
        assertTrue(dao != address(0) && tokenVoting != address(0) && adminPlugin != address(0));
        // permissions: only the Safe creates proposals; the deployer and the second admin run the Admin plugin
        IAragonDao d = IAragonDao(dao);
        assertTrue(d.hasPermission(tokenVoting, safe, CREATE_PROPOSAL, ""));
        assertFalse(d.hasPermission(tokenVoting, rnd, CREATE_PROPOSAL, ""));
        assertFalse(d.hasPermission(tokenVoting, DEPLOYER, CREATE_PROPOSAL, ""));
        assertFalse(d.hasPermission(tokenVoting, ANY_ADDR, CREATE_PROPOSAL, ""));
        assertTrue(d.hasPermission(adminPlugin, DEPLOYER, EXECUTE_PROPOSAL, ""));
        assertTrue(d.hasPermission(adminPlugin, USER_OWNER, EXECUTE_PROPOSAL, ""));
        assertFalse(d.hasPermission(adminPlugin, rnd, EXECUTE_PROPOSAL, ""));
        // anyone may execute a passed proposal
        assertTrue(d.hasPermission(tokenVoting, rnd, EXECUTE_PROPOSAL, ""));
    }

    // ---------------------------------------------------------------- who can create proposals

    function test_onlyTheSafeCreatesProposals() public {
        _lockAll(alice, 1_000e18);
        vm.warp(block.timestamp + 62 days);
        DaoAction[] memory a = _actions();
        vm.prank(rnd);
        vm.expectRevert(); // DaoUnauthorized
        ITokenVotingT(tokenVoting).createProposal("", a, 0, 0, 0, 0, false);
        // a locker with voting power is not enough
        vm.prank(alice);
        vm.expectRevert();
        ITokenVotingT(tokenVoting).createProposal("", a, 0, 0, 0, 0, false);
        vm.prank(DEPLOYER);
        vm.expectRevert();
        ITokenVotingT(tokenVoting).createProposal("", a, 0, 0, 0, 0, false);
        // the Safe can
        uint256 id = _create();
        (bool open, bool executed,,,,,) = IAragonTokenVoting(tokenVoting).getProposal(id);
        assertTrue(open);
        assertFalse(executed);
    }

    // ---------------------------------------------------------------- a proposal end to end

    function test_passedProposalExecutesThroughTheDao() public {
        _lockAll(alice, 700e18);
        _lockAll(bob, 300e18);
        vm.warp(block.timestamp + 62 days); // the 60-day ramp has finished: full power
        assertGt(lock.getVotes(alice), 0);
        uint256 id = _create();

        // power is read at the proposal snapshot: someone locking now cannot vote
        address late = makeAddr("late");
        _lockAll(late, 5_000e18);
        vm.prank(late);
        vm.expectRevert();
        ITokenVotingT(tokenVoting).vote(id, 2, false);

        vm.prank(alice);
        ITokenVotingT(tokenVoting).vote(id, 2, false); // yes 70%
        vm.prank(bob);
        ITokenVotingT(tokenVoting).vote(id, 3, false); // no 30%

        // Standard mode: no early execution even though the outcome is decided
        assertFalse(ITokenVotingT(tokenVoting).canExecute(id));
        vm.expectRevert();
        ITokenVotingT(tokenVoting).execute(id);
        vm.warp(block.timestamp + 3 days);
        assertFalse(ITokenVotingT(tokenVoting).canExecute(id), "executable before the 7-day minimum duration");

        vm.warp(block.timestamp + 5 days); // past the end
        assertTrue(ITokenVotingT(tokenVoting).canExecute(id));
        vm.prank(rnd); // anyone can execute
        ITokenVotingT(tokenVoting).execute(id);
        assertEq(target.value(), 42, "the proposal action did not run");
        assertEq(target.lastCaller(), dao, "the action must come from the DAO");
        (, bool executed,,,,,) = IAragonTokenVoting(tokenVoting).getProposal(id);
        assertTrue(executed);
        vm.expectRevert();
        ITokenVotingT(tokenVoting).execute(id); // once only
    }

    function test_belowSupportThreshold_orNoQuorum_doesNotExecute() public {
        uint256 t = block.timestamp; // explicit time: block.timestamp is cached across vm.warp under via-ir
        _lockAll(alice, 600e18);
        _lockAll(bob, 400e18);
        t += 62 days;
        vm.warp(t);
        uint256 id = _create();
        vm.prank(alice);
        ITokenVotingT(tokenVoting).vote(id, 2, false); // 60% yes < 66%
        vm.prank(bob);
        ITokenVotingT(tokenVoting).vote(id, 3, false);
        t += 8 days;
        vm.warp(t);
        assertFalse(ITokenVotingT(tokenVoting).canExecute(id));
        vm.expectRevert();
        ITokenVotingT(tokenVoting).execute(id);
        assertEq(target.value(), 0);

        // quorum: a 5% holder alone (95% did not vote) is below the 10% participation
        address whale = makeAddr("whale");
        _lockAll(whale, 9_500e18); // now alice+bob are 9.5% of the total locked
        t += 62 days;
        vm.warp(t);
        uint256 id2 = _create();
        vm.prank(bob);
        ITokenVotingT(tokenVoting).vote(id2, 2, false); // 400 of 10,500: under 10% participation
        t += 8 days;
        vm.warp(t);
        (,, AragonProposalParameters memory pp, AragonTally memory tt,,,) = IAragonTokenVoting(tokenVoting).getProposal(id2);
        console2.log("snapshot / total locked at snapshot", pp.snapshotTimepoint, lock.getPastTotalSupply(pp.snapshotTimepoint));
        console2.log("yes / no / abstain", tt.yes, tt.no, tt.abstain);
        console2.log("bob power at snapshot", lock.getPastVotes(bob, pp.snapshotTimepoint));
        assertFalse(ITokenVotingT(tokenVoting).canExecute(id2), "executable below the 10% participation");
    }

    // ---------------------------------------------------------------- the Admin plugin is intact

    function test_adminPluginStillWorks_forBothAdmins() public {
        DaoAction[] memory a = _actions();
        vm.prank(DEPLOYER);
        IAragonAdminPlugin(adminPlugin).executeProposal("", a, 0);
        assertEq(target.value(), 42);
        vm.prank(USER_OWNER);
        IAragonAdminPlugin(adminPlugin).executeProposal("", a, 0);
        vm.prank(rnd);
        vm.expectRevert();
        IAragonAdminPlugin(adminPlugin).executeProposal("", a, 0);
    }

    function test_gasOfTheDeployScript_isLogged() public {
        // setUp already ran P3_01 + P3_02; log the DAO deployment footprint for the report
        console2.log("safe / dao / tokenVoting / admin");
        console2.log(safe);
        console2.log(dao);
        console2.log(tokenVoting);
        console2.log(adminPlugin);
        assertGt(dao.code.length, 0);
    }
}
