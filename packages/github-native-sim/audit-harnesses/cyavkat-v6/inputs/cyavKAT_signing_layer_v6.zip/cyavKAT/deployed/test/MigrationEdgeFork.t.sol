// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.30;

import {Test, console2} from "forge-std/Test.sol";
import {LendingForkSetup} from "./helpers/LendingForkSetup.sol";
import {P2_01_Deploy} from "../script/P2_01_Deploy.s.sol";
import {P2_02_ConfigureVault} from "../script/P2_02_ConfigureVault.s.sol";
import {P2_03_Cutover} from "../script/P2_03_Cutover.s.sol";
import {FuseAction} from "../src/interfaces/CurveYieldPhase2Interfaces.sol";
import {CurveYieldVaultExecutor} from "../src/executor/CurveYieldVaultExecutor.sol";
import {CurveYieldAvkatLendController} from "../src/lend/CurveYieldAvkatLendController.sol";

interface IVaultME {
    function deposit(uint256 assets, address receiver) external returns (uint256);
    function redeem(uint256 shares, address receiver, address owner) external returns (uint256);
    function redeemFromRequest(uint256 shares, address receiver, address owner) external returns (uint256);
    function balanceOf(address) external view returns (uint256);
    function execute(FuseAction[] calldata) external;
}

interface IErc20ME {
    function balanceOf(address) external view returns (uint256);
    function approve(address, uint256) external returns (bool);
}

interface IWmME {
    function requestShares(uint256) external;
    function requestInfo(address) external view returns (uint256, uint256, bool, uint256, uint256);
}

interface IScriptPathsME {
    function setPaths(string calldata, string calldata) external;
    function run() external;
}

/// @notice Migrated-system edge cases (scenarios 5 and 8). Same setup as MigrationFork but with its own deployments
/// file, so the two suites can run in parallel without racing on it.
contract MigrationEdgeFork is LendingForkSetup {
    address constant VAULT = 0xEd83daf48429cfb2C650Fd721b9241e180fd4548;
    address constant AVKAT = 0x7231dbaCdFc968E07656D12389AB20De82FbfCeB;
    bytes32 constant LEND_MARKET = 0xe0e57a9a96ef56292b1400db02b19995147b1f39ff9dc1673b4618beba1cb159;
    string constant PATH = "deployments/fork-migration-edge.json";
    address keeper = makeAddr("keeper");
    address alice = makeAddr("alice");
    address bob = makeAddr("bob");
    CurveYieldVaultExecutor executor;
    CurveYieldAvkatLendController lend;
    address lendSupplyFuse;
    address wm;
    string lendPath;

    function setUp() public {
        vm.createSelectFork(vm.envString("KATANA_RPC_URL"), vm.envUint("FORK_BLOCK"));
        vm.setEnv("PRIVATE_KEY", "0");
        lendPath = _tmpPath("migedge");
        _prepareLending(lendPath, "deployments/unused-migedge.json");
        _run(address(new P2_01_Deploy()));
        _run(address(new P2_02_ConfigureVault()));
        _run(address(new P2_03_Cutover()));
        string memory d = vm.readFile(PATH);
        executor = CurveYieldVaultExecutor(vm.parseJsonAddress(d, ".executor"));
        wm = vm.parseJsonAddress(d, ".withdrawManagerV2");
        lend = CurveYieldAvkatLendController(vm.parseJsonAddress(d, ".lendController"));
        lendSupplyFuse = vm.parseJsonAddress(d, ".lendSupplyFuse");
        for (uint256 i; i < 2; ++i) {
            address u = i == 0 ? alice : bob;
            deal(AVKAT, u, 1_000e18);
            vm.prank(u);
            IErc20ME(AVKAT).approve(VAULT, type(uint256).max);
        }
    }

    function _run(address script_) internal {
        IScriptPathsME(script_).setPaths(PATH, lendPath);
        IScriptPathsME(script_).run();
    }

    // 5. Instant redeem larger than idle goes through the lending instant-withdraw fuse.
    function test_edge05_instantRedeemPullsFromLending() public {
        vm.prank(alice);
        uint256 shares = IVaultME(VAULT).deposit(1_000e18, alice);

        // Lend nearly all idle (what the executor does over time), leaving less idle than alice's redeem.
        uint256 idle = IErc20ME(AVKAT).balanceOf(VAULT);
        FuseAction[] memory a = new FuseAction[](1);
        a[0] = FuseAction(lendSupplyFuse, abi.encodeWithSignature("enter((bytes32,uint256))", LEND_MARKET, idle - 400e18));
        vm.prank(address(executor)); // holds ALPHA after the cutover
        IVaultME(VAULT).execute(a);
        uint256 idleNow = IErc20ME(AVKAT).balanceOf(VAULT);
        uint256 lentBefore = lend.marketState().vaultSupply;
        console2.log("idle / lent before redeem", idleNow, lentBefore);
        assertLt(idleNow, 900e18, "idle still covers the redeem");

        uint256 before = IErc20ME(AVKAT).balanceOf(alice);
        vm.prank(alice);
        IVaultME(VAULT).redeem(shares, alice, alice);
        uint256 got = IErc20ME(AVKAT).balanceOf(alice) - before;
        uint256 lentAfter = lend.marketState().vaultSupply;
        console2.log("received / lent after redeem", got, lentAfter);
        assertApproxEqRel(got, 987.5e18, 0.01e18, "not ~98.75% back");
        assertLt(lentAfter, lentBefore, "lending supply did not decrease");
    }

    // 8. fulfillFor(alice, 0) releases only alice's request.
    function test_edge08_fulfillForReleasesOnlyThatRequester() public {
        vm.prank(alice);
        uint256 aliceShares = IVaultME(VAULT).deposit(1_000e18, alice);
        vm.prank(bob);
        uint256 bobShares = IVaultME(VAULT).deposit(1_000e18, bob);
        vm.prank(alice);
        IWmME(wm).requestShares(aliceShares);
        vm.prank(bob);
        IWmME(wm).requestShares(bobShares);
        vm.warp(block.timestamp + 60);

        vm.prank(keeper);
        executor.fulfillFor(alice, 0);

        (uint256 aliceReleasable,, bool aliceCan,,) = IWmME(wm).requestInfo(alice);
        (uint256 bobReleasable,, bool bobCan,,) = IWmME(wm).requestInfo(bob);
        console2.log("alice releasable / bob releasable", aliceReleasable, bobReleasable);
        assertTrue(aliceCan, "alice not released");
        assertGt(aliceReleasable, 0, "alice has nothing releasable");
        assertFalse(bobCan, "bob released");

        vm.prank(alice);
        IVaultME(VAULT).redeemFromRequest(aliceReleasable, alice, alice);
        vm.prank(bob);
        vm.expectRevert();
        IVaultME(VAULT).redeemFromRequest(bobShares, bob, bob);
    }
}
