// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.30;

import {console2} from "forge-std/Test.sol";
import {LendingForkSetup} from "../helpers/LendingForkSetup.sol";
import {P2_01_Deploy} from "../../script/P2_01_Deploy.s.sol";
import {P2_02_ConfigureVault} from "../../script/P2_02_ConfigureVault.s.sol";
import {P3_01_DeployGovernanceTokens} from "../../script/P3_01_DeployGovernanceTokens.s.sol";
import {P3_02_DeployDao} from "../../script/P3_02_DeployDao.s.sol";
import {P3_03_DeployGovernanceCore} from "../../script/P3_03_DeployGovernanceCore.s.sol";
import {P3_04_ConfigureGate} from "../../script/P3_04_ConfigureGate.s.sol";
import {P3_05_Handover} from "../../script/P3_05_Handover.s.sol";
import {P4_01_CreatePlusVault} from "../../script/P4_01_CreatePlusVault.s.sol";
import {P4_02_DeployPlusStack} from "../../script/P4_02_DeployPlusStack.s.sol";
import {P4_03_ConfigurePlus} from "../../script/P4_03_ConfigurePlus.s.sol";
import {P4_04_DeployRewards} from "../../script/P4_04_DeployRewards.s.sol";
import {P4_05_GovernPhase4} from "../../script/P4_05_GovernPhase4.s.sol";
import {P4_99_RollbackPhase4} from "../../script/P4_99_RollbackPhase4.s.sol";
import {CurveYieldGovernanceGate} from "../../src/governance/CurveYieldGovernanceGate.sol";
import {CurveYieldPlusDepositRouter} from "../../src/plus/CurveYieldPlusDepositRouter.sol";
import {CurveYieldPlusLoopController} from "../../src/plus/CurveYieldPlusLoopController.sol";

interface IScriptG {
    function setPaths(string calldata, string calldata) external;
    function run() external;
}

interface IOwnableG {
    function owner() external view returns (address);
}

interface IAmG {
    function hasRole(uint64 roleId, address account) external view returns (bool, uint32);
}

/// @notice Governance of the Phase 4 contracts on a Katana fork: P2_01, P2_02, P3_01..P3_04, P4_01..P4_04, P3_05, then
/// P4_05 (handover of the Phase 4 contracts and the cyavKAT+ roles to the gate), adversarial calls as the DAO through
/// gate.execute, a fee-authority call through gate.executeProtected, and P4_99 (everything back to the deployer).
/// One test with isolated scenarios (env-driven scripts cannot run in parallel tests); a failing scenario is rolled back
/// and reported, the next one still runs.
/// Run: RAYON_NUM_THREADS=2 forge test --match-path test/plus/Phase4GovernanceFork.t.sol -vv
contract Phase4GovernanceForkTest is LendingForkSetup {
    address constant DEPLOYER = 0x11b78837cadC8E894F1c6e13fA9f3A085a75FA35;
    address constant FEE_SAFE = 0x47623C62f281807D615eeb4A2CEee9d97F9D3C49;

    string p2Path;
    string p3Path;
    string p4Path;
    string lendPath;
    string p3;
    string p4;
    address gate;
    address dao;
    address am; // the cyavKAT+ access manager
    address[] owned;
    string[] ownedKeys;
    string[] fails;

    function setUp() public {
        vm.createSelectFork(vm.envString("KATANA_RPC_URL"), vm.envUint("FORK_BLOCK"));
        vm.setEnv("PRIVATE_KEY", "0");
        p2Path = _tmpPath("p4gov-p2");
        p3Path = _tmpPath("p4gov-p3");
        p4Path = _tmpPath("p4gov-p4");
        lendPath = _tmpPath("p4gov-lend");
        vm.setEnv("PHASE3_DEPLOYMENTS", p3Path);
        vm.setEnv("PHASE4_DEPLOYMENTS", p4Path);
        vm.setEnv("SAFE_OWNER_BOT1", vm.toString(makeAddr("bot1")));
        vm.setEnv("SAFE_OWNER_BOT2", vm.toString(makeAddr("bot2")));
        vm.setEnv("BOT_OPERATOR", vm.toString(makeAddr("operator")));
        _prepareLending(lendPath, p2Path);
        _run(address(new P2_01_Deploy()));
        _run(address(new P2_02_ConfigureVault()));
        IScriptG(address(new P3_01_DeployGovernanceTokens())).run();
        IScriptG(address(new P3_02_DeployDao())).run();
        IScriptG(address(new P3_03_DeployGovernanceCore())).run();
        _run(address(new P3_04_ConfigureGate()));
        _run(address(new P4_01_CreatePlusVault()));
        _run(address(new P4_02_DeployPlusStack()));
        _run(address(new P4_03_ConfigurePlus()));
        _run(address(new P4_04_DeployRewards()));
        _run(address(new P3_05_Handover()));
        _run(address(new P4_05_GovernPhase4()));
        p3 = vm.readFile(p3Path);
        p4 = vm.readFile(p4Path);
        gate = vm.parseJsonAddress(p3, ".governanceGate");
        dao = vm.parseJsonAddress(p3, ".dao");
        am = _a4(".plusAccessManager");
        string[9] memory keys = ["plusController", "plusExecutor", "plusDepositRouter", "plusYieldBooster", "leaderboard",
            "referrals", "specialRewards", "contributorsRewardFuse", "plusRequestFeeFuse"];
        for (uint256 i; i < keys.length; ++i) {
            owned.push(_a4(string.concat(".", keys[i])));
            ownedKeys.push(keys[i]);
        }
    }

    function _run(address script_) internal {
        IScriptG(script_).setPaths(p2Path, lendPath);
        IScriptG(script_).run();
    }

    function _a4(string memory k) internal view returns (address) {
        return vm.parseJsonAddress(p4, k);
    }

    function _has(uint64 role_, address who_) internal view returns (bool has_) {
        (has_,) = IAmG(am).hasRole(role_, who_);
    }

    function _pad(string memory sig_) internal pure returns (bytes memory) {
        return abi.encodePacked(bytes4(keccak256(bytes(sig_))), new bytes(128)); // selector + zero arguments
    }

    /// @dev true when the DAO's gate.execute reverts with ProtectedCall(target, selector)
    function _protectedForDao(address target_, bytes memory data_) internal returns (bool blocked_, string memory why_) {
        vm.prank(dao);
        (bool ok, bytes memory ret) = gate.call(abi.encodeCall(CurveYieldGovernanceGate.execute, (target_, data_)));
        if (ok) return (false, "the DAO's call SUCCEEDED");
        bytes memory expected = abi.encodeWithSelector(CurveYieldGovernanceGate.ProtectedCall.selector, target_, bytes4(data_));
        if (keccak256(ret) == keccak256(expected)) return (true, "");
        return (false, string.concat("reverted, but not ProtectedCall: ", vm.toString(ret)));
    }

    function _mustBeProtected(address target_, string memory sig_, string memory label_) internal {
        (bool blocked, string memory why) = _protectedForDao(target_, _pad(sig_));
        require(blocked, string.concat(label_, " ", sig_, ": ", why));
    }

    // ---------------------------------------------------------------- scenarios

    /// @dev 1: after P4_05, ownership and roles
    function g1_handoverState() external view {
        for (uint256 i; i < owned.length; ++i) {
            require(IOwnableG(owned[i]).owner() == gate, string.concat("not gate-owned: ", ownedKeys[i]));
        }
        uint64[9] memory gateRoles = [uint64(1), 100, 300, 800, 900, 901, 902, 1000, 1200];
        for (uint256 i; i < gateRoles.length; ++i) {
            require(_has(gateRoles[i], gate), string.concat("gate missing role ", vm.toString(uint256(gateRoles[i]))));
        }
        uint64[13] memory deployerRoles = [uint64(1), 100, 200, 300, 400, 500, 600, 800, 900, 901, 902, 1000, 1200];
        for (uint256 i; i < deployerRoles.length; ++i) {
            require(!_has(deployerRoles[i], DEPLOYER), string.concat("deployer still holds role ", vm.toString(uint256(deployerRoles[i]))));
        }
        require(!_has(200, gate), "the gate must not hold ALPHA");
        require(_has(200, _a4(".plusExecutor")), "the executor lost ALPHA");
        require(_has(1000, _a4(".plusExecutor")), "the executor lost role 1000");
        require(_has(800, _a4(".plusDepositRouter")) && _has(1100, _a4(".plusDepositRouter")), "the router lost 800/1100");
        require(_has(1100, _a4(".plusYieldBooster")), "the booster lost 1100");
        require(_has(200, _a4(".plusWithdrawManagerV2")), "WM v2 lost ALPHA (it runs the burn fuse)");
        require(CurveYieldGovernanceGate(gate).isFeeAuthority(FEE_SAFE), "the fee Safe is not the fee authority");
    }

    /// @dev 2: every protected selector of P4_05 _protect(), as the DAO through gate.execute
    function g2_protectedSelectors() external {
        _mustBeProtected(_a4(".leaderboard"), "setAdminReceiver(address)", "leaderboard");
        _mustBeProtected(_a4(".leaderboard"), "setBuySplit(uint16[4])", "leaderboard");
        _mustBeProtected(_a4(".referrals"), "setClaimFee(uint256,address)", "referrals");
        _mustBeProtected(_a4(".plusController"), "setAdminReceiver(address)", "controller");
        _mustBeProtected(_a4(".plusController"), "setProfitSplit(uint16,uint16,uint16,uint16)", "controller");
        _mustBeProtected(_a4(".plusDepositRouter"), "setDepositFee(uint256,uint16[4])", "router");
        _mustBeProtected(_a4(".plusDepositRouter"), "setAdminReceiver(address)", "router");
        _mustBeProtected(_a4(".plusDepositRouter"), "setWhitelisted(address,bool)", "router");
        _mustBeProtected(_a4(".plusWithdrawManagerV2"), "updateWithdrawFee(uint256)", "WM v2");
        _mustBeProtected(_a4(".plusWithdrawManagerV2"), "updateRequestFee(uint256)", "WM v2");
        _mustBeProtected(_a4(".plusWithdrawManagerV2"), "setFeeSplit(address[3],uint16[3],bool)", "WM v2");
        _mustBeProtected(_a4(".plusFeeManager"), "updatePerformanceFee((address,uint256)[])", "fee manager");
        _mustBeProtected(_a4(".plusFeeManager"), "updateManagementFee((address,uint256)[])", "fee manager");
        _mustBeProtected(_a4(".plusFeeManager"), "setDepositFee(uint256)", "fee manager");
        _mustBeProtected(_a4(".plusVault"), "configurePerformanceFee(address,uint256)", "cyavKAT+");
        _mustBeProtected(_a4(".plusVault"), "configureManagementFee(address,uint256)", "cyavKAT+");
        _mustBeProtected(_a4(".specialRewards"), "setAdmin(address,uint256)", "special rewards");
    }

    /// @dev 3: the cyavKAT+ access manager: fee roles, ownership, generic wrappers, and everything not allowlisted
    function g3_accessManager() external {
        for (uint256 i; i < 3; ++i) {
            uint64 r = i == 0 ? uint64(901) : (i == 1 ? uint64(902) : uint64(400));
            (bool blocked, string memory why) = _protectedForDao(
                am, abi.encodeWithSignature("grantRole(uint64,address,uint32)", r, makeAddr("x"), uint32(0))
            );
            require(blocked, string.concat("grantRole(", vm.toString(uint256(r)), ") ", why));
        }
        uint64[5] memory feeRoles = [uint64(7), 400, 500, 901, 902];
        for (uint256 i; i < feeRoles.length; ++i) {
            (bool blocked, string memory why) = _protectedForDao(
                am, abi.encodeWithSignature("revokeRole(uint64,address)", feeRoles[i], address(gate))
            );
            require(blocked, string.concat("revokeRole(", vm.toString(uint256(feeRoles[i])), ") ", why));
        }
        bytes[] memory inner = new bytes[](0);
        (bool b1, string memory w1) = _protectedForDao(am, abi.encodeWithSignature("multicall(bytes[])", inner));
        require(b1, string.concat("multicall ", w1));
        (bool b2, string memory w2) = _protectedForDao(am, abi.encodeWithSignature("execute(address,bytes)", _a4(".plusVault"), hex""));
        require(b2, string.concat("execute ", w2));
        // AM administration outside the allowlist (an unexpected pass is reported with the selector)
        string[8] memory sigs = [
            "setRoleAdmin(uint64,uint64)", "setRoleGuardian(uint64,uint64)", "setGrantDelay(uint64,uint32)",
            "setTargetFunctionRole(address,bytes4[],uint64)", "setTargetAdminDelay(address,uint32)",
            "setTargetClosed(address,bool)", "updateAuthority(address,address)", "cancel(address,address,bytes)"
        ];
        string memory passed;
        for (uint256 i; i < sigs.length; ++i) {
            (bool blocked,) = _protectedForDao(am, _pad(sigs[i]));
            if (!blocked) passed = string.concat(passed, sigs[i], " ");
        }
        require(bytes(passed).length == 0, string.concat("the DAO can call on the cyavKAT+ AM: ", passed));
    }

    /// @dev 3b: renounceRole(role, gate) through the gate: the AM allows any account to renounce its own role, and the gate is the account
    function g3b_daoCannotRenounceTheGatesRoles() external {
        uint64[9] memory roles = [uint64(1), 100, 300, 800, 900, 901, 902, 1000, 1200];
        string memory passed;
        for (uint256 i; i < roles.length; ++i) {
            vm.prank(dao);
            (bool ok,) = gate.call(abi.encodeCall(CurveYieldGovernanceGate.execute, (am, abi.encodeWithSignature("renounceRole(uint64,address)", roles[i], gate))));
            if (ok) passed = string.concat(passed, vm.toString(uint256(roles[i])), " ");
        }
        require(bytes(passed).length == 0, string.concat("the DAO made the gate renounce roles: ", passed));
    }

    /// @dev 4: ownership of every gated contract cannot be moved or renounced by the DAO, and the gate cannot be re-pointed
    function g4_ownershipMoves() external {
        for (uint256 i; i < owned.length; ++i) {
            (bool blocked, string memory why) = _protectedForDao(owned[i], abi.encodeWithSignature("transferOwnership(address)", makeAddr("attacker")));
            require(blocked, string.concat("transferOwnership ", ownedKeys[i], ": ", why));
            (blocked, why) = _protectedForDao(owned[i], abi.encodeWithSignature("renounceOwnership()"));
            require(blocked, string.concat("renounceOwnership ", ownedKeys[i], ": ", why));
        }
    }

    /// @dev 5: normal (unprotected) DAO calls work, protected ones work for the fee authority through executeProtected
    function g5_normalAndFeeAuthorityCalls() external {
        CurveYieldPlusLoopController c = CurveYieldPlusLoopController(_a4(".plusController"));
        // a DAO call on an unprotected setter: the controller's executor
        vm.prank(dao);
        CurveYieldGovernanceGate(gate).execute(address(c), abi.encodeWithSignature("setExecutor(address)", _a4(".plusExecutor")));
        require(c.executor() == _a4(".plusExecutor"), "the DAO could not call an unprotected controller setter");
        // the deposit fee is protected: the fee Safe changes it through executeProtected, the DAO cannot
        CurveYieldPlusDepositRouter r = CurveYieldPlusDepositRouter(_a4(".plusDepositRouter"));
        uint16[4] memory split = [uint16(2_000), 2_500, 2_500, 3_000];
        vm.prank(FEE_SAFE);
        CurveYieldGovernanceGate(gate).executeProtected(address(r), abi.encodeCall(r.setDepositFee, (3_000, split)));
        require(r.depositFeeBps() == 3_000, "the fee authority could not change the deposit fee");
        // a DAO role grant on an unprotected role the gate administers (WHITELIST 800)
        address someone = makeAddr("someone");
        vm.prank(dao);
        CurveYieldGovernanceGate(gate).execute(am, abi.encodeWithSignature("grantRole(uint64,address,uint32)", uint64(800), someone, uint32(0)));
        require(_has(800, someone), "the DAO could not grant an unprotected role");
    }

    /// @dev 6: P4_99 puts everything back under the deployer, roles included
    function g6_rollback() external {
        _run(address(new P4_99_RollbackPhase4()));
        for (uint256 i; i < owned.length; ++i) {
            require(IOwnableG(owned[i]).owner() == DEPLOYER, string.concat("not rolled back: ", ownedKeys[i]));
        }
        uint64[8] memory roles = [uint64(1), 100, 300, 900, 901, 902, 1000, 1200];
        for (uint256 i; i < roles.length; ++i) {
            require(_has(roles[i], DEPLOYER), string.concat("deployer missing role ", vm.toString(uint256(roles[i]))));
        }
        // the deployer can act again: an owner-only setter
        CurveYieldPlusDepositRouter r = CurveYieldPlusDepositRouter(_a4(".plusDepositRouter"));
        vm.prank(DEPLOYER);
        r.setWhitelisted(makeAddr("z"), true);
        require(r.isWhitelisted(makeAddr("z")), "the deployer cannot use the router after the rollback");
        // the executor keeps ALPHA, the gate keeps its roles (the rollback only adds the deployer)
        require(_has(200, _a4(".plusExecutor")), "the executor lost ALPHA in the rollback");
        console2.log("rollback complete; the Aragon Admin plugin was never touched");
    }

    // ---------------------------------------------------------------- driver

    function _runS(string memory name, bytes4 sel) internal {
        uint256 snap = vm.snapshot();
        (bool ok, bytes memory ret) = address(this).call(abi.encodeWithSelector(sel));
        if (ok) {
            console2.log("PASS", name);
            return;
        }
        string memory why = ret.length == 0 ? "(empty revert data)" : (bytes4(ret) == 0x08c379a0 ? abi.decode(_tail(ret), (string)) : vm.toString(ret));
        vm.revertTo(snap);
        console2.log("FAIL", name);
        console2.log("   ", why);
        fails.push(string.concat(name, ": ", why));
    }

    function _tail(bytes memory b) internal pure returns (bytes memory out) {
        out = new bytes(b.length - 4);
        for (uint256 i; i < out.length; ++i) out[i] = b[i + 4];
    }

    function test_phase4Governance() public {
        _runS("1 handover state: 9 contracts gate-owned, gate/deployer/executor/router/booster roles", this.g1_handoverState.selector);
        _runS("2 every protected selector reverts ProtectedCall for the DAO", this.g2_protectedSelectors.selector);
        _runS("3 cyavKAT+ AM: fee roles, multicall/execute wrappers, non-allowlisted admin calls", this.g3_accessManager.selector);
        _runS("3b the DAO cannot make the gate renounce its cyavKAT+ roles", this.g3b_daoCannotRenounceTheGatesRoles.selector);
        _runS("4 ownership transfer / renounce of every gated contract", this.g4_ownershipMoves.selector);
        _runS("5 normal DAO calls work; the fee authority uses executeProtected", this.g5_normalAndFeeAuthorityCalls.selector);
        _runS("6 P4_99 rollback returns everything to the deployer", this.g6_rollback.selector);
        if (fails.length != 0) {
            string memory all;
            for (uint256 i; i < fails.length; ++i) all = string.concat(all, "\n  ", fails[i]);
            revert(string.concat("failed scenarios:", all));
        }
    }
}
