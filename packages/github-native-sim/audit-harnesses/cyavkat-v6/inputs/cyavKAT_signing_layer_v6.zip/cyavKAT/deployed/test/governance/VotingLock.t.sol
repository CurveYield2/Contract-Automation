// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.30;

import {Test, console2} from "forge-std/Test.sol";
import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {CurveYieldVotingLock} from "../../src/governance/CurveYieldVotingLock.sol";

contract MockCyavkat is ERC20 {
    constructor() ERC20("cyavKAT", "cyavKAT") {}

    function mint(address to_, uint256 amount_) external {
        _mint(to_, amount_);
    }
}

/// @notice Unit tests for CurveYieldVotingLock (no fork).
/// Run: forge test --match-path test/governance/VotingLock.t.sol -vv
contract VotingLockTest is Test {
    uint256 constant DAY = 1 days;
    uint256 constant RAMP = 60 days;
    uint256 constant D0 = 20_000 * 1 days; // a day boundary

    MockCyavkat token;
    CurveYieldVotingLock lock;
    uint256 T0; // day boundary + 1 hour
    uint256 S0; // the ramp start a lock made at T0 gets: the next day boundary

    address a = makeAddr("a");
    address b = makeAddr("b");
    address c = makeAddr("c");
    address d = makeAddr("d");
    address e = makeAddr("e");
    address[5] accts;

    function setUp() public {
        vm.warp(D0 + 1 hours);
        T0 = block.timestamp;
        S0 = D0 + DAY;
        token = new MockCyavkat();
        lock = new CurveYieldVotingLock(address(token), RAMP, "cyavKAT Voting Lock", "vcyavKAT");
        accts = [a, b, c, d, e];
        for (uint256 i; i < 5; ++i) {
            token.mint(accts[i], 1e30);
            vm.prank(accts[i]);
            token.approve(address(lock), type(uint256).max);
        }
    }

    function _lock(address who_, uint256 amount_) internal {
        vm.prank(who_);
        lock.lock(amount_);
    }

    function _ramp(uint256 amount_, uint256 start_, uint256 t_) internal pure returns (uint256) {
        if (t_ <= start_) return 0;
        uint256 el = t_ - start_;
        return el >= RAMP ? amount_ : amount_ * el / RAMP;
    }

    function _ceilDay(uint256 t_) internal pure returns (uint256) {
        return (t_ + DAY - 1) / DAY * DAY;
    }

    // ---------------------------------------------------------------- 1. ramp

    function test_1_ramp() public {
        _lock(a, 100e18);
        (uint256 amt, uint256 start,) = lock.accountAt(a, T0);
        assertEq(amt, 100e18);
        assertEq(start, S0, "start not the next day boundary");

        uint256[7] memory ts = [
            T0, S0 - 1, S0, S0 + 1 days, S0 + 30 days, S0 + RAMP, S0 + 200 days
        ];
        uint256[7] memory seen;
        for (uint256 i; i < ts.length; ++i) {
            vm.warp(ts[i]);
            seen[i] = lock.getVotes(a);
            assertEq(seen[i], _ramp(100e18, S0, ts[i]), "ramp value");
        }
        assertEq(seen[0], 0, "power at lock time");
        assertEq(seen[1], 0, "power before the day boundary");
        assertEq(seen[2], 0, "power at the start");
        assertEq(seen[4], 50e18, "half at start + 30d");
        assertEq(seen[5], 100e18, "full at start + 60d");
        assertEq(seen[6], 100e18, "full after 200d");
        // Past lookups read later return the same values.
        for (uint256 i; i < ts.length; ++i) {
            assertEq(lock.getPastVotes(a, ts[i]), seen[i], "past value changed");
        }
        // A future timepoint is capped at now.
        assertEq(lock.getPastVotes(a, block.timestamp + 5 days), 100e18);
    }

    // ---------------------------------------------------------------- 2. weighted start

    function test_2_weightedStart() public {
        _lock(a, 100e18);
        uint256 t1 = T0 + 29 days;
        vm.warp(t1);
        uint256 votes1 = lock.getVotes(a);
        assertEq(votes1, _ramp(100e18, S0, t1));

        vm.warp(T0 + 30 days);
        uint256 nowTs = block.timestamp;
        _lock(a, 100e18);
        uint256 s1 = _ceilDay((100e18 * S0 + 100e18 * nowTs) / 200e18);
        (uint256 amt, uint256 start,) = lock.accountAt(a, nowTs);
        assertEq(amt, 200e18);
        assertEq(start, s1, "weighted start");
        assertEq(lock.getVotes(a), _ramp(200e18, s1, nowTs), "power follows the new function");

        // Past lookups before the second lock are unchanged.
        assertEq(lock.getPastVotes(a, t1), votes1, "past changed at t1");
        assertEq(lock.getPastVotes(a, nowTs - 1), _ramp(100e18, S0, nowTs - 1), "past changed just before the second lock");
        assertEq(lock.getPastVotes(a, S0), 0);

        vm.warp(nowTs + 10 days);
        assertEq(lock.getVotes(a), _ramp(200e18, s1, block.timestamp));
        vm.warp(s1 + RAMP);
        assertEq(lock.getVotes(a), 200e18);
        vm.warp(s1 + RAMP + 500 days);
        assertEq(lock.getVotes(a), 200e18);
    }

    // ---------------------------------------------------------------- 3. unlock

    function test_3_unlock() public {
        _lock(a, 100e18);
        vm.warp(S0 + 30 days);
        assertEq(lock.getVotes(a), 50e18);
        uint256 before = token.balanceOf(a);
        vm.prank(a);
        lock.unlock(50e18);
        assertEq(lock.getVotes(a), 25e18, "power not halved immediately");
        assertEq(token.balanceOf(a) - before, 50e18, "tokens not returned");
        assertEq(lock.lockedOf(a), 50e18);
        // ramp keeps its start: full power of the remaining 50 at start + 60d
        vm.warp(S0 + RAMP);
        assertEq(lock.getVotes(a), 50e18);

        vm.prank(a);
        vm.expectRevert(abi.encodeWithSelector(CurveYieldVotingLock.InsufficientLocked.selector, 50e18, 60e18));
        lock.unlock(60e18);

        vm.prank(a);
        lock.unlock(50e18);
        assertEq(lock.getVotes(a), 0);
        assertEq(lock.lockedOf(a), 0);
    }

    // ---------------------------------------------------------------- 4. delegation

    function test_4_delegation() public {
        _lock(a, 100e18);
        _lock(b, 50e18);

        vm.warp(S0 + 15 days);
        assertEq(lock.getVotes(a), 25e18);
        assertEq(lock.getVotes(b), 12.5e18);
        vm.prank(a);
        lock.delegate(b);
        assertEq(lock.getVotes(b), 37.5e18, "B = rampA + rampB");
        assertEq(lock.getVotes(a), 0, "A still has votes");
        assertEq(lock.delegates(a), b);
        assertEq(lock.ownPowerAt(a, block.timestamp), 25e18, "own power of A");
        (,, address del) = lock.accountAt(a, block.timestamp);
        assertEq(del, b);

        vm.warp(S0 + 30 days);
        assertEq(lock.getVotes(b), 75e18);
        assertEq(lock.getVotes(a), 0);
        assertEq(lock.ownPowerAt(a, block.timestamp), 50e18);

        // Re-delegate to C mid-ramp.
        vm.prank(a);
        lock.delegate(c);
        assertEq(lock.getVotes(b), 25e18, "B keeps only its own ramp");
        assertEq(lock.getVotes(c), 50e18, "C gets A's ramp");
        assertEq(lock.getVotes(a), 0);
        assertEq(lock.delegates(a), c);
        (,, del) = lock.accountAt(a, block.timestamp);
        assertEq(del, c);
        // Earlier lookups unchanged.
        assertEq(lock.getPastVotes(b, S0 + 15 days), 37.5e18, "past of B changed");
        assertEq(lock.getPastVotes(b, S0 + 10 days), _ramp(50e18, S0, S0 + 10 days), "B before A delegated");
        assertEq(lock.getPastVotes(a, S0 + 10 days), _ramp(100e18, S0, S0 + 10 days), "A before delegating");
        assertEq(lock.getPastVotes(c, S0 + 15 days), 0);
        (,, del) = lock.accountAt(a, S0 + 20 days);
        assertEq(del, b, "delegatee history");

        // delegate(0) returns to self.
        vm.warp(S0 + 45 days);
        assertEq(lock.getVotes(c), 75e18);
        vm.prank(a);
        lock.delegate(address(0));
        assertEq(lock.delegates(a), a);
        assertEq(lock.getVotes(a), 75e18);
        assertEq(lock.getVotes(c), 0);
        assertEq(lock.getVotes(b), 37.5e18);
        vm.warp(S0 + RAMP);
        assertEq(lock.getVotes(a), 100e18);
        assertEq(lock.getVotes(b), 50e18);
    }

    // ---------------------------------------------------------------- 5. many accounts

    function _sumDelegatees(uint256 t_) internal view returns (uint256 s_) {
        for (uint256 i; i < 5; ++i) s_ += lock.getPastVotes(accts[i], t_);
    }

    function _sumOwn(uint256 t_) internal view returns (uint256 s_) {
        for (uint256 i; i < 5; ++i) s_ += lock.ownPowerAt(accts[i], t_);
    }

    function _checkInvariant(uint256 t_) internal view {
        uint256 x = _sumDelegatees(t_);
        uint256 y = _sumOwn(t_);
        uint256 diff = x > y ? x - y : y - x;
        assertLe(diff, 5, "sum of delegatee votes != sum of own power");
    }

    /// @dev Random lock / partial unlock / delegate operations with random warps; returns the timestamps visited.
    function _run(uint256 seed_, uint256 ops_) internal returns (uint256[] memory times_) {
        times_ = new uint256[](ops_);
        for (uint256 i; i < ops_; ++i) {
            uint256 h = uint256(keccak256(abi.encode(seed_, i)));
            vm.warp(block.timestamp + (h >> 24) % (20 days + 1));
            address who = accts[h % 5];
            uint256 op = (h >> 8) % 3;
            if (op == 0) {
                _lock(who, 1e18 + (h >> 40) % 1_000e18);
            } else if (op == 1) {
                uint256 locked = lock.lockedOf(who);
                if (locked != 0) {
                    vm.prank(who);
                    lock.unlock(1 + (h >> 40) % locked);
                }
            } else {
                uint256 k = (h >> 16) % 6;
                vm.prank(who);
                lock.delegate(k == 5 ? address(0) : accts[k]);
            }
            times_[i] = block.timestamp;
        }
    }

    function _checkAll(uint256[] memory times_) internal {
        for (uint256 i; i < times_.length; ++i) {
            _checkInvariant(times_[i]);
            if (times_[i] > T0 + 1) _checkInvariant(times_[i] - 1);
        }
        // and at later points, as the ramps finish
        uint256 last = block.timestamp;
        for (uint256 k = 1; k <= 12; ++k) {
            vm.warp(last + k * 10 days);
            _checkInvariant(block.timestamp);
        }
    }

    function test_5_manyAccountsScripted() public {
        _lock(a, 100e18);
        vm.warp(block.timestamp + 3 days);
        _lock(b, 250e18);
        vm.prank(a);
        lock.delegate(c);
        vm.warp(block.timestamp + 7 days);
        _lock(c, 40e18);
        vm.prank(b);
        lock.delegate(d);
        vm.warp(block.timestamp + 2 days);
        _lock(d, 500e18);
        vm.prank(a);
        lock.unlock(30e18);
        vm.warp(block.timestamp + 11 days);
        _lock(e, 75e18);
        vm.prank(e);
        lock.delegate(a);
        vm.prank(c);
        lock.delegate(e);
        vm.warp(block.timestamp + 5 days);
        vm.prank(b);
        lock.unlock(100e18);
        vm.prank(d);
        lock.delegate(address(0));
        _lock(a, 20e18);

        vm.warp(block.timestamp + 90 days);
        for (uint256 t = T0; t <= block.timestamp; t += 1 days + 7 hours) _checkInvariant(t);
    }

    function testFuzz_5_invariantHolds(uint256 seed_) public {
        uint256[] memory times = _run(seed_, 14);
        _checkAll(times);
    }

    // ---------------------------------------------------------------- 6. supply

    function test_6_totalSupplyIsLockedNotRamped() public {
        assertEq(lock.getPastTotalSupply(0), 0);
        assertEq(lock.getPastVotes(a, 0), 0, "past votes at 0");
        assertEq(lock.getPastVotes(a, T0), 0);

        // Timestamps are explicit: reading block.timestamp after vm.warp inside one function can return a stale value
        // under via-ir.
        uint256 t1 = T0;
        _lock(a, 100e18);
        uint256 t2 = t1 + 3 days;
        vm.warp(t2);
        _lock(b, 50e18);
        uint256 t3 = t2 + 5 days;
        vm.warp(t3);
        vm.prank(a);
        lock.unlock(30e18);
        vm.warp(t3 + 100 days);

        assertEq(lock.getPastTotalSupply(t1 - 1), 0);
        assertEq(lock.getPastTotalSupply(t1), 100e18);
        assertEq(lock.getPastTotalSupply(t2 - 1), 100e18);
        assertEq(lock.getPastTotalSupply(t2), 150e18);
        assertEq(lock.getPastTotalSupply(t3 - 1), 150e18);
        assertEq(lock.getPastTotalSupply(t3), 120e18);
        assertEq(lock.getPastTotalSupply(block.timestamp), 120e18);
        assertEq(lock.totalSupply(), 120e18);
        assertEq(lock.getPastTotalSupply(0), 0);
        assertEq(lock.getPastVotes(a, 0), 0);
        assertEq(lock.getPastVotes(b, 0), 0);
        // ramped power is below locked early on
        assertLt(lock.getPastVotes(a, t1 + 1 days), 100e18);
    }

    // ---------------------------------------------------------------- 7. non-transferable, clock

    function test_7_nonTransferableAndClock() public {
        _lock(a, 100e18);
        vm.startPrank(a);
        vm.expectRevert(CurveYieldVotingLock.NonTransferable.selector);
        lock.transfer(b, 1e18);
        vm.expectRevert(CurveYieldVotingLock.NonTransferable.selector);
        lock.transferFrom(a, b, 1e18);
        vm.expectRevert(CurveYieldVotingLock.NonTransferable.selector);
        lock.approve(b, 1e18);
        vm.stopPrank();
        assertEq(uint256(lock.clock()), block.timestamp);
        assertEq(lock.CLOCK_MODE(), "mode=timestamp");
        vm.warp(block.timestamp + 12345);
        assertEq(uint256(lock.clock()), block.timestamp);
        assertEq(lock.balanceOf(a), 100e18);
        assertEq(lock.allowance(a, b), 0);
        assertEq(lock.decimals(), 18);
    }

    // ---------------------------------------------------------------- 8. gas

    function test_8_gasPastVotesNinetyDaysAfterLastCheckpoint() public {
        _lock(a, 100e18);
        vm.warp(T0 + 90 days);
        uint256 g = gasleft();
        uint256 v = lock.getPastVotes(a, block.timestamp);
        uint256 used = g - gasleft();
        console2.log("getPastVotes, last checkpoint 90 days earlier: gas", used);
        assertEq(v, 100e18);
        // a lookup in the middle of the ramp for comparison
        g = gasleft();
        lock.getPastVotes(a, S0 + 30 days);
        console2.log("getPastVotes at start + 30d: gas", g - gasleft());
    }
}
