// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.30;

import {Test, console2} from "forge-std/Test.sol";
import {MessageHashUtils} from "@openzeppelin/contracts/utils/cryptography/MessageHashUtils.sol";
import {FuseAction} from "../src/interfaces/CurveYieldPhase2Interfaces.sol";
import {CurveYieldVaultBase1271} from "../src/katana/CurveYieldVaultBase1271.sol";
import {CurveYieldSignatureFuse} from "../src/katana/CurveYieldSignatureFuse.sol";

interface IVaultQ {
    function execute(FuseAction[] calldata calls) external;
    function addFuses(address[] calldata fuses) external;
    function removeFuses(address[] calldata fuses) external;
    function isFuseSupported(address fuse) external view returns (bool);
    function PLASMA_VAULT_BASE() external view returns (address);
    function totalAssets() external view returns (uint256);
    function totalSupply() external view returns (uint256);
    function getAccessManagerAddress() external view returns (address);
    function isValidSignature(bytes32 hash, bytes calldata signature) external view returns (bytes4);
    function isQuestSigner(address signer) external view returns (bool);
    function questSignPrefix() external view returns (bytes memory);
    function cap() external view returns (uint256);
    function deposit(uint256 assets, address receiver) external returns (uint256);
    function redeem(uint256 shares, address receiver, address owner) external returns (uint256);
    function withdraw(uint256 assets, address receiver, address owner) external returns (uint256);
    function balanceOf(address who) external view returns (uint256);
    function transfer(address to, uint256 amount) external returns (bool);
    function approve(address spender, uint256 amount) external returns (bool);
}

interface IErc20Q {
    function balanceOf(address) external view returns (uint256);
    function approve(address, uint256) external returns (bool);
}

interface IAmQ {
    function hasRole(uint64 roleId, address account) external view returns (bool, uint32);
}

/// @notice Fork tests for the Katana-quest ERC-1271 signing wrapper (CurveYieldVaultBase1271 + CurveYieldSignatureFuse)
/// installed on the live cyavKAT vault. Deploys the two contracts directly in setUp (as K1_QuestSigning does), pranking
/// DEPLOYER for addFuses/execute instead of running the script, so nothing here touches deployments/katana-quests.json.
/// Run: KATANA_RPC_URL=<rpc> FORK_BLOCK=<n> forge test --match-contract QuestSigningFork -vv
contract QuestSigningFork is Test {
    bytes4 constant MAGIC = 0x1626ba7e;
    bytes4 constant INVALID = 0xffffffff;

    address constant VAULT = 0xEd83daf48429cfb2C650Fd721b9241e180fd4548;
    address constant AM = 0xd7f408f203c5c6a76c9c55c9f6b015929F151fAA;
    address constant AVKAT = 0x7231dbaCdFc968E07656D12389AB20De82FbfCeB;
    address constant DEPLOYER = 0x11b78837cadC8E894F1c6e13fA9f3A085a75FA35;
    uint256 constant MARKET_ERC20 = 7;

    address originalBase;
    CurveYieldVaultBase1271 base1271;
    CurveYieldSignatureFuse fuse;
    bytes prefix;

    uint256 signerPk = 0xA11CE5;
    address signer;
    address user = makeAddr("user");

    function setUp() public {
        vm.createSelectFork(vm.envString("KATANA_RPC_URL"), vm.envUint("FORK_BLOCK"));
        signer = vm.addr(signerPk);
        originalBase = IVaultQ(VAULT).PLASMA_VAULT_BASE();

        base1271 = new CurveYieldVaultBase1271(originalBase);
        fuse = new CurveYieldSignatureFuse(MARKET_ERC20, VAULT, address(base1271));
        prefix = bytes(
            string.concat("app.katana.network wants you to sign in with your Ethereum account:\n", vm.toString(VAULT), "\n")
        );

        vm.startPrank(DEPLOYER);
        address[] memory add = new address[](1);
        add[0] = address(fuse);
        IVaultQ(VAULT).addFuses(add);
        FuseAction[] memory a = new FuseAction[](3);
        a[0] = FuseAction(address(fuse), abi.encodeCall(CurveYieldSignatureFuse.install, ()));
        a[1] = FuseAction(address(fuse), abi.encodeCall(CurveYieldSignatureFuse.setPrefix, (prefix)));
        a[2] = FuseAction(address(fuse), abi.encodeCall(CurveYieldSignatureFuse.setSigner, (signer, true)));
        IVaultQ(VAULT).execute(a);
        vm.stopPrank();
    }

    // ---------------------------------------------------------------- 1. install

    function test_1_install_swapsBaseAndPreservesTotalAssetsAndViews() public {
        assertEq(IVaultQ(VAULT).PLASMA_VAULT_BASE(), address(base1271), "base not swapped");
        assertTrue(IVaultQ(VAULT).isQuestSigner(signer), "signer view");
        assertEq(keccak256(IVaultQ(VAULT).questSignPrefix()), keccak256(prefix), "prefix view");
    }

    function test_1b_install_totalAssetsWithinFiveBps() public {
        // Deploy a fresh copy of the fork state (a second vault call sequence) to compare before/after in one test.
        uint256 assetsBefore = IVaultQ(VAULT).totalAssets();
        // setUp already installed; re-read totalAssets right after install-time execute (setUp) vs now: only market-7
        // revaluation and a possible tiny fee-share mint happen in between, never a real step.
        vm.prank(DEPLOYER);
        IVaultQ(VAULT).totalAssets(); // no-op read, just confirms no revert post-install
        uint256 assetsAfter = IVaultQ(VAULT).totalAssets();
        console2.log("totalAssets before/after", assetsBefore, assetsAfter);
        assertGe(assetsAfter * 10_000, assetsBefore * 9_995, "assets dropped beyond 5bps");
        assertLe(assetsAfter * 10_000, assetsBefore * 10_005, "assets rose beyond 5bps");
    }

    // ---------------------------------------------------------------- 2. valid signature

    function test_2_validSiweSignature_returnsMagicValue() public view {
        bytes memory message = _siweMessage("test-nonce-1");
        bytes32 hash = MessageHashUtils.toEthSignedMessageHash(message);
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(signerPk, hash);
        bytes memory sig = abi.encodePacked(r, s, v);
        bytes memory signature = abi.encode(message, sig);
        bytes4 result = IVaultQ(VAULT).isValidSignature(hash, signature);
        assertEq(result, MAGIC, "valid SIWE signature not accepted");
    }

    // ---------------------------------------------------------------- 3. rejects, never reverts

    function test_3a_rejects_wrongSigner() public view {
        bytes memory message = _siweMessage("wrong-signer");
        bytes32 hash = MessageHashUtils.toEthSignedMessageHash(message);
        uint256 otherPk = 0xB0B5;
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(otherPk, hash);
        bytes memory sig = abi.encodePacked(r, s, v);
        bytes memory signature = abi.encode(message, sig);
        assertEq(IVaultQ(VAULT).isValidSignature(hash, signature), INVALID, "wrong signer accepted");
    }

    function test_3b_rejects_wrongPrefix_otherDomain() public view {
        bytes memory message = bytes(
            string.concat("evil.example wants you to sign in with your Ethereum account:\n", vm.toString(VAULT), "\nnonce: x")
        );
        bytes32 hash = MessageHashUtils.toEthSignedMessageHash(message);
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(signerPk, hash);
        bytes memory sig = abi.encodePacked(r, s, v);
        bytes memory signature = abi.encode(message, sig);
        assertEq(IVaultQ(VAULT).isValidSignature(hash, signature), INVALID, "other domain accepted");
    }

    function test_3c_rejects_wrongPrefix_otherVaultAddress() public {
        address otherVault = makeAddr("otherVault");
        bytes memory message = bytes(
            string.concat("app.katana.network wants you to sign in with your Ethereum account:\n", vm.toString(otherVault), "\nnonce: x")
        );
        bytes32 hash = MessageHashUtils.toEthSignedMessageHash(message);
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(signerPk, hash);
        bytes memory sig = abi.encodePacked(r, s, v);
        bytes memory signature = abi.encode(message, sig);
        assertEq(IVaultQ(VAULT).isValidSignature(hash, signature), INVALID, "other vault address accepted");
    }

    function test_3d_rejects_hashNotEip191_eip712StyleDigest() public view {
        bytes memory message = _siweMessage("eip712-digest");
        bytes32 correctHash = MessageHashUtils.toEthSignedMessageHash(message);
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(signerPk, correctHash);
        bytes memory sig = abi.encodePacked(r, s, v);
        bytes memory signature = abi.encode(message, sig);
        // An EIP-712-style digest (domain separator + struct hash), never equal to the EIP-191 personal-sign hash.
        bytes32 domainSeparator = keccak256(abi.encode(keccak256("EIP712Domain(uint256 chainId)"), block.chainid));
        bytes32 structHash = keccak256(abi.encode(keccak256("Msg(bytes message)"), keccak256(message)));
        bytes32 eip712Digest = keccak256(abi.encodePacked(bytes2(0x1901), domainSeparator, structHash));
        assertTrue(eip712Digest != correctHash, "test digest accidentally equals the EIP-191 hash");
        assertEq(IVaultQ(VAULT).isValidSignature(eip712Digest, signature), INVALID, "EIP-712 digest accepted");
    }

    function test_3e_rejects_signerDisabled() public {
        bytes memory message = _siweMessage("disable-me");
        bytes32 hash = MessageHashUtils.toEthSignedMessageHash(message);
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(signerPk, hash);
        bytes memory sig = abi.encodePacked(r, s, v);
        bytes memory signature = abi.encode(message, sig);
        assertEq(IVaultQ(VAULT).isValidSignature(hash, signature), MAGIC, "sanity: should be valid before disabling");

        FuseAction[] memory a = new FuseAction[](1);
        a[0] = FuseAction(address(fuse), abi.encodeCall(CurveYieldSignatureFuse.setSigner, (signer, false)));
        vm.prank(DEPLOYER);
        IVaultQ(VAULT).execute(a);

        assertFalse(IVaultQ(VAULT).isQuestSigner(signer), "signer still enabled");
        assertEq(IVaultQ(VAULT).isValidSignature(hash, signature), INVALID, "disabled signer accepted");
    }

    function test_3f_rejects_emptyPrefix() public {
        FuseAction[] memory a = new FuseAction[](1);
        a[0] = FuseAction(address(fuse), abi.encodeCall(CurveYieldSignatureFuse.setPrefix, (bytes(""))));
        vm.prank(DEPLOYER);
        IVaultQ(VAULT).execute(a);
        assertEq(IVaultQ(VAULT).questSignPrefix().length, 0, "prefix not cleared");

        bytes memory message = _siweMessage("empty-prefix");
        bytes32 hash = MessageHashUtils.toEthSignedMessageHash(message);
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(signerPk, hash);
        bytes memory sig = abi.encodePacked(r, s, v);
        bytes memory signature = abi.encode(message, sig);
        assertEq(IVaultQ(VAULT).isValidSignature(hash, signature), INVALID, "empty prefix accepted anything");
    }

    function test_3g_rejects_shortSignatureBytes() public view {
        bytes memory shortSig = new bytes(127);
        assertEq(IVaultQ(VAULT).isValidSignature(bytes32(0), shortSig), INVALID, "short signature bytes not rejected");
        bytes memory tinySig = new bytes(10);
        assertEq(IVaultQ(VAULT).isValidSignature(bytes32(uint256(1)), tinySig), INVALID, "tiny signature bytes not rejected");
    }

    // ---------------------------------------------------------------- 4. vault still works through the wrapper

    function test_4a_shareTransfer_updateInternalPath() public {
        deal(AVKAT, user, 1_000e18);
        vm.startPrank(user);
        IErc20Q(AVKAT).approve(VAULT, 1_000e18);
        uint256 shares = IVaultQ(VAULT).deposit(1_000e18, user);
        vm.stopPrank();
        assertGt(shares, 0, "no shares minted");

        address recipient = makeAddr("recipient");
        vm.prank(user);
        bool ok = IVaultQ(VAULT).transfer(recipient, shares / 2);
        assertTrue(ok, "transfer failed");
        assertEq(IVaultQ(VAULT).balanceOf(recipient), shares / 2, "recipient balance wrong");
        assertEq(IVaultQ(VAULT).balanceOf(user), shares - shares / 2, "sender balance wrong");
    }

    function test_4b_depositAndRedeem_byAUser() public {
        deal(AVKAT, user, 1_000e18);
        vm.startPrank(user);
        IErc20Q(AVKAT).approve(VAULT, 1_000e18);
        uint256 shares = IVaultQ(VAULT).deposit(1_000e18, user);
        assertGt(shares, 0, "no shares minted");

        uint256 before = IErc20Q(AVKAT).balanceOf(user);
        uint256 got = IVaultQ(VAULT).redeem(shares, user, user);
        vm.stopPrank();
        console2.log("deposited / redeemed back", 1_000e18, got);
        assertGt(got, 0, "nothing redeemed");
        assertEq(IErc20Q(AVKAT).balanceOf(user) - before, got, "redeem proceeds not received");
        // an instant redeem fee is charged but liquidity is idle-covered for this modest size: expect most of it back
        assertApproxEqRel(got, 1_000e18, 0.05e18, "redeemed amount far from the deposit");
    }

    function test_4c_capAndOtherBaseRoutedCalls() public view {
        uint256 c = IVaultQ(VAULT).cap();
        console2.log("vault cap", c);
        assertGt(c, 0, "cap() did not route to the original base");
        // isFuseSupported is a PlasmaVault-native call (not base-routed) but exercises the vault end-to-end
        assertTrue(IVaultQ(VAULT).isFuseSupported(address(fuse)), "signature fuse not supported");
    }

    // ---------------------------------------------------------------- 5. access control

    function test_5a_fuseFunctions_revertWrongContext_whenCalledDirectly() public {
        vm.expectRevert(CurveYieldSignatureFuse.WrongContext.selector);
        fuse.install();

        vm.expectRevert(CurveYieldSignatureFuse.WrongContext.selector);
        fuse.uninstall();

        vm.expectRevert(CurveYieldSignatureFuse.WrongContext.selector);
        fuse.setSigner(signer, true);

        vm.expectRevert(CurveYieldSignatureFuse.WrongContext.selector);
        fuse.setPrefix(prefix);
    }

    function test_5b_nonAlphaCannotExecute() public {
        address stranger = makeAddr("stranger");
        (bool isAlpha,) = IAmQ(AM).hasRole(200, stranger);
        assertFalse(isAlpha, "test setup: stranger unexpectedly holds ALPHA");

        FuseAction[] memory a = new FuseAction[](1);
        a[0] = FuseAction(address(fuse), abi.encodeCall(CurveYieldSignatureFuse.setSigner, (signer, true)));
        vm.prank(stranger);
        vm.expectRevert();
        IVaultQ(VAULT).execute(a);
    }

    function test_5c_installTwice_revertsUnexpectedBase() public {
        FuseAction[] memory a = new FuseAction[](1);
        a[0] = FuseAction(address(fuse), abi.encodeCall(CurveYieldSignatureFuse.install, ()));
        vm.prank(DEPLOYER);
        vm.expectRevert(abi.encodeWithSelector(CurveYieldSignatureFuse.UnexpectedBase.selector, address(base1271)));
        IVaultQ(VAULT).execute(a);
    }

    function test_5d_uninstall_restoresOriginalBase_thenIsValidSignatureUnsupported() public {
        FuseAction[] memory a = new FuseAction[](2);
        a[0] = FuseAction(address(fuse), abi.encodeCall(CurveYieldSignatureFuse.setSigner, (signer, false)));
        a[1] = FuseAction(address(fuse), abi.encodeCall(CurveYieldSignatureFuse.uninstall, ()));
        vm.prank(DEPLOYER);
        IVaultQ(VAULT).execute(a);

        assertEq(IVaultQ(VAULT).PLASMA_VAULT_BASE(), originalBase, "base not restored exactly");

        // Uninstalling twice must also revert (current base is no longer BASE_1271).
        FuseAction[] memory b = new FuseAction[](1);
        b[0] = FuseAction(address(fuse), abi.encodeCall(CurveYieldSignatureFuse.uninstall, ()));
        vm.prank(DEPLOYER);
        vm.expectRevert(abi.encodeWithSelector(CurveYieldSignatureFuse.UnexpectedBase.selector, originalBase));
        IVaultQ(VAULT).execute(b);

        // isValidSignature no longer exists on the restored (original) base: the call must not silently succeed with
        // the magic value. It either reverts (no matching function on PlasmaVaultBase) or returns a non-magic value.
        bytes memory message = _siweMessage("post-uninstall");
        bytes32 hash = MessageHashUtils.toEthSignedMessageHash(message);
        (uint8 v, bytes32 r, bytes32 s) = vm.sign(signerPk, hash);
        bytes memory sig = abi.encodePacked(r, s, v);
        bytes memory signature = abi.encode(message, sig);
        try IVaultQ(VAULT).isValidSignature(hash, signature) returns (bytes4 result) {
            assertTrue(result != MAGIC, "isValidSignature still answered MAGIC after uninstall");
        } catch {
            // reverted: also an acceptable "unsupported" outcome
        }
    }

    // ---------------------------------------------------------------- helpers

    function _siweMessage(string memory nonce_) internal view returns (bytes memory) {
        return bytes(
            string.concat(
                "app.katana.network wants you to sign in with your Ethereum account:\n",
                vm.toString(VAULT),
                "\n\n",
                "URI: https://app.katana.network\n",
                "Version: 1\n",
                "Chain ID: 747474\n",
                "Nonce: ",
                nonce_,
                "\n",
                "Issued At: 2026-09-26T00:00:00Z"
            )
        );
    }
}
