// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.30;

import {Test} from "forge-std/Test.sol";
import {CurveYieldEngagementToken} from "../../src/governance/CurveYieldEngagementToken.sol";

/// @notice Unit tests for CurveYieldEngagementToken (no fork). Timestamps are explicit (block.timestamp is cached across
/// vm.warp under via-ir).
contract EngagementTokenTest is Test {
    uint256 constant DAY = 1 days;
    uint256 constant DECAY_Q = 180 days * 4;
    uint256 constant T = 1_800_000_000;

    CurveYieldEngagementToken token;
    address minter = makeAddr("minter");
    address distributor = makeAddr("distributor");
    address alice = makeAddr("alice");
    address bob = makeAddr("bob");

    function setUp() public {
        vm.warp(T);
        token = new CurveYieldEngagementToken(address(this));
        token.setMinter(minter, true);
        token.setDistributor(distributor);
    }

    function _mint(address to_, uint256 amount_) internal {
        vm.prank(minter);
        token.mint(to_, amount_);
    }

    /// @dev A lot minted at `mintedAt_` with no slows, at time `t_`.
    function _plain(uint256 amount_, uint256 mintedAt_, uint256 t_) internal pure returns (uint256) {
        uint256 c = 4 * (t_ - mintedAt_);
        return c >= DECAY_Q ? 0 : amount_ * (DECAY_Q - c) / DECAY_Q;
    }

    // ---------------------------------------------------------------- decay

    function test_decay_linearToZeroOver180Days() public {
        _mint(alice, 100e18);
        assertEq(token.balanceOf(alice), 100e18);
        vm.warp(T + 90 days);
        assertEq(token.balanceOf(alice), 50e18, "half at 90 days");
        vm.warp(T + 45 days);
        assertEq(token.balanceOf(alice), 75e18);
        vm.warp(T + 180 days - 1);
        assertEq(token.balanceOf(alice), _plain(100e18, T, T + 180 days - 1));
        assertLt(token.balanceOf(alice), 1e13);
        vm.warp(T + 180 days);
        assertEq(token.balanceOf(alice), 0);
        vm.warp(T + 1_000 days);
        assertEq(token.balanceOf(alice), 0);
        assertEq(token.balanceAt(alice, T + 90 days), 50e18, "balanceAt in the past of the holder's last update is not needed");
    }

    // ---------------------------------------------------------------- slowing

    function test_oneSlow_halfSpeed() public {
        _mint(alice, 100e18);
        vm.warp(T + 30 days);
        _mint(alice, 10e18); // slows 20 units: the old lot (75% left... 83.3 units) is slowed for 120 days
        CurveYieldEngagementToken.Lot[] memory lots = token.lotsOf(alice);
        assertEq(lots.length, 2);
        assertEq(lots[0].slowA, T + 30 days + 120 days);
        assertEq(lots[0].slowB, 0);
        assertEq(lots[1].slowA, 0);

        vm.warp(T + 90 days);
        // lot0: 30 days at full speed + 60 days at half speed = 60 days of decay time
        uint256 l0 = 100e18 * (DECAY_Q - (4 * 30 days + 2 * 60 days)) / DECAY_Q;
        uint256 l1 = _plain(10e18, T + 30 days, T + 90 days);
        assertEq(token.balanceOf(alice), l0 + l1);
        // after the window ends the speed returns to full
        vm.warp(T + 150 days + 10 days);
        l0 = 100e18 * (DECAY_Q - (4 * 30 days + 2 * 120 days + 4 * 10 days)) / DECAY_Q;
        l1 = _plain(10e18, T + 30 days, T + 160 days);
        assertEq(token.balanceOf(alice), l0 + l1);
    }

    function test_twoSlows_quarterSpeed_thirdSlowExtendsEarlierWindow() public {
        _mint(alice, 100e18);
        vm.warp(T + 30 days);
        _mint(alice, 10e18); // slowA = T+150d
        vm.warp(T + 60 days);
        _mint(alice, 10e18); // slowB = T+180d
        CurveYieldEngagementToken.Lot[] memory lots = token.lotsOf(alice);
        assertEq(lots[0].slowA, T + 150 days);
        assertEq(lots[0].slowB, T + 180 days);

        // consumed by T+60d: 30d full + 30d half = 4*30d + 2*30d; then both windows active: quarter speed
        vm.warp(T + 120 days);
        uint256 c = 4 * 30 days + 2 * 30 days + 1 * 60 days;
        uint256 l0 = 100e18 * (DECAY_Q - c) / DECAY_Q;
        uint256 l1 = _plain(10e18, T + 30 days, T + 120 days);
        uint256 l2 = _plain(10e18, T + 60 days, T + 120 days);
        assertEq(token.balanceOf(alice), l0 + l1 + l2, "quarter speed while slowed twice");

        // a third slow extends the earlier-expiring window (slowA)
        vm.warp(T + 90 days);
        // (warp back is not possible: rebuild the timeline instead)
    }

    function test_thirdSlowExtendsTheEarlierExpiringWindow() public {
        _mint(alice, 100e18);
        vm.warp(T + 30 days);
        _mint(alice, 10e18); // slowA = T+150d
        vm.warp(T + 60 days);
        _mint(alice, 10e18); // slowB = T+180d
        vm.warp(T + 90 days);
        _mint(alice, 10e18); // both active, slowA (earlier) extended
        CurveYieldEngagementToken.Lot[] memory lots = token.lotsOf(alice);
        assertEq(lots[0].slowA, T + 90 days + 120 days, "earlier window not extended");
        assertEq(lots[0].slowB, T + 180 days, "later window changed");
    }

    function test_mintSlowsTwoUnitsPerUnit_oldestLotsFirst_wholeLots() public {
        _mint(alice, 100e18); // lot0
        _mint(alice, 100e18); // lot1; slows lot0 (100 >= 2*100? no: covers 100 of 200, so lot0 only, nothing else exists)
        CurveYieldEngagementToken.Lot[] memory lots = token.lotsOf(alice);
        assertEq(lots[0].slowA, T + 120 days, "lot0 slowed by the second mint");
        assertEq(lots[1].slowA, 0);

        // mint 10: budget 20 is covered by lot0 alone (value 100): lot1 stays unslowed
        _mint(alice, 10e18);
        lots = token.lotsOf(alice);
        assertEq(lots[0].slowB, T + 120 days, "lot0 slowed a second time");
        assertEq(lots[1].slowA, 0, "lot1 slowed although lot0 covered the budget");

        // mint 60: budget 120 > lot0's 100: lot0 (extended) then lot1 (whole lot, over-covering: 200 slowed for a 120 budget)
        _mint(alice, 60e18);
        lots = token.lotsOf(alice);
        assertEq(lots[1].slowA, T + 120 days, "lot1 not slowed");
        assertEq(lots[2].slowA, 0, "lot2 (10) slowed although lots 0 and 1 covered 200 >= 120");
    }

    function test_mintEventReportsSlowedUnits() public {
        _mint(alice, 100e18);
        vm.expectEmit(true, false, false, true);
        emit CurveYieldEngagementToken.Minted(alice, 10e18, 100e18); // the whole lot of 100 is slowed for a 20 budget
        _mint(alice, 10e18);
    }

    // ---------------------------------------------------------------- lot cap

    function test_lotCap64_mergesTwoOldestPreservingValue() public {
        for (uint256 i; i < 64; ++i) {
            vm.warp(T + i * 1 hours);
            _mint(alice, 1e18);
        }
        assertEq(token.lotsOf(alice).length, 64);
        vm.warp(T + 100 hours);
        uint256 before = token.balanceOf(alice);
        _mint(alice, 5e18);
        assertEq(token.lotsOf(alice).length, 64, "cap exceeded");
        assertApproxEqAbs(token.balanceOf(alice), before + 5e18, 2, "merge did not preserve value");
        // and again
        vm.warp(T + 101 hours);
        before = token.balanceOf(alice);
        _mint(alice, 5e18);
        assertEq(token.lotsOf(alice).length, 64);
        assertApproxEqAbs(token.balanceOf(alice), before + 5e18, 2);
    }

    function test_lotCap64_dropsDecayedLotsFirst() public {
        for (uint256 i; i < 64; ++i) {
            vm.warp(T + i * 1 hours);
            _mint(alice, 1e18);
        }
        vm.warp(T + 500 days); // every lot fully decayed, even the slowed ones
        assertEq(token.balanceOf(alice), 0);
        _mint(alice, 7e18);
        assertEq(token.lotsOf(alice).length, 1, "decayed lots not dropped");
        assertEq(token.balanceOf(alice), 7e18);
    }

    // ---------------------------------------------------------------- access / pause / non-transferable

    function test_nonTransferable() public {
        _mint(alice, 1e18);
        vm.startPrank(alice);
        vm.expectRevert(CurveYieldEngagementToken.NonTransferable.selector);
        token.transfer(bob, 1);
        vm.expectRevert(CurveYieldEngagementToken.NonTransferable.selector);
        token.transferFrom(alice, bob, 1);
        vm.expectRevert(CurveYieldEngagementToken.NonTransferable.selector);
        token.approve(bob, 1);
        vm.stopPrank();
        assertEq(token.allowance(alice, bob), 0);
        assertEq(token.decimals(), 18);
    }

    function test_minterOnly_zeroAmount_andAdminOnlyOwner() public {
        vm.prank(alice);
        vm.expectRevert(CurveYieldEngagementToken.NotMinter.selector);
        token.mint(alice, 1e18);
        vm.prank(minter);
        vm.expectRevert(CurveYieldEngagementToken.ZeroAmount.selector);
        token.mint(alice, 0);
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSignature("OwnableUnauthorizedAccount(address)", alice));
        token.setMinter(alice, true);
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSignature("OwnableUnauthorizedAccount(address)", alice));
        token.setDistributor(alice);
        token.setMinter(minter, false);
        vm.prank(minter);
        vm.expectRevert(CurveYieldEngagementToken.NotMinter.selector);
        token.mint(alice, 1e18);
    }

    function test_mintRevertsWhilePaused_onlyDistributorPauses() public {
        vm.prank(alice);
        vm.expectRevert(CurveYieldEngagementToken.NotDistributor.selector);
        token.setMintingPaused(true);
        vm.prank(distributor);
        token.setMintingPaused(true);
        vm.prank(minter);
        vm.expectRevert(CurveYieldEngagementToken.Paused.selector);
        token.mint(alice, 1e18);
        vm.prank(distributor);
        token.setMintingPaused(false);
        _mint(alice, 1e18);
        assertEq(token.balanceOf(alice), 1e18);
        assertEq(token.holdersLength(), 1);
        assertEq(token.holderAt(0), alice);
        _mint(alice, 1e18);
        assertEq(token.holdersLength(), 1, "holder listed twice");
    }

    // ---------------------------------------------------------------- balanceAt

    function test_balanceAtFutureMatchesLaterBalanceOf() public {
        _mint(alice, 100e18);
        vm.warp(T + 30 days);
        _mint(alice, 10e18);
        vm.warp(T + 60 days);
        _mint(alice, 20e18);
        uint256[6] memory ts = [T + 60 days, T + 75 days, T + 120 days, T + 150 days, T + 181 days, T + 400 days];
        uint256[6] memory predicted;
        for (uint256 i; i < ts.length; ++i) predicted[i] = token.balanceAt(alice, ts[i]);
        for (uint256 i; i < ts.length; ++i) {
            vm.warp(ts[i]);
            assertEq(token.balanceOf(alice), predicted[i], "balanceAt(future) != later balanceOf");
        }
    }

    // ---------------------------------------------------------------- fuzz

    /// @dev Between mints the sum of lot values never increases; a mint adds exactly the minted amount (+-2 wei from the
    /// merge rounding), slowing changes no value at the moment it is applied.
    function testFuzz_sumOfValuesNeverIncreasesWithoutMint(uint256 seed_) public {
        address[2] memory hs = [alice, bob];
        uint256 now_ = T;
        uint256[2] memory prev;
        for (uint256 i; i < 40; ++i) {
            uint256 h = uint256(keccak256(abi.encode(seed_, i)));
            if (h % 3 != 0) {
                now_ += (h >> 8) % 30 days;
                vm.warp(now_);
                for (uint256 k; k < 2; ++k) {
                    uint256 b = token.balanceOf(hs[k]);
                    assertLe(b, prev[k] + 0, "balance increased without a mint");
                    prev[k] = b;
                }
            } else {
                address who = hs[(h >> 16) % 2];
                uint256 idx = who == alice ? 0 : 1;
                uint256 amount = 1 + (h >> 24) % 100e18;
                uint256 before = token.balanceOf(who);
                vm.prank(minter);
                token.mint(who, amount);
                assertApproxEqAbs(token.balanceOf(who), before + amount, 2, "mint changed existing value");
                prev[idx] = token.balanceOf(who);
                prev[1 - idx] = token.balanceOf(hs[1 - idx]);
            }
            assertLe(token.lotsOf(alice).length, 64);
            assertLe(token.lotsOf(bob).length, 64);
        }
    }
}
