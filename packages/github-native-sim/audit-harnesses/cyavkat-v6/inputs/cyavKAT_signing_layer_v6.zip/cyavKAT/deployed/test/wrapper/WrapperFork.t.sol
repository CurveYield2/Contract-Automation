// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.30;

import {Test, console2} from "forge-std/Test.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {IMorpho, MarketParams, Id, Position} from "@morpho-org/morpho-blue/src/interfaces/IMorpho.sol";
import {MarketParamsLib} from "@morpho-org/morpho-blue/src/libraries/MarketParamsLib.sol";
import {BurnRequestFeeFuse} from "contracts/fuses/burn_request_fee/BurnRequestFeeFuse.sol";
import {FuseAction} from "../../src/interfaces/CurveYieldPhase2Interfaces.sol";
import {CurveYieldWrappedCyavKat} from "../../src/wrapper/CurveYieldWrappedCyavKat.sol";
import {CurveYieldWrapperFeeSplitter} from "../../src/wrapper/CurveYieldWrapperFeeSplitter.sol";
import {IporVaultHaircutOracle12, IERC4626Rate} from "../../src/oracles/IporVaultHaircutOracle12.sol";

interface IVaultW {
    function deposit(uint256 assets, address receiver) external returns (uint256);
    function convertToAssets(uint256 shares) external view returns (uint256);
    function totalAssets() external view returns (uint256);
    function totalSupply() external view returns (uint256);
    function balanceOf(address) external view returns (uint256);
    function approve(address, uint256) external returns (bool);
    function transfer(address, uint256) external returns (bool);
    function addFuses(address[] calldata) external;
    function execute(FuseAction[] calldata) external;
}

interface IErc20W {
    function balanceOf(address) external view returns (uint256);
    function approve(address, uint256) external returns (bool);
}

/// @notice Fork tests for the wcyavKAT wrapper, its fee splitter and the 12%-haircut oracle (WRAPPER_SPEC.md).
/// Deploys fresh contracts in setUp (as L5 does) so every test starts from a known watermark; the live deployment, if
/// L5 has been run, is only sanity-checked. Run: RAYON_NUM_THREADS=2 forge test --match-path test/wrapper/WrapperFork.t.sol -vv
contract WrapperFork is Test {
    using MarketParamsLib for MarketParams;

    address constant VAULT = 0xEd83daf48429cfb2C650Fd721b9241e180fd4548;
    address constant AVKAT = 0x7231dbaCdFc968E07656D12389AB20De82FbfCeB;
    address constant MORPHO = 0xD50F2DffFd62f94Ee4AEd9ca05C61d0753268aBc;
    address constant IRM = 0x4F708C0ae7deD3d74736594C2109C2E3c065B428;
    address constant DEPLOYER = 0x11b78837cadC8E894F1c6e13fA9f3A085a75FA35;
    bytes32 constant WITHDRAW_MANAGER_SLOT = 0x465d2ff0062318fe6f4c7e9ac78cfcd70bc86a1d992722875ef83a9770513100;
    uint256 constant LLTV = 0.86e18;

    CurveYieldWrapperFeeSplitter splitter;
    CurveYieldWrappedCyavKat wrapper;
    IporVaultHaircutOracle12 oracle;
    MarketParams mp;
    address wm;

    address alice = makeAddr("alice");
    address bob = makeAddr("bob");
    address admin = makeAddr("admin");
    address contributors = makeAddr("contributors");

    function setUp() public {
        vm.createSelectFork(vm.envString("KATANA_RPC_URL"), vm.envUint("FORK_BLOCK"));
        wm = address(uint160(uint256(vm.load(VAULT, WITHDRAW_MANAGER_SLOT))));
        splitter = new CurveYieldWrapperFeeSplitter(DEPLOYER, IERC20(VAULT), admin, contributors, wm);
        wrapper = new CurveYieldWrappedCyavKat(DEPLOYER, IERC20(VAULT), address(splitter));
        oracle = new IporVaultHaircutOracle12(IERC4626Rate(address(wrapper)), AVKAT);
        mp = MarketParams(AVKAT, address(wrapper), address(oracle), IRM, LLTV);
        IMorpho(MORPHO).createMarket(mp);

        _fundCyavkat(alice, 5_000e18);
        _fundCyavkat(bob, 5_000e18);
        vm.prank(alice);
        IVaultW(VAULT).approve(address(wrapper), type(uint256).max);
        vm.prank(bob);
        IVaultW(VAULT).approve(address(wrapper), type(uint256).max);
    }

    // ---------------------------------------------------------------- helpers

    /// @dev cyavKAT by depositing avKAT into the vault.
    function _fundCyavkat(address who_, uint256 avkat_) internal {
        deal(AVKAT, who_, avkat_);
        vm.startPrank(who_);
        IErc20W(AVKAT).approve(VAULT, avkat_);
        IVaultW(VAULT).deposit(avkat_, who_);
        vm.stopPrank();
    }

    function _wrap(address who_, uint256 cyavkat_) internal returns (uint256 shares_) {
        vm.prank(who_);
        shares_ = wrapper.deposit(cyavkat_, who_);
    }

    /// @dev avKAT value of one cyavKAT (the price the wrapper and its oracle read).
    function _price() internal view returns (uint256) {
        return IVaultW(VAULT).convertToAssets(1e20);
    }

    /// @dev Moves the cyavKAT share price to `num_/den_` of its current value by adding or removing idle avKAT in the vault.
    function _scalePrice(uint256 num_, uint256 den_) internal {
        uint256 ta = IVaultW(VAULT).totalAssets();
        uint256 idle = IErc20W(AVKAT).balanceOf(VAULT);
        uint256 target = ta * num_ / den_;
        if (target >= ta) {
            deal(AVKAT, VAULT, idle + (target - ta));
        } else {
            require(idle >= ta - target, "vault idle too small to lower the price");
            deal(AVKAT, VAULT, idle - (ta - target));
        }
    }

    function _forcePrice(uint256 target_) internal {
        uint256 p = _price();
        if (p != target_) _scalePrice(target_, p);
    }

    function _splitterBal() internal view returns (uint256) {
        return IVaultW(VAULT).balanceOf(address(splitter));
    }

    // ---------------------------------------------------------------- 1. wrap / unwrap, first depositor

    function test_1_wrapUnwrapRoundTrip_decimals() public {
        assertEq(wrapper.decimals(), 20);
        assertEq(wrapper.asset(), VAULT);
        uint256 amount = IVaultW(VAULT).balanceOf(alice) / 2;
        uint256 shares = _wrap(alice, amount);
        assertGt(shares, 0);
        assertEq(wrapper.balanceOf(alice), shares);
        assertEq(wrapper.totalAssets(), amount);
        vm.prank(alice);
        uint256 back = wrapper.redeem(shares, alice, alice);
        assertApproxEqAbs(back, amount, 1, "round trip lost more than 1 wei");
        assertEq(wrapper.totalSupply(), 0);
    }

    function test_1_firstDepositorCannotInflateThePrice() public {
        address attacker = bob;
        address victim = alice;
        uint256 donation = 1_000e20;
        // attacker: 1 raw unit, then a direct donation of cyavKAT to the wrapper
        vm.prank(attacker);
        uint256 aShares = wrapper.deposit(1, attacker);
        assertEq(aShares, 1);
        uint256 attackerCost = 1 + donation;
        vm.prank(attacker);
        IVaultW(VAULT).transfer(address(wrapper), donation);
        // victim deposits half of the donation: the classic case where the victim gets 0 shares
        uint256 v = donation / 2;
        uint256 victimBefore = IVaultW(VAULT).balanceOf(victim);
        vm.prank(victim);
        uint256 vShares = wrapper.deposit(v, victim);
        console2.log("victim shares for", v, vShares);
        // attacker redeems everything
        uint256 attackerBefore = IVaultW(VAULT).balanceOf(attacker);
        vm.prank(attacker);
        uint256 got = wrapper.redeem(aShares, attacker, attacker);
        assertLe(got, attackerCost, "attacker profited from the donation");
        // The victim's loss is bounded by what the attacker gave up.
        uint256 victimValue = wrapper.convertToAssets(vShares);
        uint256 victimLoss = v > victimValue ? v - victimValue : 0;
        assertLe(victimLoss, attackerCost - 1, "victim lost more than the attacker paid");
        assertEq(IVaultW(VAULT).balanceOf(victim), victimBefore - v);
        assertEq(IVaultW(VAULT).balanceOf(attacker) - attackerBefore, got);
    }

    // ---------------------------------------------------------------- 2. management fee

    function test_2_managementFee_twoPercentAYear_noPriceJump() public {
        uint256 held = IVaultW(VAULT).balanceOf(alice);
        _wrap(alice, held);
        uint256 hwm = wrapper.highWatermark();
        vm.warp(block.timestamp + 365 days);
        _forcePrice(hwm); // no share-price change over the year
        (uint256 m, uint256 p) = wrapper.pendingFees();
        assertApproxEqRel(m, held * 200 / 10_000, 0.001e18, "pending management fee != 2%");
        assertApproxEqAbs(p, 0, held / 1e9 + 1, "performance fee at a flat price");

        uint256 taBefore = wrapper.totalAssets();
        uint256 rateBefore = wrapper.convertToAssets(1e20);
        uint256 splitterBefore = _splitterBal();
        wrapper.accrue();
        uint256 fee = _splitterBal() - splitterBefore;
        console2.log("held / fee sent to the splitter", held, fee);
        assertApproxEqRel(fee, held * 200 / 10_000, 0.001e18, "fee sent != 2% of held");
        assertApproxEqAbs(wrapper.totalAssets(), taBefore, 2, "totalAssets jumped on accrue");
        assertApproxEqAbs(wrapper.convertToAssets(1e20), rateBefore, 1, "exchange rate jumped on accrue");
        assertEq(wrapper.lastAccrual(), block.timestamp);
    }

    // ---------------------------------------------------------------- 3. performance fee

    function test_3_performanceFee_eightPercentOfGainAboveWatermark() public {
        uint256 held = IVaultW(VAULT).balanceOf(alice);
        _wrap(alice, held);
        uint256 p0 = wrapper.highWatermark();
        _scalePrice(11, 10); // +10%
        uint256 p1 = _price();
        assertApproxEqRel(p1, p0 * 11 / 10, 1e12, "price not +10%"); // 1e-6 relative: the vault's own rounding/fees
        uint256 expected = held * (p1 - p0) * 800 / (p1 * 10_000);
        console2.log("price before / after, expected fee shares", p0, p1, expected);
        (uint256 m, uint256 perf) = wrapper.pendingFees();
        assertEq(m, 0, "management fee with no time elapsed");
        assertEq(perf, expected, "pendingFees performance != 8% x gain / price x held");
        uint256 before = _splitterBal();
        wrapper.accrue();
        assertEq(_splitterBal() - before, expected, "fee shares sent");
        assertEq(wrapper.highWatermark(), p1, "watermark not the new price");
        (m, perf) = wrapper.pendingFees();
        assertEq(perf, 0, "performance fee pending right after accrue");
        // with elapsed time the management fee adds on top
        vm.warp(block.timestamp + 73 days); // 20% of a year: 0.4% management
        _forcePrice(p1);
        (m,) = wrapper.pendingFees();
        assertApproxEqRel(m, (held - expected) * 200 / 10_000 / 5, 0.001e18, "management fee for 73 days");
    }

    // ---------------------------------------------------------------- 4. watermark

    function test_4_watermark_noFeeUntilNewHigh() public {
        uint256 held = IVaultW(VAULT).balanceOf(alice);
        _wrap(alice, held);
        uint256 hwm = wrapper.highWatermark();

        _scalePrice(95, 100); // -5%
        assertLt(_price(), hwm);
        (, uint256 perf) = wrapper.pendingFees();
        assertEq(perf, 0, "performance fee below the watermark");
        wrapper.accrue();
        assertEq(_splitterBal(), 0, "fee taken below the watermark");
        assertEq(wrapper.highWatermark(), hwm, "watermark moved down");

        _forcePrice(hwm); // recovers to the old high
        (, perf) = wrapper.pendingFees();
        assertLe(perf, held / 1e9 + 1, "fee when merely back at the old high");
        wrapper.accrue();
        assertLe(_splitterBal(), held / 1e9 + 1);
        uint256 before = _splitterBal();

        _scalePrice(101, 100); // 1% above the old high
        uint256 p = _price();
        assertGt(p, hwm);
        uint256 expected = (held - before) * (p - hwm) * 800 / (p * 10_000);
        wrapper.accrue();
        uint256 fee = _splitterBal() - before;
        console2.log("fee on the 1% above the old high", fee, expected);
        assertApproxEqRel(fee, expected, 0.001e18, "fee not on the 1% gain only");
        assertEq(wrapper.highWatermark(), p);
        // sanity: it is 8% of ~1% of held, not 8% of the recovery from -5%
        assertLt(fee, held * 800 / 10_000 * 2 / 100);
    }

    // ---------------------------------------------------------------- 5. setFees

    function test_5_setFees_boundsOwnerAndAccruesFirst() public {
        uint256 held = IVaultW(VAULT).balanceOf(alice);
        _wrap(alice, held);
        assertEq(wrapper.managementFeeBps(), 200);
        assertEq(wrapper.performanceFeeBps(), 800);

        vm.prank(bob);
        vm.expectRevert(abi.encodeWithSignature("OwnableUnauthorizedAccount(address)", bob));
        wrapper.setFees(100, 100);

        vm.startPrank(DEPLOYER);
        vm.expectRevert(CurveYieldWrappedCyavKat.FeeTooHigh.selector);
        wrapper.setFees(501, 1_500);
        vm.expectRevert(CurveYieldWrappedCyavKat.FeeTooHigh.selector);
        wrapper.setFees(500, 1_501);
        vm.stopPrank();

        // accrues first at the OLD rates
        vm.warp(block.timestamp + 182 days);
        (uint256 m, uint256 p) = wrapper.pendingFees();
        assertGt(m, 0);
        uint256 before = _splitterBal();
        vm.prank(DEPLOYER);
        wrapper.setFees(500, 1_500);
        assertEq(_splitterBal() - before, m + p, "old-rate fees not taken before the change");
        assertEq(wrapper.managementFeeBps(), 500);
        assertEq(wrapper.performanceFeeBps(), 1_500);
        assertEq(wrapper.lastAccrual(), block.timestamp);

        // new rate applies only from now on
        vm.warp(block.timestamp + 73 days);
        uint256 heldNow = IVaultW(VAULT).balanceOf(address(wrapper));
        (m,) = wrapper.pendingFees();
        assertApproxEqRel(m, heldNow * 500 * 73 days / (10_000 * 365 days), 1e12, "5% rate for 73 days");

        // fees off
        vm.prank(DEPLOYER);
        wrapper.setFees(0, 0);
        vm.warp(block.timestamp + 100 days);
        (m, p) = wrapper.pendingFees();
        assertEq(m, 0);
        assertEq(p, 0);
    }

    // ---------------------------------------------------------------- 6. oracle

    function test_6_oracle_exactMath_smoothAcrossAccrue() public {
        uint256 held = IVaultW(VAULT).balanceOf(alice);
        _wrap(alice, held);
        uint256 aw = IVaultW(VAULT).convertToAssets(wrapper.convertToAssets(1e20));
        assertEq(oracle.price(), aw * 1e36 * 8_800 / (1e20 * 10_000), "oracle math");
        assertEq(oracle.price(), aw * 1e16 * 88 / 100, "oracle = assets per wcyavKAT * 1e16 * 0.88");
        console2.log("oracle price / assets per wcyavKAT", oracle.price(), aw);

        // pending fees (time + price gain) must not move the price when they are taken
        vm.warp(block.timestamp + 200 days);
        _scalePrice(103, 100);
        uint256 p0 = oracle.price();
        wrapper.accrue();
        uint256 p1 = oracle.price();
        console2.log("oracle before / after accrue", p0, p1);
        assertApproxEqRel(p0, p1, 1e6, "oracle jumped across accrue"); // 1e-12 relative
        // and it tracks the wrapper's rate net of fees
        uint256 aw1 = IVaultW(VAULT).convertToAssets(wrapper.convertToAssets(1e20));
        assertEq(p1, aw1 * 1e36 * 8_800 / (1e20 * 10_000));
    }

    // ---------------------------------------------------------------- 7. Morpho market

    function test_7_morphoBorrowLimitAndLiquidation() public {
        // lender
        address lender = makeAddr("lender");
        deal(AVKAT, lender, 200_000e18);
        vm.startPrank(lender);
        IErc20W(AVKAT).approve(MORPHO, type(uint256).max);
        IMorpho(MORPHO).supply(mp, 200_000e18, 0, lender, "");
        vm.stopPrank();

        // borrower wraps and supplies collateral
        uint256 held = IVaultW(VAULT).balanceOf(alice);
        uint256 w = _wrap(alice, held);
        vm.startPrank(alice);
        wrapper.approve(MORPHO, w);
        IMorpho(MORPHO).supplyCollateral(mp, w, alice, "");
        vm.stopPrank();

        uint256 value = w * oracle.price() / 1e36; // avKAT value of the collateral after the haircut
        uint256 maxBorrow = value * LLTV / 1e18;
        console2.log("collateral shares / value (haircut) / max borrow", w, value, maxBorrow);

        // over the limit reverts
        vm.prank(alice);
        vm.expectRevert(bytes("insufficient collateral"));
        IMorpho(MORPHO).borrow(mp, maxBorrow * 1_001 / 1_000, 0, alice, alice);
        // just under the limit works
        uint256 borrowAmount = maxBorrow * 999 / 1_000;
        vm.prank(alice);
        IMorpho(MORPHO).borrow(mp, borrowAmount, 0, alice, alice);
        assertEq(IErc20W(AVKAT).balanceOf(alice) >= borrowAmount, true);
        // and ~ 86% x 88% of the raw avKAT value
        uint256 rawValue = IVaultW(VAULT).convertToAssets(wrapper.convertToAssets(w));
        assertApproxEqRel(borrowAmount, rawValue * 8_800 / 10_000 * 86 / 100 * 999 / 1_000, 1e13, "max borrow != 75.68% of value");

        // healthy: cannot be liquidated
        address liq = makeAddr("liquidator");
        deal(AVKAT, liq, 100_000e18);
        vm.startPrank(liq);
        IErc20W(AVKAT).approve(MORPHO, type(uint256).max);
        vm.expectRevert(bytes("position is healthy"));
        IMorpho(MORPHO).liquidate(mp, alice, 1e18, 0, "");
        vm.stopPrank();

        // the cyavKAT price falls 5%: the position is unhealthy and a liquidation succeeds
        _scalePrice(95, 100);
        Position memory before = IMorpho(MORPHO).position(Id.wrap(Id.unwrap(mp.id())), alice);
        vm.prank(liq);
        (uint256 seized, uint256 repaid) = IMorpho(MORPHO).liquidate(mp, alice, w / 10, 0, "");
        Position memory afterP = IMorpho(MORPHO).position(Id.wrap(Id.unwrap(mp.id())), alice);
        console2.log("liquidation: seized wcyavKAT / repaid avKAT", seized, repaid);
        assertEq(seized, w / 10);
        assertGt(repaid, 0);
        assertLt(afterP.collateral, before.collateral, "collateral not seized");
        assertLt(afterP.borrowShares, before.borrowShares, "debt not repaid");
    }

    function test_7b_positionBecomesLiquidatableWithFeesAndTime() public {
        address lender = makeAddr("lender");
        deal(AVKAT, lender, 200_000e18);
        vm.startPrank(lender);
        IErc20W(AVKAT).approve(MORPHO, type(uint256).max);
        IMorpho(MORPHO).supply(mp, 200_000e18, 0, lender, "");
        vm.stopPrank();
        uint256 held = IVaultW(VAULT).balanceOf(alice);
        uint256 w = _wrap(alice, held);
        vm.startPrank(alice);
        wrapper.approve(MORPHO, w);
        IMorpho(MORPHO).supplyCollateral(mp, w, alice, "");
        vm.stopPrank();
        uint256 maxBorrow = w * oracle.price() / 1e36 * LLTV / 1e18;
        vm.prank(alice);
        IMorpho(MORPHO).borrow(mp, maxBorrow * 9_999 / 10_000, 0, alice, alice);

        // one year of the 2% management fee (price flat): the wrapper's rate falls net of fees, and so does the oracle
        uint256 hwm = wrapper.highWatermark();
        vm.warp(block.timestamp + 365 days);
        _forcePrice(hwm);
        uint256 priceAfter = oracle.price();
        console2.log("oracle price after a year of fees", priceAfter);
        // borrow interest also accrued: 99.99% of the limit is now over it
        address liq = makeAddr("liquidator");
        deal(AVKAT, liq, 100_000e18);
        vm.startPrank(liq);
        IErc20W(AVKAT).approve(MORPHO, type(uint256).max);
        (uint256 seized,) = IMorpho(MORPHO).liquidate(mp, alice, w / 20, 0, "");
        vm.stopPrank();
        assertGt(seized, 0, "liquidation failed");
    }

    // ---------------------------------------------------------------- 8. splitter

    function test_8_splitter_fortyThirtyThirty_dustToBurn() public {
        // 10,007 raw units: 40% = 4002.8, 30% = 3002.1, burn = the rest (3003, dust included)
        vm.prank(alice);
        IVaultW(VAULT).transfer(address(splitter), 10_007);
        uint256 a0 = IVaultW(VAULT).balanceOf(admin);
        uint256 c0 = IVaultW(VAULT).balanceOf(contributors);
        uint256 w0 = IVaultW(VAULT).balanceOf(wm);
        splitter.distribute();
        assertEq(IVaultW(VAULT).balanceOf(admin) - a0, 4_002);
        assertEq(IVaultW(VAULT).balanceOf(contributors) - c0, 3_002);
        assertEq(IVaultW(VAULT).balanceOf(wm) - w0, 3_003, "burn share should take the rounding dust");
        assertEq(_splitterBal(), 0);

        // a round number splits exactly 40/30/30
        vm.prank(alice);
        IVaultW(VAULT).transfer(address(splitter), 1_000e20);
        a0 = IVaultW(VAULT).balanceOf(admin);
        c0 = IVaultW(VAULT).balanceOf(contributors);
        w0 = IVaultW(VAULT).balanceOf(wm);
        splitter.distribute();
        assertEq(IVaultW(VAULT).balanceOf(admin) - a0, 400e20);
        assertEq(IVaultW(VAULT).balanceOf(contributors) - c0, 300e20);
        assertEq(IVaultW(VAULT).balanceOf(wm) - w0, 300e20);

        // nothing to distribute: no revert
        splitter.distribute();
    }

    function test_8b_splitter_settersOwnerOnlyRejectZero() public {
        address rnd = makeAddr("rnd");
        vm.startPrank(rnd);
        vm.expectRevert(abi.encodeWithSignature("OwnableUnauthorizedAccount(address)", rnd));
        splitter.setAdminReceiver(rnd);
        vm.expectRevert(abi.encodeWithSignature("OwnableUnauthorizedAccount(address)", rnd));
        splitter.setDestinations(rnd, rnd);
        vm.stopPrank();

        vm.startPrank(DEPLOYER);
        vm.expectRevert(CurveYieldWrapperFeeSplitter.InvalidAddress.selector);
        splitter.setAdminReceiver(address(0));
        vm.expectRevert(CurveYieldWrapperFeeSplitter.InvalidAddress.selector);
        splitter.setDestinations(address(0), wm);
        vm.expectRevert(CurveYieldWrapperFeeSplitter.InvalidAddress.selector);
        splitter.setDestinations(contributors, address(0));
        address newAdmin = makeAddr("newAdmin");
        address newContributors = makeAddr("newContributors");
        address newWm = makeAddr("newWm");
        splitter.setAdminReceiver(newAdmin);
        splitter.setDestinations(newContributors, newWm);
        vm.stopPrank();
        assertEq(splitter.adminReceiver(), newAdmin);
        assertEq(splitter.contributorsReceiver(), newContributors);
        assertEq(splitter.burnWithdrawManager(), newWm);

        vm.prank(alice);
        IVaultW(VAULT).transfer(address(splitter), 1_000e20);
        splitter.distribute();
        assertEq(IVaultW(VAULT).balanceOf(newAdmin), 400e20);
        assertEq(IVaultW(VAULT).balanceOf(newContributors), 300e20);
        assertEq(IVaultW(VAULT).balanceOf(newWm), 300e20);

        // constructor rejects zero too
        vm.expectRevert(CurveYieldWrapperFeeSplitter.InvalidAddress.selector);
        new CurveYieldWrapperFeeSplitter(DEPLOYER, IERC20(VAULT), address(0), contributors, wm);
        vm.expectRevert(CurveYieldWrapperFeeSplitter.InvalidAddress.selector);
        new CurveYieldWrapperFeeSplitter(DEPLOYER, IERC20(VAULT), admin, contributors, address(0));
    }

    // ---------------------------------------------------------------- 9. burn through the IPOR fuse

    function test_9_burnViaBurnRequestFeeFuse_supplyDown_assetsSame_ppsUp() public {
        // fees arrive at the splitter through the real path: management fee over a year, then distribute
        uint256 held = IVaultW(VAULT).balanceOf(alice);
        _wrap(alice, held);
        vm.warp(block.timestamp + 365 days);
        _forcePrice(wrapper.highWatermark());
        wrapper.accrue();
        uint256 fees = _splitterBal();
        assertGt(fees, 0);
        uint256 w0 = IVaultW(VAULT).balanceOf(wm);
        splitter.distribute();
        uint256 toBurn = IVaultW(VAULT).balanceOf(wm) - w0;
        assertEq(toBurn, fees - fees * 4_000 / 10_000 - fees * 3_000 / 10_000);
        assertGt(toBurn, 0);

        // a fresh BurnRequestFeeFuse (the live 0x44D3 reads the pre-IL-6952 slot), added by the FUSE_MANAGER (DEPLOYER)
        BurnRequestFeeFuse burnFuse = new BurnRequestFeeFuse(type(uint256).max);
        address[] memory add = new address[](1);
        add[0] = address(burnFuse);
        vm.prank(DEPLOYER);
        IVaultW(VAULT).addFuses(add);

        // The IPOR vault realises its own management / performance fee shares on every execute. Burn 1 raw unit first so
        // that realisation happens now, and measure the real burn in a second call at the same timestamp.
        FuseAction[] memory a = new FuseAction[](1);
        a[0] = FuseAction(address(burnFuse), abi.encodeWithSignature("enter((uint256))", uint256(1)));
        vm.prank(DEPLOYER); // ALPHA
        IVaultW(VAULT).execute(a);
        toBurn -= 1;
        uint256 supply0 = IVaultW(VAULT).totalSupply();
        uint256 assets0 = IVaultW(VAULT).totalAssets();
        uint256 pps0 = _price();
        a[0] = FuseAction(address(burnFuse), abi.encodeWithSignature("enter((uint256))", toBurn));
        uint256 wmBefore = IVaultW(VAULT).balanceOf(wm);
        address perfAcc = 0xe40276A664b655C4eD189dFae137A42Cd898A321;
        address mgmtAcc = 0xfEa31a44A30006d9b1Fc19862903C97aC53845eB;
        uint256 perfBefore = IVaultW(VAULT).balanceOf(perfAcc);
        uint256 mgmtBefore = IVaultW(VAULT).balanceOf(mgmtAcc);
        vm.prank(DEPLOYER);
        IVaultW(VAULT).execute(a);
        console2.log("wm before / after", wmBefore, IVaultW(VAULT).balanceOf(wm));
        console2.log("perf fee acct delta", IVaultW(VAULT).balanceOf(perfAcc) - perfBefore);
        console2.log("mgmt fee acct delta", IVaultW(VAULT).balanceOf(mgmtAcc) - mgmtBefore);
        console2.log("toBurn / supply drop", toBurn, supply0 - IVaultW(VAULT).totalSupply());
        // The burn lifts the price per share, and the vault's own IPOR performance fee (10% of gains) then mints shares
        // to its fee account in the same execute. Net supply = supply0 - burned + freshly minted fee shares.
        uint256 feeMinted = IVaultW(VAULT).balanceOf(perfAcc) - perfBefore + IVaultW(VAULT).balanceOf(mgmtAcc) - mgmtBefore;

        console2.log("supply before / after", supply0, IVaultW(VAULT).totalSupply());
        assertEq(IVaultW(VAULT).totalSupply(), supply0 - toBurn + feeMinted, "supply != before - burned + vault fee shares");
        assertLt(IVaultW(VAULT).totalSupply(), supply0, "supply did not drop");
        assertLt(feeMinted, toBurn / 10, "vault fee shares above 10% of the burn");
        assertEq(IVaultW(VAULT).balanceOf(wm), w0, "withdraw manager still holds the burned shares");
        assertGt(_price(), pps0, "price per share did not go up");
        assertApproxEqAbs(IVaultW(VAULT).totalAssets(), assets0, 1, "totalAssets changed");
        assertGt(_price(), pps0, "price per share did not go up");
    }

    // ---------------------------------------------------------------- live deployment sanity (if L5 has run)

    function test_liveDeploymentSanityIfPresent() public {
        string memory j = vm.readFile("deployments/katana-lending-v1.json");
        address live;
        try vm.parseJsonAddress(j, ".wcyavkat") returns (address a) {
            live = a;
        } catch {}
        if (live == address(0) || live.code.length == 0) {
            console2.log("no live wcyavKAT in deployments/katana-lending-v1.json (L5 not run)");
            vm.skip(true);
        }
        CurveYieldWrappedCyavKat w = CurveYieldWrappedCyavKat(live);
        assertEq(w.asset(), VAULT);
        assertEq(w.decimals(), 20);
        assertEq(w.managementFeeBps(), 200);
        assertEq(w.performanceFeeBps(), 800);
        assertEq(w.owner(), DEPLOYER);
        address spl = vm.parseJsonAddress(j, ".wrapperFeeSplitter");
        assertEq(w.FEE_SPLITTER(), spl);
        assertEq(address(CurveYieldWrapperFeeSplitter(spl).CYAVKAT()), VAULT);
        bytes32 id = vm.parseJsonBytes32(j, ".lendMorphoMarket");
        MarketParams memory lp = IMorpho(MORPHO).idToMarketParams(Id.wrap(id));
        assertEq(lp.loanToken, AVKAT);
        assertEq(lp.collateralToken, live);
        assertEq(lp.lltv, LLTV);
        assertEq(lp.irm, IRM);
        assertEq(IporVaultHaircutOracle12(lp.oracle).price(), IVaultW(VAULT).convertToAssets(w.convertToAssets(1e20)) * 1e16 * 88 / 100);
    }
}
