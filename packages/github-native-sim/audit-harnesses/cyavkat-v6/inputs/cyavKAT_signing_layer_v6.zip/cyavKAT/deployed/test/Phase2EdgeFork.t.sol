// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.30;

import "./Phase2Fork.t.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {TickMath} from "contracts/fuses/uniswap/ext/TickMath.sol";
import {INonfungiblePositionManager} from "contracts/fuses/uniswap/ext/INonfungiblePositionManager.sol";
import {Market} from "@morpho-org/morpho-blue/src/interfaces/IMorpho.sol";
import {ICyFeeRouter} from "../src/lp/CurveYieldSushiLpHolder.sol";
import {ICyEpochClock, ICyGaugeVoter} from "../src/vkat/CurveYieldVkatInterfaces.sol";
import {IVaultLS} from "./helpers/LendingForkSetup.sol";

interface IVaultT2 {
    function updateMarketsBalances(uint256[] calldata marketIds) external returns (uint256);
}

interface IPoolX {
    function swap(address recipient, bool zeroForOne, int256 amountSpecified, uint160 sqrtPriceLimitX96, bytes calldata data)
        external returns (int256, int256);
    function slot0() external view returns (uint160, int24, uint16, uint16, uint16, uint8, bool);
}

interface IWrapperE {
    function previewMint(uint256 shares) external view returns (uint256);
    function deposit(uint256 assets, address receiver) external returns (uint256);
}

interface IOracleX {
    function price() external view returns (uint256);
}

/// @dev Swaps straight against the 1% pool (exact-in of its whole balance) up to a price limit.
contract PoolSwapper {
    using SafeERC20 for IERC20;

    address public immutable POOL;
    address public immutable AVKAT_;
    address public immutable KAT_;

    constructor(address pool_, address avkat_, address kat_) {
        (POOL, AVKAT_, KAT_) = (pool_, avkat_, kat_);
    }

    function swap(bool zeroForOne_, uint160 limit_) external {
        uint256 bal = IERC20(zeroForOne_ ? AVKAT_ : KAT_).balanceOf(address(this));
        IPoolX(POOL).swap(address(this), zeroForOne_, int256(bal), limit_, "");
    }

    function uniswapV3SwapCallback(int256 a0_, int256 a1_, bytes calldata) external {
        require(msg.sender == POOL, "not pool");
        if (a0_ > 0) IERC20(AVKAT_).safeTransfer(msg.sender, uint256(a0_));
        if (a1_ > 0) IERC20(KAT_).safeTransfer(msg.sender, uint256(a1_));
    }
}

/// @notice Phase 2 edge-case fork tests (scenarios 1-4, 6, 7, 9-12). Scenarios 5 and 8 live in MigrationEdgeFork.
/// Inherits Phase2Fork for setUp and helpers, so the parent's tests run again under this contract; filter with
/// `--match-contract Phase2EdgeFork` or `bash run-tests.sh test_edge`.
contract Phase2EdgeFork is Phase2Fork {
    PoolSwapper internal swapper;

    // ---------------------------------------------------------------- helpers: pool

    function _pool() internal returns (PoolSwapper) {
        if (address(swapper) == address(0)) swapper = new PoolSwapper(POOL_1PCT, AVKAT, KAT);
        return swapper;
    }

    function _tick() internal view returns (int24 t_) {
        (, t_,,,,,) = IPoolX(POOL_1PCT).slot0();
    }

    /// @dev Moves the pool price to `target_` (a tick boundary) with exact-in swaps against the pool.
    function _swapTo(int24 target_) internal {
        int24 cur = _tick();
        if (target_ == cur) return;
        bool down = target_ < cur;
        PoolSwapper s = _pool();
        deal(down ? AVKAT : KAT, address(s), 1e27);
        s.swap(down, TickMath.getSqrtRatioAtTick(target_));
    }

    /// @dev Round trips across [lo_, hi_] so the position earns pool fees on volume.
    function _churn(uint256 rounds_, int24 lo_, int24 hi_) internal {
        for (uint256 i; i < rounds_; ++i) {
            _swapTo(lo_ + 10);
            _swapTo(hi_ - 10);
        }
    }

    function _openLp() internal returns (CurveYieldSushiLpHolder h_) {
        _installLpSet();
        vm.prank(keeper);
        executor.deployAssets();
        h_ = lpc.holder();
        require(h_.tokenId() != 0, "LP not opened");
    }

    /// @dev What the position has earned and not yet collected, measured by a collect that is reverted.
    function _pendingFees(CurveYieldSushiLpHolder h_) internal returns (uint256 f0_, uint256 f1_) {
        uint256 snap = vm.snapshot();
        uint256 id = h_.tokenId();
        vm.prank(address(h_));
        (f0_, f1_) = INonfungiblePositionManager(NPM).collect(
            INonfungiblePositionManager.CollectParams({
                tokenId: id, recipient: address(0xdead), amount0Max: type(uint128).max, amount1Max: type(uint128).max
            })
        );
        vm.revertTo(snap);
    }


    // ---------------------------------------------------------------- 1. LP: no rebalance when unprofitable

    function test_edge01_lpNoRebalanceWhenUnprofitable() public {
        CurveYieldSushiLpHolder h = _openLp();
        (int24 lo0, int24 hi0) = (h.tickLower(), h.tickUpper());
        console2.log("range lower / upper / start tick");
        console2.logInt(lo0);
        console2.logInt(hi0);
        console2.logInt(_tick());

        // Large avKAT -> KAT swaps through the router until the price is below the lower tick.
        address whale = makeAddr("whale");
        bool viaRouter;
        uint256 amt = 200_000e18;
        for (uint256 i; i < 14 && _tick() >= lo0; ++i) {
            deal(AVKAT, whale, amt);
            vm.startPrank(whale);
            IErc20T(AVKAT).approve(ROUTER, amt);
            try ICyFeeRouter(ROUTER).swapExactInput(AVKAT, KAT, amt, 0, whale, block.timestamp) {
                viaRouter = true;
            } catch {
                vm.stopPrank();
                break;
            }
            vm.stopPrank();
            amt *= 2;
        }
        if (_tick() >= lo0) _swapTo(lo0 - 100); // router refused (or too shallow): finish against the pool
        console2.log("moved via router:", viaRouter);
        console2.log("tick after dump");
        console2.logInt(_tick());
        assertLt(_tick(), lo0, "price not below the lower tick");

        (,, bool valid) = lpc.optimalRange();
        console2.log("optimal range valid / close value / basis", valid, lpc.closeValueAvkat(), h.basisAvkat());
        assertFalse(lpc.needsRebalance(), "needsRebalance while unprofitable");
        vm.prank(keeper);
        executor.rebalance();
        assertEq(h.tickLower(), lo0, "lower tick moved");
        assertEq(h.tickUpper(), hi0, "upper tick moved");
    }

    // ---------------------------------------------------------------- 2. LP: rebalance when profitable

    function test_edge02_lpRebalanceWhenProfitable() public {
        CurveYieldSushiLpHolder h = _openLp();
        (int24 lo, int24 hi) = (h.tickLower(), h.tickUpper());
        uint256 basis0 = h.basisAvkat();
        _churn(10, lo, hi);
        (uint256 f0, uint256 f1) = _pendingFees(h);
        console2.log("uncollected fees avKAT / KAT", f0, f1);
        console2.log("after swaps: close value / basis", lpc.closeValueAvkat(), h.basisAvkat());
        h.collectFees(); // permissionless: fees move into the holder, where position() values them
        console2.log("after collectFees: close value / basis", lpc.closeValueAvkat(), h.basisAvkat());
        if (lpc.closeValueAvkat() < h.basisAvkat()) {
            console2.log("closeValueAvkat still below the basis after collecting fees");
            vm.skip(true);
        }

        // needsRebalance() now has hysteresis: it needs the conversion edge to move or the price to leave the range.
        // Move the price just below the lower tick (still profitable to close once fees are collected), then let the
        // router's 15-minute TWAP catch up with the new price before the rebalance swaps.
        bool candidate;
        bool done;
        for (int24 t = lo - 5; t > lo - 400 && !done; t -= 100) {
            uint256 snap = vm.snapshot();
            _swapTo(t);
            vm.warp(block.timestamp + 1800);
            vm.roll(block.number + 900);
            (int24 ol, int24 ou, bool valid) = lpc.optimalRange();
            if (valid && lpc.needsRebalance()) {
                candidate = true;
                uint256 basisBefore = h.basisAvkat();
                h.collectFees(); // the way the bot does it: the controller's planReduce reads the uncollected view
                vm.prank(keeper);
                try executor.rebalance() {
                    console2.log("rebalanced at tick; optimal range");
                    console2.logInt(t);
                    console2.logInt(ol);
                    console2.logInt(ou);
                    (int24 nl, int24 nu,) = lpc.optimalRange();
                    console2.log("after rebalance: pool tick / optimalRange() now / needsRebalance");
                    console2.logInt(_tick());
                    console2.logInt(nl);
                    console2.logInt(nu);
                    console2.log(lpc.needsRebalance());
                    // The range chosen at rebalance time: the holder's own KAT->avKAT sweep then moves the (thin) pool's price,
                    // so optimalRange() recomputed afterwards can differ.
                    assertEq(h.tickLower(), ol, "lower not at the optimal range");
                    assertEq(h.tickUpper(), ou, "upper not at the optimal range");
                    assertEq(h.basisAvkat(), basisBefore, "basis changed by the rebalance");
                    assertGe(lpc.closeValueAvkat(), h.basisAvkat(), "close value below basis after the rebalance");
                    // 4f: hysteresis. The holder's own swap moved the tick, but inside the new range: no immediate churn.
                    assertFalse(lpc.needsRebalance(), "needsRebalance still true after the rebalance (no hysteresis)");
                    assertLe(basis0, basisBefore, "basis shrank");
                    done = true;
                } catch (bytes memory err) {
                    console2.log("rebalance reverted at tick");
                    console2.logInt(t);
                    console2.logBytes(err);
                }
            }
            if (!done) vm.revertTo(snap);
        }
        if (!candidate) {
            console2.log("needsRebalance never true below the range while closing is profitable");
            vm.skip(true);
        }
        assertTrue(done, "needsRebalance was true but executor.rebalance() reverted at every candidate price");
    }

    // ---------------------------------------------------------------- 4c. LP open: market 7 accounting

    function test_edge13_lpOpenIsValuedInMarket7() public {
        _installLpSet();
        IVaultLS vault = IVaultLS(VAULT);
        uint256 m7Before = vault.totalAssetsInMarket(7);
        uint256 totalBefore = vault.totalAssets();
        vm.prank(keeper);
        executor.deployAssets();
        CurveYieldSushiLpHolder h = lpc.holder();
        assertGt(h.tokenId(), 0, "LP not opened");
        uint256 basis = h.basisAvkat();
        uint256 m7After = vault.totalAssetsInMarket(7);
        uint256 net = lpc.managedAvkat(); // holder net value in avKAT at the conversion rate
        console2.log("market 7 before / after / holder net value", m7Before, m7After, net);
        assertGt(m7After, m7Before, "market 7 did not rise");
        assertApproxEqRel(m7After - m7Before, net, 0.005e18, "market 7 rise != LP net value (oracle prices, 0.5%)");
        // No share-price step beyond the LP's entry cost (the 1% pool fee on the KAT side of the position).
        uint256 totalAfter = vault.totalAssets();
        assertGe(totalAfter + basis / 100, totalBefore, "share price stepped down by more than the entry cost");
        assertLe(totalAfter, totalBefore + basis / 200, "share price stepped up");
    }

    // ---------------------------------------------------------------- 4d. pending fees are valued before collection

    function test_edge14_pendingFeesValuedBeforeCollect() public {
        CurveYieldSushiLpHolder h = _openLp();
        (int24 lo, int24 hi) = (h.tickLower(), h.tickUpper());
        int24 startTick = _tick();
        CyLpPosition memory p0 = h.position();
        _churn(4, lo, hi);
        _swapTo(startTick); // back to the same tick: LP amounts differ only by the fees
        CyLpPosition memory p1 = h.position();
        (uint256 f0, uint256 f1) = _pendingFees(h);
        console2.log("pending fees avKAT / KAT", f0, f1);
        console2.log("lpAvkat before / after", p0.lpAvkat, p1.lpAvkat);
        console2.log("lpKat before / after", p0.lpKat, p1.lpKat);
        assertGt(f0 + f1, 0, "no fees earned");
        assertGt(p1.lpAvkat, p0.lpAvkat, "pending avKAT fees not in position().lpAvkat");
        assertGt(p1.lpKat, p0.lpKat, "pending KAT fees not in position().lpKat");

        IVaultLS vault = IVaultLS(VAULT);
        uint256[] memory m = new uint256[](1);
        m[0] = 7;
        vm.prank(DEPLOYER); // holds UPDATE_MARKETS_BALANCES
        IVaultT2(VAULT).updateMarketsBalances(m);
        uint256 m7a = vault.totalAssetsInMarket(7);
        h.collectFees();
        vm.prank(DEPLOYER);
        IVaultT2(VAULT).updateMarketsBalances(m);
        uint256 m7b = vault.totalAssetsInMarket(7);
        console2.log("market 7 before / after collectFees", m7a, m7b);
        assertApproxEqRel(m7a, m7b, 1e9, "collectFees changed market 7"); // 1e-9 relative
    }

    // ---------------------------------------------------------------- 4e. native exit: accounting

    function test_edge15_nativeExitAccounting() public {
        _installVkatSet();
        _bigScheduledRequest();
        IVaultLS vault = IVaultLS(VAULT);
        uint256 total0 = vault.totalAssets();
        uint256 m7a = vault.totalAssetsInMarket(7);
        vm.prank(keeper);
        executor.startNativeExit();
        vm.roll(block.number + 1);
        vm.warp(block.timestamp + 2);
        vm.prank(keeper);
        executor.beginNativeExits();
        uint256 total1 = vault.totalAssets();
        uint256 m7b = vault.totalAssetsInMarket(7);
        uint256 exitingKat = vkat.exitingKat();
        uint256 exitingAvkat = _avkat(exitingKat);
        console2.log("exiting KAT / avKAT", exitingKat, exitingAvkat);
        console2.log("totalAssets before / after", total0, total1);
        console2.log("market 7 before / after", m7a, m7b);
        assertGt(exitingKat, 0, "no exit started");
        assertGt(m7b, m7a, "exiting KAT not in market 7");
        // The exit costs at most the 2.5% minimum fee on the exiting amount, plus conversion rounding.
        uint256 drop = total0 > total1 ? total0 - total1 : 0;
        assertLe(drop, exitingAvkat * 250 / 10_000 + exitingAvkat / 1_000, "total assets dropped by more than the 2.5% fee");
    }


    // ---------------------------------------------------------------- 3. LP allocation follows yield

    function test_edge03_lpAllocationFollowsYield() public {
        CurveYieldSushiLpHolder h = _openLp();
        (int24 lo, int24 hi) = (h.tickLower(), h.tickUpper());
        // Lending yield must not depend on live market state: an outside supplier and borrower make the market busy.
        _outsideSupply(5_000e18);
        _borrowDownTo(1_000e18);
        // No swap churn here: position() now values pending fees, so churn would add unmeasured yield on top of the
        // controlled top-ups below. The LP yield is set by _addYield alone.
        lo;
        hi;
        uint256 anchorVpb = lpc.anchorValuePerBasis();
        uint256 t0 = lpc.anchorTime();
        assertGt(t0, 0, "no checkpoint at open");

        vm.warp(block.timestamp + 3 days); // inside the 7-day window: the checkpoint has not re-anchored yet
        uint256 lend = lpc.lendYieldBps(); // read after the warp: the market's adaptive rate moves with time
        console2.log("lending yield bps", lend);
        assertGt(lend, 0, "no lending yield to compare against");
        uint256 dt = block.timestamp - t0;
        uint256 basis = h.basisAvkat();

        // Fee income lands in the holder (fees are only credited when collected): add what makes the LP yield
        // beat lending by ~60%, then by ~150%.
        _addYield(h, lend * 160 / 100, dt, anchorVpb, basis);
        uint256 lp1 = lpc.lpYieldBps();
        uint256 adv1 = lp1 > lend ? (lp1 - lend) * 10_000 / lend : 0;
        console2.log("LP yield / advantage bps / target", lp1, adv1, lpc.targetAllocationBps());
        assertGt(adv1, 3_000, "advantage not above +30%");
        assertLt(adv1, 10_000, "advantage already at +100%");
        assertGt(lpc.targetAllocationBps(), 200, "allocation not above the floor at +30%..+100%");
        assertLt(lpc.targetAllocationBps(), 500, "allocation at the ceiling before +100%");

        _addYield(h, lend * 230 / 100, dt, anchorVpb, basis);
        uint256 lp2 = lpc.lpYieldBps();
        uint256 adv2 = lp2 > lend ? (lp2 - lend) * 10_000 / lend : 0;
        console2.log("LP yield / advantage bps / target", lp2, adv2, lpc.targetAllocationBps());
        assertGe(adv2, 10_000, "advantage not at +100%");
        assertEq(lpc.targetAllocationBps(), 500, "allocation not at the 5% ceiling");

        // Once the 7-day window has passed, the next LP action re-anchors the yield checkpoint.
        vm.warp(t0 + 7 days + 1);
        FuseAction[] memory a = new FuseAction[](1);
        a[0] = FuseAction(lpc.fuses().increase, abi.encodeWithSignature("enter(uint256)", 10e18));
        vm.prank(address(executor));
        IVaultT(VAULT).execute(a);
        assertEq(lpc.anchorTime(), block.timestamp, "checkpoint not re-anchored by an LP action");
    }

    /// @dev Tops the holder up so the trailing LP yield reads `targetBps_` (deal of avKAT stands in for collected fees).
    function _addYield(CurveYieldSushiLpHolder h_, uint256 targetBps_, uint256 dt_, uint256 anchorVpb_, uint256 basis_) internal {
        uint256 have = lpc.managedAvkat();
        uint256 wantVpb = anchorVpb_ + anchorVpb_ * targetBps_ * dt_ / (10_000 * 365 days);
        uint256 wantManaged = wantVpb * basis_ / 1e18;
        if (wantManaged > have) deal(AVKAT, address(h_), IErc20T(AVKAT).balanceOf(address(h_)) + (wantManaged - have));
    }

    // ---------------------------------------------------------------- outside borrower on the lending market

    /// @dev An outside borrower wraps cyavKAT into wcyavKAT (the market's collateral), supplies it, and borrows until
    /// `availableAvkat_` is left.
    function _borrowDownTo(uint256 availableAvkat_) internal {
        address borrower = makeAddr("borrower");
        MarketParams memory mp = IMorpho(MORPHO).idToMarketParams(Id.wrap(LEND_MARKET));
        IWrapperE wrapper_ = IWrapperE(mp.collateralToken);
        (uint256 supplyAssets,, uint256 borrowAssets,) = _marketTotals();
        uint256 borrow_ = supplyAssets - borrowAssets - availableAvkat_;
        uint256 price = IOracleX(mp.oracle).price(); // loan per collateral (wcyavKAT), 1e36 scale
        uint256 wNeeded = borrow_ * 1e36 / price * 1e18 / mp.lltv * 110 / 100 + 1e18;
        uint256 cyNeeded = wrapper_.previewMint(wNeeded) * 105 / 100 + 1e18;
        uint256 assets = IVaultT(VAULT).convertToAssets(cyNeeded) * 105 / 100 + 1e18;
        deal(AVKAT, borrower, assets);
        vm.startPrank(borrower);
        IErc20T(AVKAT).approve(VAULT, assets);
        uint256 cy = IVaultT(VAULT).deposit(assets, borrower);
        IErc20T(VAULT).approve(address(wrapper_), cy);
        uint256 w = wrapper_.deposit(cy, borrower);
        IErc20T(address(wrapper_)).approve(MORPHO, w);
        IMorpho(MORPHO).supplyCollateral(mp, w, borrower, "");
        IMorpho(MORPHO).borrow(mp, borrow_, 0, borrower, borrower);
        vm.stopPrank();
    }

    function _marketTotals() internal view returns (uint256 supply_, uint256 supplyShares_, uint256 borrow_, uint256 borrowShares_) {
        Market memory m = IMorpho(MORPHO).market(Id.wrap(LEND_MARKET));
        (supply_, supplyShares_, borrow_, borrowShares_) =
            (m.totalSupplyAssets, m.totalSupplyShares, m.totalBorrowAssets, m.totalBorrowShares);
    }

    // ---------------------------------------------------------------- 4. lending liquidity trigger

    function test_edge04_lendingLiquidityTrigger() public {
        _installLendSet();
        _outsideSupply(10_000e18);
        vm.prank(keeper);
        executor.deployAssets();
        uint256 lent0 = lend.marketState().vaultSupply;
        assertGt(lent0, 0, "nothing lent");
        assertFalse(lend.marketState().liquidityTriggered, "triggered before any borrow");

        // Leave ~60% of the vault's lent amount available: below its supply, above the 3% floor.
        _borrowDownTo(lent0 * 6 / 10);
        CurveYieldAvkatLendController.MarketState memory m = lend.marketState();
        console2.log("available / vault supply / total supply", m.available, m.vaultSupply, m.totalSupply);
        assertTrue(m.liquidityTriggered, "liquidityTriggered false");
        assertLt(m.vaultSupply, 10_000e18, "test needs the lent amount inside the 10k exemption");

        vm.prank(keeper);
        executor.rebalance();
        uint256 lent1 = lend.marketState().vaultSupply;
        console2.log("lent before / after rebalance", lent0, lent1);
        assertLt(lent1, lent0, "no reduction (stopped at the 10k exemption?)");
        assertLe(lent0 - lent1, lent0 / 10 + 1, "reduced by more than 10% of lent");

        vm.prank(keeper);
        executor.deployAssets();
        assertLe(lend.marketState().vaultSupply, lent1, "deployAssets added to lending while triggered");
        assertEq(lend.marketState().vaultSupply, lent1, "changed inside the 12h decay interval");
    }

    // ---------------------------------------------------------------- 10. over-cap reduce respects the liquidity floor

    function test_edge10_lendingOverCapReduceKeepsLiquidityFloor() public {
        _installLendSet();
        _outsideSupply(10_000e18);
        vm.prank(keeper);
        executor.deployAssets();
        uint256 lent0 = lend.marketState().vaultSupply;
        assertGt(lent0, 0, "nothing lent");

        // Only ~4% of the market's supply is available: the floor (3%) leaves a sliver to withdraw.
        (uint256 supply,,,) = _marketTotals();
        _borrowDownTo(supply * 400 / 10_000);
        CyLendParams memory p = lend.params();
        p.capBps = 200; // far below the current lent share
        vm.prank(DEPLOYER);
        lend.setParams(p);

        vm.prank(keeper);
        executor.rebalance();
        CurveYieldAvkatLendController.MarketState memory m = lend.marketState();
        console2.log("lent before / after, available, total", lent0, m.vaultSupply, m.available);
        console2.log(m.totalSupply);
        assertLt(m.vaultSupply, lent0, "nothing reduced");
        assertGe(m.available * 10_000, m.totalSupply * 300, "market liquidity fell below 3% of supply");
    }

    // ---------------------------------------------------------------- vKAT helpers

    function _setVkatAllocation(uint16 bps_) internal {
        CyVkatParams memory p = vkat.params();
        p.allocationBps = bps_;
        vm.prank(DEPLOYER);
        vkat.setParams(p);
    }

    function _warpIntoVoteWindow() internal {
        ICyEpochClock clock = ICyEpochClock(EPOCH_CLOCK);
        uint256 window = vkat.params().deployWindow;
        console2.log("epoch duration / elapsed / vote ends in", clock.epochDuration(), clock.elapsedInEpoch(), clock.epochVoteEndsIn());
        if (clock.epochVoteEndsIn() > window) vm.warp(block.timestamp + (clock.epochVoteEndsIn() - window) + 1 hours);
        console2.log("after warp: elapsed / vote ends in", clock.elapsedInEpoch(), clock.epochVoteEndsIn());
        assertLe(clock.epochVoteEndsIn(), window, "not in the last 3 days of the vote");
        assertTrue(ICyGaugeVoter(GAUGE_VOTER).votingActive(), "voting not active");
    }

    // ---------------------------------------------------------------- 6. vKAT lock + vote + convert

    function test_edge06_vkatLockVoteConvert() public {
        _installVkatSet();
        _setVkatAllocation(1_000);
        _warpIntoVoteWindow();
        CurveYieldAllocationController.Budgets memory b = allocation.budgets();
        console2.log("managed / idle / strategic budget", b.managed, b.idle, b.strategicBudget);

        vm.prank(keeper);
        executor.deployAssets();
        uint256 pos = vkat.positionAvkat();
        console2.log("vKAT position id / avKAT", vkat.positionTokenId(), pos);
        assertTrue(vkat.positionTokenId() != 0, "no position");
        assertGt(pos, 0, "empty position");
        assertLe(pos, b.strategicBudget, "position above the reserve budget");
        assertLe(pos, b.managed * 1_000 / 10_000 + 1, "position above its 10% target");

        // First half of the next epoch: shrink the target to 0 and convert back.
        ICyEpochClock clock = ICyEpochClock(EPOCH_CLOCK);
        vm.warp(block.timestamp + (clock.epochDuration() - clock.elapsedInEpoch()) + 1 hours);
        console2.log("next epoch: elapsed / duration", clock.elapsedInEpoch(), clock.epochDuration());
        assertLt(clock.elapsedInEpoch(), clock.epochDuration() / 2, "not in the first half");
        _setVkatAllocation(0);
        assertTrue(vkat.conversionAvailable(), "conversion not available");
        uint256 idle0 = IErc20T(AVKAT).balanceOf(VAULT);
        vm.prank(keeper);
        executor.rebalance();
        uint256 posAfter = vkat.positionAvkat();
        uint256 idle1 = IErc20T(AVKAT).balanceOf(VAULT);
        console2.log("position after / idle gained", posAfter, idle1 - idle0);
        assertLt(posAfter, pos / 100, "position not converted back");
        assertApproxEqRel(idle1 - idle0, pos, 0.02e18, "avKAT did not come back to the vault");
    }

    // ---------------------------------------------------------------- 7. native lane from the vKAT position

    function test_edge07_nativeLaneStartsFromVkatPosition() public {
        _installVkatSet();
        // A big deposit that the loop absorbs (permissive ramp), so idle is small.
        deal(AVKAT, user, 25_000e18);
        vm.prank(user);
        IVaultT(VAULT).deposit(20_000e18, user);
        CyLoopParams memory lp = _loopParams();
        lp.rampStartProfitBps = 250;
        lp.rampEndProfitBps = 400;
        vm.prank(DEPLOYER);
        loop.setParams(lp);
        vm.prank(keeper);
        executor.deployAssets();

        // vKAT position inside the deploy window.
        _setVkatAllocation(1_000);
        _warpIntoVoteWindow();
        vm.prank(keeper);
        executor.deployAssets();
        uint256 pos = vkat.positionAvkat();
        console2.log("vKAT position avKAT", pos);
        assertTrue(vkat.positionTokenId() != 0, "no vKAT position");
        assertGt(pos, 0, "empty vKAT position");

        // A scheduled request larger than idle.
        uint256 shares = IVaultT(VAULT).balanceOf(user);
        vm.prank(user);
        IWmReqT(address(wm)).requestShares(shares);
        vm.warp(block.timestamp + 60);
        uint256 needed = IVaultT(VAULT).convertToAssets(shares);
        uint256 idle = IErc20T(AVKAT).balanceOf(VAULT);
        console2.log("idle / needed", idle, needed);
        assertGt(needed, idle, "request not larger than idle");

        vm.prank(keeper);
        executor.startNativeExit();
        assertGt(vkat.exitingTokens().length, 0, "no exit ticket in the same block: position not used first");
        assertLt(vkat.positionAvkat(), pos, "position not drawn on");
    }

    // ---------------------------------------------------------------- 9. exact wind-up profit split

    function test_edge09_windupProfitSplitIsExact() public {
        CyLoopParams memory p = _loopParams();
        p.rampStartProfitBps = 250;
        p.rampEndProfitBps = 400;
        vm.prank(DEPLOYER);
        loop.setParams(p);
        uint256 custody0 = IErc20T(AVKAT).balanceOf(CUSTODY);
        uint256 splitter0 = IErc20T(AVKAT).balanceOf(address(splitter));

        vm.recordLogs();
        vm.prank(keeper);
        executor.deployAssets();
        Vm.Log[] memory logs = vm.getRecordedLogs();

        bytes32 sig = keccak256("LoopProfitSplit(uint256,uint256,uint256,uint256,uint256)");
        uint256 events;
        uint256 sumGrowth;
        uint256 sumContributors;
        for (uint256 i; i < logs.length; ++i) {
            if (logs[i].topics[0] != sig) continue;
            ++events;
            (uint256 profit, uint256 growth, uint256 contributors, uint256 vaultShare, uint256 rewardsManager) =
                abi.decode(logs[i].data, (uint256, uint256, uint256, uint256, uint256));
            console2.log("profit / growth / contributors", profit, growth, contributors);
            console2.log("vault / rewardsManager", vaultShare, rewardsManager);
            assertEq(growth, profit * 3_500 / 10_000, "growth not 35%");
            assertEq(contributors, profit * 2_000 / 10_000, "contributors not 20%");
            assertEq(rewardsManager, profit * 2_500 / 10_000, "rewards manager not 25%");
            assertApproxEqAbs(vaultShare, profit * 2_000 / 10_000, 3, "vault remainder not 20%");
            assertEq(growth + contributors + vaultShare + rewardsManager, profit, "parts do not sum to the profit");
            sumGrowth += growth;
            sumContributors += contributors;
        }
        assertGt(events, 0, "no LoopProfitSplit event");
        assertEq(IErc20T(AVKAT).balanceOf(CUSTODY) - custody0, sumGrowth, "custody did not receive the growth share");
        assertEq(IErc20T(AVKAT).balanceOf(address(splitter)) - splitter0, sumContributors, "splitter did not hold the contributors share");
    }

    // ---------------------------------------------------------------- 11. bounds

    function test_edge11_boundsLoop() public {
        CyLoopParamBounds memory b = loop.bounds();
        CyBound[13] memory r = [
            b.allocationBps, b.rampZoneBps, b.profitBps, b.profitBps, b.profitBps, b.profitBps, b.lossBufferBps,
            b.targetLtvBps, b.emergencyLtvBps, b.emergencyTargetLtvBps, b.ltvRebalanceToleranceBps, b.reduceLossBps,
            b.maxCycles
        ];
        for (uint256 f; f < 13; ++f) _edges(address(loop), f, r[f], _loopEdge, "loop");
    }

    function _loopEdge(uint256 f_, uint256 v_) internal view returns (bytes memory) {
        CyLoopParams memory p = _loopParams();
        uint16 v = uint16(v_);
        if (f_ == 0) p.allocationBps = v;
        else if (f_ == 1) p.rampZoneBps = v;
        else if (f_ == 2) p.baseWindupProfitBps = v;
        else if (f_ == 3) {
            p.rampStartProfitBps = v;
            if (v > p.rampEndProfitBps) p.rampEndProfitBps = v;
        } else if (f_ == 4) {
            p.rampEndProfitBps = v;
            if (p.rampStartProfitBps > v) p.rampStartProfitBps = v;
        } else if (f_ == 5) p.minUnwindProfitBps = v;
        else if (f_ == 6) p.lossBufferBps = v;
        else if (f_ == 7) {
            p.targetLtvBps = v;
            if (p.emergencyTargetLtvBps < v) p.emergencyTargetLtvBps = v;
            if (p.emergencyLtvBps <= p.emergencyTargetLtvBps) p.emergencyLtvBps = p.emergencyTargetLtvBps + 1;
        } else if (f_ == 8) {
            p.emergencyLtvBps = v;
            if (p.emergencyTargetLtvBps >= v) p.emergencyTargetLtvBps = v - 1;
            if (p.targetLtvBps > p.emergencyTargetLtvBps) p.targetLtvBps = p.emergencyTargetLtvBps;
        } else if (f_ == 9) {
            p.emergencyTargetLtvBps = v;
            if (p.targetLtvBps > v) p.targetLtvBps = v;
            if (p.emergencyLtvBps <= v) p.emergencyLtvBps = v + 1;
        } else if (f_ == 10) p.ltvRebalanceToleranceBps = v;
        else if (f_ == 11) p.reduceLossBps = v;
        else p.maxCycles = uint8(v_);
        return abi.encodeCall(CurveYieldMorphoLoopController.setParams, (p));
    }

    function test_edge11_boundsVkat() public {
        CyVkatParamBounds memory b = vkat_bounds();
        CyBound[3] memory r = [b.allocationBps, b.nativeExitMaxLtvBps, b.deployWindow];
        for (uint256 f; f < 3; ++f) _edges(address(vkat), f, r[f], _vkatEdge, "vkat");
    }

    function vkat_bounds() internal returns (CyVkatParamBounds memory) {
        _installVkatSet();
        return vkat.bounds();
    }

    function _vkatEdge(uint256 f_, uint256 v_) internal view returns (bytes memory) {
        CyVkatParams memory p = vkat.params();
        if (f_ == 0) p.allocationBps = uint16(v_);
        else if (f_ == 1) p.nativeExitMaxLtvBps = uint16(v_);
        else p.deployWindow = uint32(v_);
        return abi.encodeCall(CurveYieldVkatController.setParams, (p));
    }

    function test_edge11_boundsLend() public {
        _installLendSet();
        CyLendParamBounds memory b = lend.bounds();
        CyBound[6] memory r =
            [b.capBps, b.ownershipTriggerBps, b.decayBps, b.decayInterval, b.liquidityFloorBps, b.ownershipExemptAvkat];
        for (uint256 f; f < 6; ++f) _edges(address(lend), f, r[f], _lendEdge, "lend");
    }

    function _lendEdge(uint256 f_, uint256 v_) internal view returns (bytes memory) {
        CyLendParams memory p = lend.params();
        if (f_ == 0) p.capBps = uint16(v_);
        else if (f_ == 1) p.ownershipTriggerBps = uint16(v_);
        else if (f_ == 2) p.decayBps = uint16(v_);
        else if (f_ == 3) p.decayInterval = uint32(v_);
        else if (f_ == 4) p.liquidityFloorBps = uint16(v_);
        else p.ownershipExemptAvkat = uint128(v_);
        return abi.encodeCall(CurveYieldAvkatLendController.setParams, (p));
    }

    function test_edge11_boundsLp() public {
        _installLpSet();
        CyLpParamBounds memory b = lpc.bounds();
        CyBound[12] memory r = [
            b.allocationBps, b.allocationBps, b.advantageBps, b.advantageBps, b.minKatBps, b.lossBps, b.lossBps,
            b.ltvBps, b.ltvBps, b.ltvBps, b.slippageBps, b.yieldWindow
        ];
        for (uint256 f; f < 12; ++f) _edges(address(lpc), f, r[f], _lpEdge, "lp");
    }

    /// @dev Returns empty when the value is a bound edge that the ordering rules make impossible for that field
    /// (advantageStart < advantageFull, target <= emergencyTarget < emergency), so only that edge is skipped.
    function _lpEdge(uint256 f_, uint256 v_) internal view returns (bytes memory) {
        CyLpParams memory p = lpc.params();
        uint16 v = uint16(v_);
        if (f_ == 0) {
            p.minBps = v;
            if (v > p.maxBps) p.maxBps = v;
        } else if (f_ == 1) {
            p.maxBps = v;
            if (p.minBps > v) p.minBps = v;
        } else if (f_ == 2) {
            if (v_ == 50_000) return ""; // needs advantageFull > 50,000
            p.advantageStartBps = v;
            if (v >= p.advantageFullBps) p.advantageFullBps = v + 1;
        } else if (f_ == 3) {
            if (v_ == 0) return ""; // needs advantageStart < 0
            p.advantageFullBps = v;
            if (p.advantageStartBps >= v) p.advantageStartBps = v - 1;
        } else if (f_ == 4) p.minKatBps = v;
        else if (f_ == 5) p.standardLossBps = v;
        else if (f_ == 6) p.scheduledLossBps = v;
        else if (f_ == 7) {
            if (v_ == 7_690) return ""; // needs emergency > 7,690
            p.targetLtvBps = v;
            if (p.emergencyTargetLtvBps < v) p.emergencyTargetLtvBps = v;
            if (p.emergencyLtvBps <= p.emergencyTargetLtvBps) p.emergencyLtvBps = p.emergencyTargetLtvBps + 1;
        } else if (f_ == 8) {
            if (v_ == 5_000) return ""; // needs emergencyTarget < 5,000
            p.emergencyLtvBps = v;
            if (p.emergencyTargetLtvBps >= v) p.emergencyTargetLtvBps = v - 1;
            if (p.targetLtvBps > p.emergencyTargetLtvBps) p.targetLtvBps = p.emergencyTargetLtvBps;
        } else if (f_ == 9) {
            if (v_ == 7_690) return ""; // needs emergency > 7,690
            p.emergencyTargetLtvBps = v;
            if (p.targetLtvBps > v) p.targetLtvBps = v;
            if (p.emergencyLtvBps <= v) p.emergencyLtvBps = v + 1;
        } else if (f_ == 10) p.slippageBps = v;
        else p.yieldWindow = uint32(v_);
        return abi.encodeCall(CurveYieldSushiLpController.setParams, (p));
    }

    function test_edge11_boundsAllocationVaultFloor() public {
        CyBound memory b = allocation.vaultFloorBound();
        _edges(address(allocation), 0, b, _floorEdge, "vaultFloor");
    }

    function _floorEdge(uint256, uint256 v_) internal pure returns (bytes memory) {
        return abi.encodeCall(CurveYieldAllocationController.setVaultFloorBps, (uint16(v_)));
    }

    function test_edge11_boundsSplitter() public {
        CyBound memory b = splitter.categoryBound();
        for (uint256 c; c < 4; ++c) _edges(address(splitter), c, b, _splitEdge, "splitter");
    }

    /// @dev Sets category `c_` to `v_` and spreads the difference over the others so the parts still sum to 100%.
    function _splitEdge(uint256 c_, uint256 v_) internal view returns (bytes memory) {
        uint256[4] memory s = [uint256(3_500), 2_000, 2_000, 2_500];
        uint256 max = splitter.categoryBound().max;
        int256 delta = int256(s[c_]) - int256(v_);
        s[c_] = v_;
        for (uint256 i; i < 4; ++i) {
            if (i == c_ || delta == 0) continue;
            if (delta > 0) {
                uint256 add = uint256(delta) < max - s[i] ? uint256(delta) : max - s[i];
                s[i] += add;
                delta -= int256(add);
            } else {
                uint256 take = uint256(-delta) < s[i] ? uint256(-delta) : s[i];
                s[i] -= take;
                delta += int256(take);
            }
        }
        if (delta != 0) return "";
        return abi.encodeCall(CurveYieldLoopProfitSplitter.setSplit, (uint16(s[0]), uint16(s[1]), uint16(s[2]), uint16(s[3])));
    }

    function test_edge11_boundsExecutorReward() public {
        (CyBound memory bps, CyBound memory cap) = executor.rewardBounds();
        _edges(address(executor), 0, bps, _rewardEdge, "rewardBps");
        _edges(address(executor), 1, cap, _rewardEdge, "rewardCap");
    }

    function _rewardEdge(uint256 f_, uint256 v_) internal pure returns (bytes memory) {
        return f_ == 0
            ? abi.encodeCall(CurveYieldVaultExecutor.setCallerReward, (uint16(v_), 3e18))
            : abi.encodeCall(CurveYieldVaultExecutor.setCallerReward, (10, v_));
    }

    /// @dev At each bound the owner's setter succeeds; one step outside it reverts with OutOfBounds.
    function _edges(
        address target_, uint256 f_, CyBound memory b_,
        function(uint256, uint256) internal view returns (bytes memory) build_, string memory name_
    ) internal {
        bytes memory d = build_(f_, b_.min);
        if (d.length != 0) _callOk(target_, d, string.concat(name_, " field ", vm.toString(f_), ": min rejected"));
        d = build_(f_, b_.max);
        if (d.length != 0) _callOk(target_, d, string.concat(name_, " field ", vm.toString(f_), ": max rejected"));
        if (b_.min > 0) _callOutOfBounds(target_, build_(f_, b_.min - 1), string.concat(name_, " field ", vm.toString(f_), ": min-1"));
        _callOutOfBounds(target_, build_(f_, b_.max + 1), string.concat(name_, " field ", vm.toString(f_), ": max+1"));
    }

    function _callOk(address target_, bytes memory data_, string memory why_) internal {
        vm.prank(DEPLOYER);
        (bool ok, bytes memory ret) = target_.call(data_);
        if (!ok) console2.logBytes(ret);
        assertTrue(ok, why_);
    }

    function _callOutOfBounds(address target_, bytes memory data_, string memory why_) internal {
        vm.prank(DEPLOYER);
        (bool ok, bytes memory ret) = target_.call(data_);
        assertFalse(ok, string.concat(why_, " accepted"));
        assertEq(bytes4(ret), CurveYieldBounds.OutOfBounds.selector, string.concat(why_, " wrong error"));
    }

    // ---------------------------------------------------------------- 12. access

    function test_edge12_fusesRejectDeployerWithAlpha() public {
        _installVkatSet();
        _installLendSet();
        _installLpSet();
        CyLoopFuses memory lf = loop.fuses();
        CyVkatFuses memory vf = vkat.fuses();
        CyLpFuses memory pf = lpc.fuses();
        address reduce = address(0);
        {
            (bool ok, bytes memory r) = address(lend).staticcall(abi.encodeWithSignature("reduceFuse()"));
            require(ok, "reduceFuse()");
            reduce = abi.decode(r, (address));
        }
        CyExecutorDeps memory deps = executor.dependencies();

        bytes[] memory data = new bytes[](21);
        address[] memory fuse = new address[](21);
        (fuse[0], data[0]) = (lf.windup, abi.encodeWithSignature("enter(uint256)", 1e18));
        (fuse[1], data[1]) = (lf.unwind, abi.encodeWithSignature("enter(uint256,uint256)", 1e18, 100));
        (fuse[2], data[2]) = (lf.ltvRebalance, abi.encodeWithSignature("enter()"));
        (fuse[3], data[3]) = (lf.emergency, abi.encodeWithSignature("enter(uint256)", 0));
        (fuse[4], data[4]) = (vf.lock, abi.encodeWithSignature("enter(uint256)", 1e18));
        (fuse[5], data[5]) = (vf.convert, abi.encodeWithSignature("enter(uint256)", 1e18));
        (fuse[6], data[6]) = (vf.vote, abi.encodeWithSignature("enter()"));
        (fuse[7], data[7]) = (vf.exitPrepare, abi.encodeWithSignature("enter(uint256)", 1e18));
        (fuse[8], data[8]) = (vf.exitBegin, abi.encodeWithSignature("enter(uint256)", 1));
        (fuse[9], data[9]) = (vf.exitBegin, abi.encodeWithSignature("enterFromPosition(uint256)", 1e18));
        (fuse[10], data[10]) = (vf.exitComplete, abi.encodeWithSignature("enter(uint256)", 1));
        (fuse[11], data[11]) = (vf.exitComplete, abi.encodeWithSignature("enterEarly(uint256)", 1));
        (fuse[12], data[12]) = (reduce, abi.encodeWithSignature("enter(uint256)", 1e18));
        (fuse[13], data[13]) = (pf.open, abi.encodeWithSignature("enter(uint256,int24,int24)", 1e18, int24(-200), int24(200)));
        (fuse[14], data[14]) = (pf.increase, abi.encodeWithSignature("enter(uint256)", 1e18));
        (fuse[15], data[15]) = (pf.withdraw, abi.encodeWithSignature("enter(uint256,uint256)", 5_000, 100));
        (fuse[16], data[16]) = (pf.rebalance, abi.encodeWithSignature("enter(int24,int24)", int24(-200), int24(200)));
        (fuse[17], data[17]) = (pf.emergency, abi.encodeWithSignature("enter()"));
        (fuse[18], data[18]) = (deps.payFuse, abi.encodeWithSignature("enter(uint256)", 1e18));
        (fuse[19], data[19]) = (deps.profitSplitFuse, abi.encodeWithSignature("enter(uint256)", 1e18));
        // the LP withdraw fuse lets the OWNER (not just the executor) call enterWithLoss: DEPLOYER owns lpc here, so it is
        // the one entry point expected to pass this check; covered by test_lp_withdrawGates_andWithdrawWithLoss.
        (fuse[20], data[20]) = (pf.withdraw, abi.encodeWithSignature("enter(uint256,uint256)", 100, 100));

        for (uint256 i; i < data.length; ++i) {
            FuseAction[] memory a = new FuseAction[](1);
            a[0] = FuseAction(fuse[i], data[i]);
            vm.prank(DEPLOYER); // holds ALPHA, but is not the executor
            vm.expectRevert(abi.encodeWithSignature("UnauthorizedCaller(address)", DEPLOYER));
            IVaultT(VAULT).execute(a);
        }
    }

    function test_edge12_recordFunctionsAreVaultOnly() public {
        _installVkatSet();
        _installLendSet();
        _installLpSet();
        address rnd = makeAddr("random");
        bytes memory err = abi.encodeWithSignature("OnlyVault(address)", rnd);

        vm.startPrank(rnd);
        vm.expectRevert(err);
        vkat.recordPosition(1);
        vm.expectRevert(err);
        vkat.recordPrepared(1);
        vm.expectRevert(err);
        vkat.recordExitStarted(1);
        vm.expectRevert(err);
        vkat.recordExitCompleted(1);
        vm.expectRevert(err);
        lend.recordReduction(1e18);
        vm.expectRevert(err);
        lpc.recordCheckpoint();
        vm.stopPrank();
        // and the vault itself is accepted
        vm.prank(VAULT);
        lend.recordReduction(0);
        vm.prank(VAULT);
        lpc.recordCheckpoint();
    }
}
