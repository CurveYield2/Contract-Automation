// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.30;

import {console2} from "forge-std/Test.sol";
import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {LendingForkSetup} from "../helpers/LendingForkSetup.sol";
import {P2_01_Deploy} from "../../script/P2_01_Deploy.s.sol";
import {P2_02_ConfigureVault} from "../../script/P2_02_ConfigureVault.s.sol";
import {P3_01_DeployGovernanceTokens} from "../../script/P3_01_DeployGovernanceTokens.s.sol";
import {P3_02_DeployDao} from "../../script/P3_02_DeployDao.s.sol";
import {P3_03_DeployGovernanceCore} from "../../script/P3_03_DeployGovernanceCore.s.sol";
import {P3_04_ConfigureGate} from "../../script/P3_04_ConfigureGate.s.sol";
import {P4_01_CreatePlusVault} from "../../script/P4_01_CreatePlusVault.s.sol";
import {P4_02_DeployPlusStack} from "../../script/P4_02_DeployPlusStack.s.sol";
import {P4_03_ConfigurePlus} from "../../script/P4_03_ConfigurePlus.s.sol";
import {P4_04_DeployRewards} from "../../script/P4_04_DeployRewards.s.sol";
import {CurveYieldLeaderboard, CySeasonParams, CyTiers} from "../../src/leaderboard/CurveYieldLeaderboard.sol";
import {CurveYieldSpecialRewards} from "../../src/plus/CurveYieldSpecialRewards.sol";
import {CurveYieldContributorsRewardFuse} from "../../src/plus/CurveYieldContributorsRewardFuse.sol";
import {CurveYieldPlusDepositRouter} from "../../src/plus/CurveYieldPlusDepositRouter.sol";
import {CurveYieldPlusLoopController} from "../../src/plus/CurveYieldPlusLoopController.sol";
import {CurveYieldEngagementToken} from "../../src/governance/CurveYieldEngagementToken.sol";
import {CurveYieldEngagementRewards} from "../../src/governance/CurveYieldEngagementRewards.sol";

interface IScriptR {
    function setPaths(string calldata, string calldata) external;
    function run() external;
}

interface IErcR {
    function balanceOf(address) external view returns (uint256);
    function approve(address, uint256) external returns (bool);
    function transfer(address, uint256) external returns (bool);
    function totalSupply() external view returns (uint256);
    function convertToAssets(uint256) external view returns (uint256);
    function deposit(uint256, address) external returns (uint256);
}

interface IWmR {
    function feeSplit() external view returns (address[3] memory, uint16[3] memory);
}

interface IOwnableR {
    function owner() external view returns (address);
    function contributorsSink() external view returns (address);
    function contributorsReceiver() external view returns (address);
}

/// @dev an LP-token stand-in: a plain ERC20 that will hold cyavKAT+ (the special rewards attribute it to its holders)
contract MockLp is ERC20 {
    constructor() ERC20("LP", "LP") {}

    function mint(address to, uint256 amount) external {
        _mint(to, amount);
    }
}

/// @notice Fork tests of the reward layer (PHASE4 #22 special rewards, #23 contributors fuse) after P2_01, P2_02,
/// P3_01..P3_04, P4_01..P4_04 ran as the deployer. One test, isolated scenarios (env-driven scripts cannot run in parallel
/// tests); a failing scenario is rolled back and reported, the next one still runs.
/// Run: RAYON_NUM_THREADS=2 forge test --match-path test/plus/PlusRewardsFork.t.sol -vv
contract PlusRewardsForkTest is LendingForkSetup {
    address constant VAULT = 0xEd83daf48429cfb2C650Fd721b9241e180fd4548;
    address constant AVKAT = 0x7231dbaCdFc968E07656D12389AB20De82FbfCeB;
    address constant DEPLOYER = 0x11b78837cadC8E894F1c6e13fA9f3A085a75FA35;
    address constant FEE_SAFE = 0x47623C62f281807D615eeb4A2CEee9d97F9D3C49;
    address constant CUSTODY = 0xe7D109Ce6b34447Dd45B54e5615F4177291D5ADf;
    uint256 constant CY = 1e20;
    uint256 constant PLUS_UNIT = 1e22;

    string p2Path;
    string p3Path;
    string p4Path;
    string lendPath;
    string p2;
    string p3;
    string p4;
    string lend;

    IErcR cy = IErcR(VAULT);
    IErcR plus;
    CurveYieldSpecialRewards special;
    CurveYieldContributorsRewardFuse fuse;
    CurveYieldLeaderboard lb;
    CurveYieldPlusDepositRouter router;
    CurveYieldPlusLoopController controller;
    CurveYieldEngagementToken engToken;
    CurveYieldEngagementRewards engRewards;
    address booster;

    address alice = makeAddr("alice"); // leaderboard only
    address bob = makeAddr("bob"); // engagement only
    address carol = makeAddr("carol"); // neither
    address dave = makeAddr("dave"); // both
    address erin = makeAddr("erin"); // leaderboard, just-in-time depositor
    address keeper = makeAddr("keeper");
    uint256 t;
    string[] fails;

    function setUp() public {
        vm.createSelectFork(vm.envString("KATANA_RPC_URL"), vm.envUint("FORK_BLOCK"));
        vm.setEnv("PRIVATE_KEY", "0");
        p2Path = _tmpPath("prewards-p2");
        p3Path = _tmpPath("prewards-p3");
        p4Path = _tmpPath("prewards-p4");
        lendPath = _tmpPath("prewards-lend");
        vm.setEnv("PHASE3_DEPLOYMENTS", p3Path);
        vm.setEnv("PHASE4_DEPLOYMENTS", p4Path);
        vm.setEnv("SAFE_OWNER_BOT1", vm.toString(makeAddr("bot1")));
        vm.setEnv("SAFE_OWNER_BOT2", vm.toString(makeAddr("bot2")));
        vm.setEnv("BOT_OPERATOR", vm.toString(makeAddr("operator")));
        _prepareLending(lendPath, p2Path);
        _run(address(new P2_01_Deploy()));
        _run(address(new P2_02_ConfigureVault()));
        IScriptR(address(new P3_01_DeployGovernanceTokens())).run();
        IScriptR(address(new P3_02_DeployDao())).run();
        IScriptR(address(new P3_03_DeployGovernanceCore())).run();
        _run(address(new P3_04_ConfigureGate()));
        _run(address(new P4_01_CreatePlusVault()));
        _run(address(new P4_02_DeployPlusStack()));
        _run(address(new P4_03_ConfigurePlus()));
        _run(address(new P4_04_DeployRewards()));
        p2 = vm.readFile(p2Path);
        p3 = vm.readFile(p3Path);
        p4 = vm.readFile(p4Path);
        lend = vm.readFile(lendPath);
        plus = IErcR(_a4(".plusVault"));
        special = CurveYieldSpecialRewards(_a4(".specialRewards"));
        fuse = CurveYieldContributorsRewardFuse(_a4(".contributorsRewardFuse"));
        lb = CurveYieldLeaderboard(_a4(".leaderboard"));
        router = CurveYieldPlusDepositRouter(_a4(".plusDepositRouter"));
        controller = CurveYieldPlusLoopController(_a4(".plusController"));
        booster = _a4(".plusYieldBooster");
        engToken = CurveYieldEngagementToken(vm.parseJsonAddress(p3, ".engagementToken"));
        engRewards = CurveYieldEngagementRewards(vm.parseJsonAddress(p3, ".engagementRewards"));
    }

    function _run(address script_) internal {
        IScriptR(script_).setPaths(p2Path, lendPath);
        IScriptR(script_).run();
    }

    function _a4(string memory k) internal view returns (address) {
        return vm.parseJsonAddress(p4, k);
    }

    // ---------------------------------------------------------------- helpers

    function _near(uint256 a, uint256 b, uint256 tolBps, string memory what) internal pure {
        uint256 d = a > b ? a - b : b - a;
        uint256 ref = a > b ? a : b;
        require(d * 10_000 <= ref * tolBps, string.concat(what, ": ", vm.toString(a), " vs ", vm.toString(b)));
    }

    function _mintCy(address u, uint256 cyWanted) internal {
        uint256 a = IErcR(VAULT).convertToAssets(cyWanted) + 1e12;
        deal(AVKAT, u, a);
        vm.startPrank(u);
        IErcR(AVKAT).approve(VAULT, a);
        IErcR(VAULT).deposit(a, u);
        vm.stopPrank();
    }

    /// @dev `u` ends up with about `cyAmount` cyavKAT worth of cyavKAT+ (whitelisted in the router: no fee)
    function _plusFor(address u, uint256 cyAmount) internal {
        vm.prank(DEPLOYER);
        router.setWhitelisted(u, true);
        _mintCy(u, cyAmount);
        vm.startPrank(u);
        IErcR(VAULT).approve(address(router), cyAmount);
        router.deposit(cyAmount, u);
        vm.stopPrank();
        _warp(t + 3_601); // IPOR locks a depositor's shares for the redemption delay (3600 s): AccountIsLocked
    }

    function _fundSpecial(uint256 cyAmount) internal {
        _mintCy(address(special), cyAmount);
    }

    function _warp(uint256 to) internal {
        t = to;
        vm.warp(to);
    }

    function _seasonParams() internal view returns (CySeasonParams memory p_) {
        p_.start = uint48(t);
        p_.end = uint48(t + 140 days);
        p_.initialRateBps = 5_000;
        p_.cliffCount = 2;
        p_.cliffAt = [uint48(t + 28 days), uint48(t + 84 days), uint48(0)];
        p_.cliffRateBps = [uint16(7_000), 9_000, 0];
        p_.pointsPerShareEpoch = 100e18;
        p_.longHoldBonusBps = 500;
        p_.tier1Bps = 4_000;
        p_.tier2Bps = 2_000;
        p_.refTiers = CyTiers({fullUntilBps: 10_000, cut1Bps: 3_000, cut2FromBps: 30_000, cut2Bps: 4_000});
        p_.buyRate = 100e18 * 100;
        p_.buyTiers = CyTiers({fullUntilBps: 3_000, cut1Bps: 3_000, cut2FromBps: 10_000, cut2Bps: 4_000});
        p_.adminCapBps = 2_000;
        p_.minBalance = 0;
        p_.registrationFee = 0;
    }

    function _openAndProcess() internal returns (uint256 id) {
        vm.prank(keeper);
        id = special.openEpoch();
        special.processEpoch(1_000);
    }

    function _nextEpochTime() internal {
        _warp(t + special.minInterval() + 1);
    }

    // ---------------------------------------------------------------- scenarios

    /// @dev W: the P4_04 wiring
    function w0_wiring() external view {
        require(controller.specialRewards() == address(special), "controller special rewards");
        require(router.specialRewards() == address(special), "router special rewards");
        (address[3] memory rec, uint16[3] memory bps) = IWmR(_a4(".plusWithdrawManagerV2")).feeSplit();
        require(rec[0] == FEE_SAFE && rec[1] == address(special) && rec[2] == booster, "WM v2 split recipients");
        require(bps[0] == 2_000 && bps[1] == 2_500 && bps[2] == 3_000, "WM v2 split bps");
        require(lb.specialRewards() == address(special) && lb.growthCustody() == CUSTODY && lb.plusBooster() == booster, "leaderboard buy destinations");
        require(router.isWhitelisted(address(fuse)), "contributors fuse not whitelisted in the router");
        require(engRewards.isRewardToken(address(plus)), "cyavKAT+ not a reward token of the engagement rewards");
        require(IOwnableR(vm.parseJsonAddress(p2, ".splitter")).contributorsSink() == address(fuse), "loop splitter sink");
        require(IOwnableR(vm.parseJsonAddress(lend, ".wrapperFeeSplitter")).contributorsReceiver() == address(fuse), "wrapper splitter sink");
        require(IOwnableR(vm.parseJsonAddress(p3, ".proposalBond")).contributorsReceiver() == address(fuse), "bond sink");
        require(address(special.PLUS()) == address(plus) && address(special.LEADERBOARD()) == address(lb), "special rewards env");
        require(address(fuse.LEADERBOARD()) == address(lb) && fuse.PLUS_ROUTER() == address(router), "contributors fuse env");
    }

    /// @dev S1: eligibility (leaderboard registrant of the current season OR engagement holder), pro rata claims, first-epoch
    /// weights are zero (nobody has a previous snapshot), admin share and caller reward.
    function s1_eligibilityAndClaims() external {
        // the first epoch: everybody's previous snapshot is 0 -> weights 0 -> the amount rolls over
        _fundSpecial(10_000 * CY);
        uint256 adminBefore = cy.balanceOf(FEE_SAFE);
        uint256 kBefore = cy.balanceOf(keeper);
        uint256 id0 = _openAndProcess();
        CurveYieldSpecialRewards.Epoch memory e0 = special.epochInfo(id0);
        require(e0.closed && e0.totalWeight == 0, "first epoch must close with no weight (just-in-time protection)");
        console2.log("epoch 0 admin / caller paid", cy.balanceOf(FEE_SAFE) - adminBefore, cy.balanceOf(keeper) - kBefore);
        require(special.reserved() == 0, "reserved not released on rollover");

        // second epoch: alice, bob, dave eligible; carol not
        _nextEpochTime();
        uint256 poolBefore = cy.balanceOf(address(special));
        adminBefore = cy.balanceOf(FEE_SAFE);
        uint256 id1 = _openAndProcess();
        CurveYieldSpecialRewards.Epoch memory e1 = special.epochInfo(id1);
        require(e1.closed && e1.totalWeight != 0, "second epoch has no weight");
        uint256 wA = special.weightOf(id1, alice);
        uint256 wB = special.weightOf(id1, bob);
        uint256 wC = special.weightOf(id1, carol);
        uint256 wD = special.weightOf(id1, dave);
        console2.log("weights alice / bob / carol / dave", wA, wB, wC);
        console2.log("  dave", wD);
        require(wC == 0, "carol (neither registered nor engagement holder) got weight");
        require(wA != 0 && wB != 0 && wD != 0, "an eligible holder got no weight");
        require(wA + wB + wD == e1.totalWeight, "weights do not sum to the total");
        require(cy.balanceOf(FEE_SAFE) - adminBefore == poolBefore * 1_000 / 10_000, "admin share != 10%");
        uint256 sum;
        address[4] memory us = [alice, bob, carol, dave];
        for (uint256 i; i < 4; ++i) {
            uint256 b0 = cy.balanceOf(us[i]);
            special.claim(id1, us[i]);
            uint256 got = cy.balanceOf(us[i]) - b0;
            sum += got;
            if (us[i] == carol) require(got == 0, "carol was paid");
            else _near(got, e1.amount * special.weightOf(id1, us[i]) / e1.totalWeight, 1, "claim != pro rata");
        }
        require(e1.amount - sum < 1e6, "claims do not sum to the epoch amount");
        (bool ok,) = address(special).call(abi.encodeCall(special.claim, (id1, alice)));
        require(!ok, "double claim did not revert");
        require(special.reserved() <= 1e6, "reserved not released after all claims");
    }

    /// @dev S2: min rule. Moving shares mid-epoch between two eligible accounts cannot double count.
    function s2_minRuleNoDoubleCount() external {
        _nextEpochTime();
        _fundSpecial(1_000 * CY);
        _openAndProcess(); // snapshot 1 (weights 0, previous balances recorded)
        uint256 balA = plus.balanceOf(alice);
        uint256 balD = plus.balanceOf(dave);
        vm.prank(alice);
        plus.transfer(dave, balA / 2); // mid-epoch move
        _nextEpochTime();
        _fundSpecial(1_000 * CY);
        uint256 id = _openAndProcess();
        uint256 wA = special.weightOf(id, alice);
        uint256 wD = special.weightOf(id, dave);
        console2.log("after the move: alice / dave weights", wA, wD);
        require(wA == balA - balA / 2, "alice weight != min(now, before) = what she kept");
        require(wD == balD, "dave weight != min(now, before) = what he had");
        require(wA + wD < balA + balD, "moved shares were double counted");
    }

    /// @dev S3: a just-in-time depositor earns nothing in the epoch she deposits in.
    function s3_justInTime() external {
        _nextEpochTime();
        _fundSpecial(1_000 * CY);
        _openAndProcess(); // snapshot for the others
        _nextEpochTime();
        _plusFor(erin, 5_000 * CY); // deposits right before the next snapshot
        _fundSpecial(1_000 * CY);
        uint256 id = _openAndProcess();
        require(special.weightOf(id, erin) == 0, "just-in-time deposit earned weight");
        // and one epoch later she does (held across two snapshots)
        _nextEpochTime();
        _fundSpecial(1_000 * CY);
        uint256 id2 = _openAndProcess();
        require(special.weightOf(id2, erin) != 0, "held across two snapshots but no weight");
    }

    /// @dev S4: the first `exemptShares` cyavKAT+ of each holder are excluded.
    function s4_exemptShares() external {
        _nextEpochTime();
        _fundSpecial(1_000 * CY);
        _openAndProcess();
        vm.prank(DEPLOYER);
        special.setParams(10, 20e20, 5 * PLUS_UNIT, 7 days, 0, 0);
        _nextEpochTime();
        _fundSpecial(1_000 * CY);
        uint256 id = _openAndProcess();
        uint256 bal = plus.balanceOf(alice);
        require(special.weightOf(id, alice) == bal - 5 * PLUS_UNIT, "exempt shares not deducted");
    }

    /// @dev S5: forwarder attribution pro rata to the LP holders, and pruning below the minimum.
    function s5_forwarders() external {
        MockLp lp = new MockLp();
        _plusFor(address(this), 400 * CY);
        plus.transfer(address(lp), 200 * PLUS_UNIT);
        lp.mint(alice, 25e18);
        lp.mint(bob, 75e18);
        special.registerForwarder(address(lp));
        require(special.isForwarder(address(lp)), "forwarder not registered");
        uint256 direct = plus.balanceOf(alice);
        uint256 att = special.balanceWithForwarders(alice);
        console2.log("alice direct / with forwarder", direct, att);
        _near(att - direct, 50 * PLUS_UNIT, 1, "alice's attributed share != 25% of the LP's cyavKAT+");
        // permissionless: a non-contract, a duplicate and the vault itself are rejected
        (bool ok,) = address(special).call(abi.encodeCall(special.registerForwarder, (address(lp))));
        require(!ok, "duplicate forwarder accepted");
        (ok,) = address(special).call(abi.encodeCall(special.registerForwarder, (makeAddr("eoa"))));
        require(!ok, "EOA accepted as a forwarder");
        (ok,) = address(special).call(abi.encodeCall(special.registerForwarder, (address(plus))));
        require(!ok, "the vault accepted as a forwarder");
        // raise the minimum above the LP's holdings: it is pruned at the next epoch
        vm.prank(DEPLOYER);
        special.setParams(10, 20e20, 0, 7 days, 0, 1_000 * PLUS_UNIT);
        _nextEpochTime();
        _fundSpecial(100 * CY);
        vm.prank(keeper);
        special.openEpoch();
        special.processEpoch(1_000); // close it so the next scenario can open one
        require(!special.isForwarder(address(lp)), "forwarder below the minimum was not pruned");
        require(special.balanceWithForwarders(alice) == plus.balanceOf(alice), "pruned forwarder still attributed");
    }

    /// @dev S6: admin share 10%, caller reward 0.1% capped at 20 cyavKAT.
    function s6_adminAndCallerReward() external {
        _nextEpochTime();
        _fundSpecial(100_000 * CY);
        uint256 a0 = cy.balanceOf(FEE_SAFE);
        uint256 k0 = cy.balanceOf(keeper);
        uint256 pool = cy.balanceOf(address(special)) - special.reserved(); // reserved: earlier epochs not yet claimed
        vm.prank(keeper);
        special.openEpoch();
        require(cy.balanceOf(FEE_SAFE) == a0 && cy.balanceOf(keeper) == k0, "admin / caller were paid at open (they are paid at close)");
        special.processEpoch(1_000); // closes: admin share and caller reward are paid now, only because the epoch has weight
        require(cy.balanceOf(FEE_SAFE) - a0 == pool / 10, "admin share != 10% of the pool");
        require(cy.balanceOf(keeper) - k0 == 20 * CY, "caller reward not capped at 20 cyavKAT");
        _nextEpochTime();
        // small pool: uncapped 0.1%
        _fundSpecial(100 * CY);
        k0 = cy.balanceOf(keeper);
        uint256 free = cy.balanceOf(address(special)) - special.reserved();
        vm.prank(keeper);
        special.openEpoch();
        special.processEpoch(1_000);
        require(cy.balanceOf(keeper) - k0 == free * 10 / 10_000, "caller reward != 0.1% for a small pool");
    }

    /// @dev S7: nobody eligible -> the epoch closes with 0 weight and its amount rolls into the next pool. OBSERVATION: the
    /// admin share and caller reward are paid out of the pool on every such epoch, so repeated rollovers pay the admin
    /// share again and again on the same undistributed money.
    function s7_rollover() external {
        // a fresh special rewards contract nobody is eligible for: a season with no registrants is enough (bob/dave hold no
        // engagement tokens in this scenario because it uses a different leaderboard registry)
        CurveYieldSpecialRewards s2 = new CurveYieldSpecialRewards(
            address(this), VAULT, address(plus), address(lb), address(engToken), FEE_SAFE
        );
        // exclude everyone: nobody registered in `lb` that this instance sees? (lb is shared) -> use a lone forwarder-less
        // instance whose leaderboard/engagement views are empty by pointing at a fresh, empty leaderboard
        CurveYieldLeaderboard emptyLb = new CurveYieldLeaderboard(address(this), VAULT, address(0));
        CurveYieldEngagementToken emptyEng = new CurveYieldEngagementToken(address(this));
        s2 = new CurveYieldSpecialRewards(address(this), VAULT, address(plus), address(emptyLb), address(emptyEng), FEE_SAFE);
        _mintCy(address(s2), 10_000 * CY);
        uint256 total = cy.balanceOf(address(s2));
        uint256 a0 = cy.balanceOf(FEE_SAFE);
        s2.openEpoch();
        s2.processEpoch(10);
        CurveYieldSpecialRewards.Epoch memory e = s2.epochInfo(0);
        require(e.closed && e.totalWeight == 0, "empty epoch did not close with 0 weight");
        require(s2.reserved() == 0, "reserved not released");
        uint256 paid1 = cy.balanceOf(FEE_SAFE) - a0;
        // next epoch: the rolled amount is in the pool again and pays the admin share AGAIN
        _warp(t + 8 days);
        s2.openEpoch();
        uint256 paid2 = cy.balanceOf(FEE_SAFE) - a0 - paid1;
        console2.log("admin paid on the first / second empty epoch of the same money", paid1, paid2);
        require(total != 0 && paid2 == 0, "admin share is paid again on money that was never distributed (rollover leak)");
    }

    // ---------------------------------------------------------------- contributors reward fuse

    /// @dev C1: avKAT -> cyavKAT -> cyavKAT+ with no router fee
    function c1_convert() external {
        deal(AVKAT, address(fuse), 1_000e18);
        uint256 a0 = cy.balanceOf(FEE_SAFE);
        uint256 s0 = cy.balanceOf(address(special));
        uint256 b0 = cy.balanceOf(booster);
        uint256 shares = fuse.convert();
        require(shares != 0, "nothing converted");
        require(plus.balanceOf(address(fuse)) == shares, "fuse did not receive the shares");
        require(cy.balanceOf(FEE_SAFE) == a0 && cy.balanceOf(address(special)) == s0 && cy.balanceOf(booster) == b0, "a deposit fee was charged");
        require(IErcR(AVKAT).balanceOf(address(fuse)) == 0 && cy.balanceOf(address(fuse)) == 0, "leftover avKAT / cyavKAT");
        uint256 expectedCy = IErcR(VAULT).convertToAssets(1e20); // avKAT per cyavKAT
        uint256 valueCy = plus.convertToAssets(shares); // cyavKAT
        console2.log("1000 avKAT -> cyavKAT+ shares / worth in cyavKAT", shares, valueCy);
        _near(valueCy * expectedCy / 1e20, 1_000e18, 30, "value lost in the conversion");
        // cyavKAT already held is converted too, and an empty call does nothing
        require(fuse.convert() == 0, "empty convert returned shares");
    }

    function _buyPointsFor(address u, uint256 cyAmount) internal {
        _mintCy(u, cyAmount);
        vm.startPrank(u);
        IErcR(VAULT).approve(address(lb), cyAmount);
        lb.buyPoints(cyAmount);
        vm.stopPrank();
    }

    /// @dev C2: distributeLeaderboard pays the top-100 pro rata to points
    function c2_distributeLeaderboard() external {
        _buyPointsFor(alice, 100 * CY);
        _buyPointsFor(dave, 300 * CY);
        _buyPointsFor(erin, 600 * CY);
        (address[] memory users, uint256[] memory pts) = lb.leaderboard();
        uint256 total;
        for (uint256 i; i < pts.length; ++i) total += pts[i];
        require(users.length >= 3 && total != 0, "leaderboard empty");
        deal(AVKAT, address(fuse), 2_000e18);
        fuse.convert();
        _warp(t + 3_601); // the fuse is the depositor: its new shares are locked for the redemption delay
        uint256 amount = plus.balanceOf(address(fuse)) * 5_000 / 10_000;
        uint256[] memory before = new uint256[](users.length);
        for (uint256 i; i < users.length; ++i) before[i] = plus.balanceOf(users[i]);
        vm.prank(DEPLOYER);
        fuse.distributeLeaderboard(5_000);
        uint256 paid;
        for (uint256 i; i < users.length; ++i) {
            uint256 got = plus.balanceOf(users[i]) - before[i];
            paid += got;
            _near(got, amount * pts[i] / total, 1, "leaderboard payout != pro rata to points");
        }
        require(amount - paid < 1e6, "leaderboard payouts do not add up to the distributed amount");
        // only the owner
        (bool ok,) = address(fuse).call(abi.encodeCall(fuse.distributeLeaderboard, (100)));
        require(!ok, "non-owner distributed");
    }

    /// @dev C3: distributeGovernance sends cyavKAT+ to the engagement rewards, which pay engagement holders in its epoch
    function c3_distributeGovernance() external {
        deal(AVKAT, address(fuse), 1_000e18);
        fuse.convert();
        _warp(t + 3_601);
        uint256 amount = fuse.distributable() * 2_000 / 10_000;
        uint256 e0 = plus.balanceOf(address(engRewards));
        vm.prank(DEPLOYER);
        fuse.distributeGovernance(2_000);
        require(plus.balanceOf(address(engRewards)) - e0 == amount, "engagement rewards did not receive the amount");
        uint256 id = engRewards.openEpoch();
        engRewards.processEpoch(100);
        uint256 b0 = plus.balanceOf(bob);
        engRewards.claim(id, bob);
        require(plus.balanceOf(bob) > b0, "an engagement holder was not paid in cyavKAT+");
    }

    /// @dev C4: grand prize reserve, timelock, payout by points and reset
    function c4_grandPrize() external {
        _buyPointsFor(alice, 100 * CY);
        _buyPointsFor(dave, 300 * CY);
        deal(AVKAT, address(fuse), 1_000e18);
        fuse.convert();
        uint256 held = plus.balanceOf(address(fuse));
        vm.startPrank(DEPLOYER);
        fuse.setGrandPrize(2_000, t + 30 days);
        vm.stopPrank();
        require(fuse.distributable() == held - held * 2_000 / 10_000, "reserve not excluded from distributable");
        (bool ok,) = address(fuse).call(abi.encodeCall(fuse.grandPrizeEvent, ()));
        require(!ok, "grand prize paid before the unlock date");
        vm.prank(DEPLOYER);
        (ok,) = address(fuse).call(abi.encodeCall(fuse.setGrandPrize, (1_000, t + 60 days)));
        require(!ok, "a second grand prize was configured while one is pending");
        _warp(t + 31 days);
        (address[] memory users, uint256[] memory pts) = lb.leaderboard();
        uint256 total;
        for (uint256 i; i < pts.length; ++i) total += pts[i];
        uint256 prize = held * 2_000 / 10_000;
        uint256[] memory before = new uint256[](users.length);
        for (uint256 i; i < users.length; ++i) before[i] = plus.balanceOf(users[i]);
        fuse.grandPrizeEvent();
        for (uint256 i; i < users.length; ++i) {
            _near(plus.balanceOf(users[i]) - before[i], prize * pts[i] / total, 1, "grand prize != pro rata to points");
        }
        require(fuse.grandPrizeBps() == 0, "grand prize not reset");
        vm.prank(DEPLOYER);
        fuse.setGrandPrize(1_000, t + 60 days); // a new one can be set
    }

    // ---------------------------------------------------------------- driver

    function _prepare() internal {
        _warp(block.timestamp);
        vm.startPrank(DEPLOYER);
        lb.startSeason(_seasonParams(), "Season 1", "CYS1");
        engToken.setMinter(DEPLOYER, true);
        engToken.mint(bob, 1e18);
        engToken.mint(dave, 1e18);
        vm.stopPrank();
        _plusFor(alice, 100 * CY);
        _plusFor(bob, 100 * CY);
        _plusFor(carol, 100 * CY);
        _plusFor(dave, 100 * CY);
        vm.prank(alice);
        lb.register();
        vm.prank(dave);
        lb.register();
        vm.prank(erin);
        lb.register();
        vm.prank(DEPLOYER);
        lb.setPointsAllocator(DEPLOYER);
    }

    function _runS(string memory name, bytes4 sel) internal {
        uint256 snap = vm.snapshot();
        (bool ok, bytes memory ret) = address(this).call(abi.encodeWithSelector(sel));
        if (ok) {
            console2.log("PASS", name);
            return;
        }
        string memory why;
        if (ret.length == 0) why = "(empty revert data)";
        else if (bytes4(ret) == 0x08c379a0) why = abi.decode(_tail(ret), (string));
        else why = vm.toString(ret);
        vm.revertTo(snap);
        console2.log("FAIL", name);
        console2.log("   ", why);
        fails.push(string.concat(name, ": ", why));
    }

    function _tail(bytes memory b) internal pure returns (bytes memory out) {
        out = new bytes(b.length - 4);
        for (uint256 i; i < out.length; ++i) out[i] = b[i + 4];
    }

    function test_rewards() public {
        _runS("W P4_04 wiring", this.w0_wiring.selector);
        _prepare();
        _runS("S1 eligibility, pro rata claims, admin share", this.s1_eligibilityAndClaims.selector);
        _runS("S2 min rule: no double count", this.s2_minRuleNoDoubleCount.selector);
        _runS("S3 just-in-time earns 0", this.s3_justInTime.selector);
        _runS("S4 exempt shares", this.s4_exemptShares.selector);
        _runS("S5 forwarders: attribution and pruning", this.s5_forwarders.selector);
        _runS("S6 admin share and capped caller reward", this.s6_adminAndCallerReward.selector);
        _runS("S7 rollover", this.s7_rollover.selector);
        _runS("C1 convert avKAT -> cyavKAT -> cyavKAT+, no fee", this.c1_convert.selector);
        _runS("C2 distributeLeaderboard pro rata", this.c2_distributeLeaderboard.selector);
        _runS("C3 distributeGovernance via engagement rewards", this.c3_distributeGovernance.selector);
        _runS("C4 grand prize", this.c4_grandPrize.selector);
        if (fails.length != 0) {
            string memory all;
            for (uint256 i; i < fails.length; ++i) all = string.concat(all, "\n  ", fails[i]);
            revert(string.concat("failed scenarios:", all));
        }
    }
}
