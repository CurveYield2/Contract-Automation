// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.30;

import {Test, console2} from "forge-std/Test.sol";
import {LendingForkSetup, IVaultLS} from "./helpers/LendingForkSetup.sol";
import {P2_01_Deploy} from "../script/P2_01_Deploy.s.sol";
import {P2_02_ConfigureVault} from "../script/P2_02_ConfigureVault.s.sol";
import {P2_03_Cutover} from "../script/P2_03_Cutover.s.sol";
import {CurveYieldVaultExecutor} from "../src/executor/CurveYieldVaultExecutor.sol";

interface IVaultM {
    function deposit(uint256 assets, address receiver) external returns (uint256);
    function redeem(uint256 shares, address receiver, address owner) external returns (uint256);
    function redeemFromRequest(uint256 shares, address receiver, address owner) external returns (uint256);
    function balanceOf(address) external view returns (uint256);
    function totalSupply() external view returns (uint256);
    function convertToAssets(uint256) external view returns (uint256);
}

interface IErc20M {
    function balanceOf(address) external view returns (uint256);
    function approve(address, uint256) external returns (bool);
}

interface IWmM {
    function requestShares(uint256) external;
    function requestInfo(address) external view returns (uint256, uint256, bool, uint256, uint256);
}

interface IScriptPaths {
    function setPaths(string calldata, string calldata) external;
    function run() external;
}

interface IControllerV2M {
    function deployAssets() external;
}

/// @notice Runs the real Phase 2 migration scripts (01 deploy, 02 configure, 03 cutover) on a Katana fork, then checks
/// the user and keeper flows through the new system.
/// Run: KATANA_RPC_URL=<rpc> FORK_BLOCK=<head-30> forge test --match-contract MigrationFork -vv
contract MigrationFork is LendingForkSetup {
    address constant VAULT = 0xEd83daf48429cfb2C650Fd721b9241e180fd4548;
    address constant AVKAT = 0x7231dbaCdFc968E07656D12389AB20De82FbfCeB;
    address constant CONTROLLER_V2 = 0xbFdf2d2653859B66A8A15e1C85F6d6cdEe89698f;
    address constant GROWTH_CUSTODY = 0xe7D109Ce6b34447Dd45B54e5615F4177291D5ADf;
    address keeper = makeAddr("keeper");
    address alice = makeAddr("alice");
    address bob = makeAddr("bob");
    CurveYieldVaultExecutor executor;
    address wm;
    string lendPath;
    LendingState lendState;
    uint256 totalBeforeP2_02;
    uint256 totalAfterP2_02;

    function setUp() public {
        vm.createSelectFork(vm.envString("KATANA_RPC_URL"), vm.envUint("FORK_BLOCK"));
        vm.setEnv("PRIVATE_KEY", "0"); // scripts act as the deployer address on the fork
        lendPath = _tmpPath("migration");
        (lendState,) = _prepareLending(lendPath, "deployments/unused-migration.json");
        _run(address(new P2_01_Deploy()));
        totalBeforeP2_02 = IVaultLS(VAULT).totalAssets();
        _run(address(new P2_02_ConfigureVault()));
        totalAfterP2_02 = IVaultLS(VAULT).totalAssets();
        _run(address(new P2_03_Cutover()));
        string memory d = vm.readFile("deployments/fork-migration.json");
        executor = CurveYieldVaultExecutor(vm.parseJsonAddress(d, ".executor"));
        wm = vm.parseJsonAddress(d, ".withdrawManagerV2");
        for (uint256 i; i < 2; ++i) {
            address u = i == 0 ? alice : bob;
            deal(AVKAT, u, 1_000e18);
            vm.prank(u);
            IErc20M(AVKAT).approve(VAULT, type(uint256).max);
        }
    }

    /// @dev Paths per script instance; the lending JSON is the temp copy that the lending setup prepared.
    function _run(address script_) internal {
        IScriptPaths(script_).setPaths("deployments/fork-migration.json", lendPath);
        IScriptPaths(script_).run();
    }

    /// @dev 4a: the market 7 fuse swap changes no value, and the made-up markets are gone from the vault.
    function test_p2_02_accountingOnIporMarketsOnly() public view {
        assertEq(totalAfterP2_02, totalBeforeP2_02, "P2_02 changed totalAssets");
        uint256[] memory active = IVaultLS(VAULT).getActiveMarketsInBalanceFuses();
        bool has7;
        bool has14;
        bool has41;
        for (uint256 i; i < active.length; ++i) {
            assertTrue(active[i] != 55 && active[i] != 60 && active[i] != 61, "made-up market still active");
            if (active[i] == 7) has7 = true;
            if (active[i] == 14) has14 = true;
            if (active[i] == 41) has41 = true;
        }
        assertTrue(has7 && has14 && has41, "markets 7 / 14 / 41 not active");
        assertEq(IVaultLS(VAULT).totalAssetsInMarket(60), 0, "market 60 not empty");
        assertEq(IVaultLS(VAULT).totalAssetsInMarket(55), 0);
        assertEq(IVaultLS(VAULT).totalAssetsInMarket(61), 0);
        // market 14 is the loop only; lending lives in market 41 (\"Lend Only\")
        bytes32[] memory subs = IVaultLS(VAULT).getMarketSubstrates(14);
        assertEq(subs.length, 1, "market 14 must be loop-only");
        assertEq(subs[0], 0x80e60fe453223b0f84a567724f88190bef708420d24397157067d424429783e9);
        bytes32[] memory subs41 = IVaultLS(VAULT).getMarketSubstrates(41);
        assertEq(subs41.length, 1, "market 41 substrates");
        assertEq(subs41[0], 0xe0e57a9a96ef56292b1400db02b19995147b1f39ff9dc1673b4618beba1cb159);
        assertGt(IVaultLS(VAULT).totalAssetsInMarket(41), 0, "lent avKAT not valued in market 41");
    }

    function test_oldControllerIsInert() public {
        vm.expectRevert();
        IControllerV2M(CONTROLLER_V2).deployAssets();
    }

    function test_depositAndDeployThroughExecutor() public {
        vm.prank(alice);
        IVaultM(VAULT).deposit(1_000e18, alice);
        vm.prank(keeper);
        executor.deployAssets(); // must not revert (#18)
    }

    function test_scheduledRequest_fulfil_redeem() public {
        vm.prank(alice);
        uint256 shares = IVaultM(VAULT).deposit(1_000e18, alice);
        vm.prank(alice);
        IWmM(wm).requestShares(shares);
        vm.warp(block.timestamp + 60);
        uint256 supplyBefore = IVaultM(VAULT).totalSupply();
        vm.prank(keeper);
        executor.fulfillAll();
        assertLt(IVaultM(VAULT).totalSupply(), supplyBefore, "request fee not burned at release");
        (uint256 releasable,, bool canWithdraw,,) = IWmM(wm).requestInfo(alice);
        assertTrue(canWithdraw, "not released");
        uint256 before = IErc20M(AVKAT).balanceOf(alice);
        vm.prank(alice);
        IVaultM(VAULT).redeemFromRequest(releasable, alice, alice);
        uint256 got = IErc20M(AVKAT).balanceOf(alice) - before;
        console2.log("deposited 1000, received after 8.75% scheduled fee", got);
        assertApproxEqRel(got, 912.5e18, 0.01e18, "not ~91.25% back");
    }

    function test_instantRedeem_chargesFeeAndCustodyCut() public {
        vm.prank(bob);
        uint256 shares = IVaultM(VAULT).deposit(1_000e18, bob);
        uint256 custodyBefore = IErc20M(AVKAT).balanceOf(GROWTH_CUSTODY);
        uint256 before = IErc20M(AVKAT).balanceOf(bob);
        vm.prank(bob);
        IVaultM(VAULT).redeem(shares, bob, bob);
        uint256 got = IErc20M(AVKAT).balanceOf(bob) - before;
        uint256 cut = IErc20M(AVKAT).balanceOf(GROWTH_CUSTODY) - custodyBefore;
        console2.log("instant: received / custody cut", got, cut);
        assertApproxEqRel(got, 987.5e18, 0.01e18, "not ~98.75% back (1.25% instant fee)");
        assertGt(cut, 0, "no custody cut on the instant fee");
    }

    function test_emergencyIsNoopAtTarget() public {
        vm.prank(keeper);
        executor.emergencyRepay(0);
        vm.prank(keeper);
        executor.lpEmergency();
    }

    function test_scriptsAreIdempotentWhereSafe() public {
        _run(address(new P2_02_ConfigureVault())); // re-run: skips what is already there
        _run(address(new P2_03_Cutover())); // re-run: re-applies the same state, post-conditions still hold
    }
}
