// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.30;

import {console2} from "forge-std/Test.sol";
import {L2_LendAvkat} from "../script/L2_LendAvkat.s.sol";
import {L3_WithdrawLend} from "../script/L3_WithdrawLend.s.sol";
import {P2_01_Deploy} from "../script/P2_01_Deploy.s.sol";
import {P2_02_ConfigureVault} from "../script/P2_02_ConfigureVault.s.sol";
import {P2_03_Cutover} from "../script/P2_03_Cutover.s.sol";
import {FuseAction} from "../src/interfaces/CurveYieldPhase2Interfaces.sol";
import {IMorpho, MarketParams, Id} from "@morpho-org/morpho-blue/src/interfaces/IMorpho.sol";
import {MorphoBalancesLib} from "@morpho-org/morpho-blue/src/libraries/periphery/MorphoBalancesLib.sol";
import {LendingForkSetup, IVaultLS, IScriptPathsLS} from "./helpers/LendingForkSetup.sol";

interface IVaultLV {
    function deposit(uint256 assets, address receiver) external returns (uint256);
    function redeem(uint256 shares, address receiver, address owner) external returns (uint256);
    function execute(FuseAction[] calldata) external;
}

interface IErc20LV {
    function balanceOf(address) external view returns (uint256);
    function approve(address, uint256) external returns (bool);
}

interface IControllerV2LV {
    function deployAssets() external;
}

/// @notice Live-v1 lending path (L1 install / L4 move, L2 lend, L3 withdraw) on a Katana fork, and the Phase 2 migration
/// on top. The fork setup is state-aware (see LendingForkSetup): whatever the live vault looks like, lending ends up in
/// market 41. These tests do not depend on live market headroom: they add their own idle avKAT and an outside supplier.
contract LendingV1Fork is LendingForkSetup {
    using MorphoBalancesLib for IMorpho;

    address constant VAULT = 0xEd83daf48429cfb2C650Fd721b9241e180fd4548;
    address constant AVKAT = 0x7231dbaCdFc968E07656D12389AB20De82FbfCeB;
    address constant MORPHO = 0xD50F2DffFd62f94Ee4AEd9ca05C61d0753268aBc;
    address constant CONTROLLER_V2 = 0xbFdf2d2653859B66A8A15e1C85F6d6cdEe89698f;
    address constant DEPLOYER = 0x11b78837cadC8E894F1c6e13fA9f3A085a75FA35;
    bytes32 constant LEND_MARKET = 0xe0e57a9a96ef56292b1400db02b19995147b1f39ff9dc1673b4618beba1cb159;
    address keeper = makeAddr("keeper");
    address alice = makeAddr("alice");
    address supplier = makeAddr("supplier");

    LendingState pre; // what the live vault looked like before setUp
    uint256 preTotal;
    uint256 preM14;
    uint256 preM60;
    address supplyFuse;
    string lendPath;
    string p2Path;

    function setUp() public {
        vm.createSelectFork(vm.envString("KATANA_RPC_URL"), vm.envUint("FORK_BLOCK"));
        vm.setEnv("LEND_AVKAT", "0");
        vm.setEnv("WITHDRAW_AVKAT", "0");
        lendPath = _tmpPath("lendv1");
        p2Path = _tmpPath("lendv1-p2");
        preTotal = IVaultLS(VAULT).totalAssets();
        preM14 = IVaultLS(VAULT).totalAssetsInMarket(14);
        preM60 = IVaultLS(VAULT).totalAssetsInMarket(60);
        (pre, supplyFuse) = _prepareLending(lendPath, p2Path);
    }

    function _run(address script_) internal {
        IScriptPathsLS(script_).setPaths(p2Path, lendPath);
        IScriptPathsLS(script_).run();
    }

    function _lent() internal view returns (uint256) {
        MarketParams memory p = IMorpho(MORPHO).idToMarketParams(Id.wrap(LEND_MARKET));
        return IMorpho(MORPHO).expectedSupplyAssets(p, VAULT);
    }

    /// @dev Headroom independent of the live market: extra idle avKAT in the vault (raises managed, so the 20% cap and the
    /// v1 reserve rule leave room) and a big outside supplier (the ownership rule).
    function _makeRoom() internal {
        deal(AVKAT, VAULT, IErc20LV(AVKAT).balanceOf(VAULT) + 30_000e18);
        deal(AVKAT, supplier, 500_000e18);
        vm.startPrank(supplier);
        IErc20LV(AVKAT).approve(MORPHO, 500_000e18);
        MarketParams memory mp = IMorpho(MORPHO).idToMarketParams(Id.wrap(LEND_MARKET));
        IMorpho(MORPHO).supply(mp, 500_000e18, 0, supplier, "");
        vm.stopPrank();
    }

    function test_installThenLendMax_keepsV1DeployWorking_andNoSharePriceStep() public {
        assertEq(IVaultLS(VAULT).getInstantWithdrawalFuses().length, 2, "instant withdrawal fuses");
        assertEq(IVaultLS(VAULT).getMarketSubstrates(41).length, 1, "market 41 lacks the lending substrate");
        assertEq(IVaultLS(VAULT).getMarketSubstrates(14).length, 1, "market 14 must be loop-only");
        _makeRoom();
        uint256 totalBefore = IVaultLS(VAULT).totalAssets();
        uint256 lentBefore = _lent();
        _run(address(new L2_LendAvkat()));
        uint256 lent = _lent();
        console2.log("lent before / after (max allowed)", lentBefore, lent);
        assertGt(lent, lentBefore, "nothing lent");
        assertApproxEqRel(IVaultLS(VAULT).totalAssets(), totalBefore, 0.0005e18, "share-price step from lending");
        vm.prank(keeper);
        IControllerV2LV(CONTROLLER_V2).deployAssets(); // v1 must still work with the lent amount outside the vault
    }

    function test_withdrawAllBack() public {
        _makeRoom();
        _run(address(new L2_LendAvkat()));
        _run(address(new L3_WithdrawLend()));
        assertLe(_lent(), 1e15, "not withdrawn");
    }

    function test_phase2MigrationReusesLendingFuses() public {
        _makeRoom();
        _run(address(new L2_LendAvkat()));
        _run(address(new P2_01_Deploy()));
        _run(address(new P2_02_ConfigureVault()));
        _run(address(new P2_03_Cutover()));
        string memory lend = vm.readFile(lendPath);
        string memory p2 = vm.readFile(p2Path);
        assertEq(vm.parseJsonAddress(p2, ".lendSupplyFuse"), vm.parseJsonAddress(lend, ".lendSupplyFuse"), "supply fuse not reused");
        assertEq(IVaultLS(VAULT).getInstantWithdrawalFuses().length, 3, "Phase 2 instant fuses");
    }

}
