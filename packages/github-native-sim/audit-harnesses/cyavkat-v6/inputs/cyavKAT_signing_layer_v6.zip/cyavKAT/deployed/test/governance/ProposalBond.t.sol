// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.30;

import {Test} from "forge-std/Test.sol";
import {CurveYieldEngagementToken} from "../../src/governance/CurveYieldEngagementToken.sol";
import {CurveYieldProposalBond} from "../../src/governance/CurveYieldProposalBond.sol";
import {AragonAction} from "../../src/governance/CurveYieldAragonInterfaces.sol";
import {GovMockToken, MockTokenVoting, GovMockTarget} from "./GovMocks.sol";

contract ProposalBondTest is Test {
    uint256 constant T = 1_800_000_000;
    uint256 constant BOND = 200e20;

    GovMockToken cy;
    MockTokenVoting voting;
    CurveYieldEngagementToken eng;
    CurveYieldProposalBond bond;
    GovMockTarget target;
    address safe = makeAddr("safe");
    address admin = makeAddr("admin");
    address contributors = makeAddr("contributors");
    address engRewards = makeAddr("engRewards");
    address user = makeAddr("user");

    function setUp() public {
        vm.warp(T);
        cy = new GovMockToken("cy");
        voting = new MockTokenVoting();
        eng = new CurveYieldEngagementToken(address(this));
        bond = new CurveYieldProposalBond(address(this), address(cy), address(voting), address(eng), safe, admin, contributors, engRewards);
        eng.setMinter(address(bond), true);
        target = new GovMockTarget(address(this));
        bond.setParam(0, address(target), target.setter.selector, 10, 100, true);
        cy.mint(user, 10_000e20);
        vm.prank(user);
        cy.approve(address(bond), type(uint256).max);
    }

    function _request(uint256 value_) internal returns (uint256 id_) {
        vm.prank(user);
        id_ = bond.request(0, value_);
    }

    function _setActions(uint256 pid_, address to_, uint256 value_, bytes memory data_) internal {
        AragonAction[] memory a = new AragonAction[](1);
        a[0] = AragonAction(to_, value_, data_);
        voting.setActions(pid_, a);
    }

    function _linked(uint256 value_, uint256 pid_) internal returns (uint256 id_) {
        id_ = _request(value_);
        _setActions(pid_, address(target), 0, abi.encodeWithSelector(target.setter.selector, value_));
        vm.prank(safe);
        bond.linkProposal(id_, pid_);
    }

    // ---------------------------------------------------------------- request

    function test_request_pullsTheBond_inRangeOnly() public {
        uint256 b0 = cy.balanceOf(user);
        uint256 id = _request(50);
        assertEq(id, 0);
        assertEq(b0 - cy.balanceOf(user), BOND);
        assertEq(cy.balanceOf(address(bond)), BOND);
        CurveYieldProposalBond.Request memory r = bond.requestOf(0);
        assertEq(r.requester, user);
        assertEq(r.value, 50);
        assertEq(r.bond, BOND);
        assertEq(uint256(r.status), uint256(CurveYieldProposalBond.Status.Pending));
        assertEq(uint256(r.createdAt), T);
    }

    function test_request_rangeEdges_disabled_unknown() public {
        _request(10); // min edge
        _request(100); // max edge
        vm.prank(user);
        vm.expectRevert(CurveYieldProposalBond.OutOfRange.selector);
        bond.request(0, 9);
        vm.prank(user);
        vm.expectRevert(CurveYieldProposalBond.OutOfRange.selector);
        bond.request(0, 101);
        bond.setParam(0, address(target), target.setter.selector, 10, 100, false);
        vm.prank(user);
        vm.expectRevert(CurveYieldProposalBond.BadParam.selector);
        bond.request(0, 50);
        vm.prank(user);
        vm.expectRevert(); // no such param
        bond.request(5, 50);
        // the bond is taken only after the checks: a user without allowance cannot request
        bond.setParam(0, address(target), target.setter.selector, 10, 100, true);
        address poor = makeAddr("poor");
        vm.prank(poor);
        vm.expectRevert();
        bond.request(0, 50);
    }

    // ---------------------------------------------------------------- linkProposal

    function test_link_safeOnly_andExactlyOneMatchingAction() public {
        uint256 id = _request(50);
        _setActions(1, address(target), 0, abi.encodeWithSelector(target.setter.selector, uint256(50)));
        vm.prank(user);
        vm.expectRevert(CurveYieldProposalBond.NotSafe.selector);
        bond.linkProposal(id, 1);

        // wrong value
        _setActions(2, address(target), 0, abi.encodeWithSelector(target.setter.selector, uint256(51)));
        vm.prank(safe);
        vm.expectRevert(CurveYieldProposalBond.ProposalMismatch.selector);
        bond.linkProposal(id, 2);
        // wrong target
        _setActions(3, address(bond), 0, abi.encodeWithSelector(target.setter.selector, uint256(50)));
        vm.prank(safe);
        vm.expectRevert(CurveYieldProposalBond.ProposalMismatch.selector);
        bond.linkProposal(id, 3);
        // wrong selector
        _setActions(4, address(target), 0, abi.encodeWithSelector(target.setAdmin.selector, uint256(50)));
        vm.prank(safe);
        vm.expectRevert(CurveYieldProposalBond.ProposalMismatch.selector);
        bond.linkProposal(id, 4);
        // native value attached
        _setActions(5, address(target), 1, abi.encodeWithSelector(target.setter.selector, uint256(50)));
        vm.prank(safe);
        vm.expectRevert(CurveYieldProposalBond.ProposalMismatch.selector);
        bond.linkProposal(id, 5);
        // extra calldata
        _setActions(6, address(target), 0, bytes.concat(abi.encodeWithSelector(target.setter.selector, uint256(50)), hex"00"));
        vm.prank(safe);
        vm.expectRevert(CurveYieldProposalBond.ProposalMismatch.selector);
        bond.linkProposal(id, 6);
        // two actions
        AragonAction[] memory two = new AragonAction[](2);
        two[0] = AragonAction(address(target), 0, abi.encodeWithSelector(target.setter.selector, uint256(50)));
        two[1] = two[0];
        voting.setActions(7, two);
        vm.prank(safe);
        vm.expectRevert(CurveYieldProposalBond.ProposalMismatch.selector);
        bond.linkProposal(id, 7);
        // no actions
        vm.prank(safe);
        vm.expectRevert(CurveYieldProposalBond.ProposalMismatch.selector);
        bond.linkProposal(id, 99);

        // the exact call links
        vm.prank(safe);
        bond.linkProposal(id, 1);
        CurveYieldProposalBond.Request memory r = bond.requestOf(id);
        assertEq(uint256(r.status), uint256(CurveYieldProposalBond.Status.Linked));
        assertEq(r.proposalId, 1);
        // and cannot be linked twice
        vm.prank(safe);
        vm.expectRevert(CurveYieldProposalBond.WrongStatus.selector);
        bond.linkProposal(id, 1);
    }

    // ---------------------------------------------------------------- reject

    function test_reject_slashesThirdsDustToEngagement() public {
        bond.setTerms(100e20 + 1, 100e18, 7 days); // a bond that does not divide by 3
        uint256 amount = 100e20 + 1;
        vm.prank(user);
        uint256 id = bond.request(0, 50);
        vm.prank(user);
        vm.expectRevert(CurveYieldProposalBond.NotSafe.selector);
        bond.reject(id);
        vm.prank(safe);
        bond.reject(id);
        uint256 third = amount / 3;
        assertEq(cy.balanceOf(admin), third);
        assertEq(cy.balanceOf(contributors), third);
        assertEq(cy.balanceOf(engRewards), amount - 2 * third, "dust must go to engagement");
        assertEq(cy.balanceOf(address(bond)), 0);
        assertEq(uint256(bond.requestOf(id).status), uint256(CurveYieldProposalBond.Status.Slashed));
        vm.prank(safe);
        vm.expectRevert(CurveYieldProposalBond.WrongStatus.selector);
        bond.reject(id);
    }

    // ---------------------------------------------------------------- settle

    function test_settle_executed_refundsBondAndMintsProposerReward() public {
        uint256 id = _linked(50, 1);
        uint256 endDate = T + 7 days;
        voting.setProposal(1, false, true, uint64(T), uint64(endDate), 1, 0, 0);
        uint256 b0 = cy.balanceOf(user);
        bond.settle(id);
        assertEq(cy.balanceOf(user) - b0, BOND, "bond not refunded");
        assertEq(eng.balanceOf(user), 100e18, "proposer reward not minted");
        assertEq(uint256(bond.requestOf(id).status), uint256(CurveYieldProposalBond.Status.Rewarded));
        vm.expectRevert(CurveYieldProposalBond.WrongStatus.selector);
        bond.settle(id);
    }

    function test_settle_endedNotExecuted_slashes() public {
        uint256 id = _linked(50, 1);
        voting.setProposal(1, false, false, uint64(T), uint64(T + 7 days), 0, 1, 0);
        vm.warp(T + 7 days + 1);
        bond.settle(id);
        uint256 third = BOND / 3;
        assertEq(cy.balanceOf(admin), third);
        assertEq(cy.balanceOf(contributors), third);
        assertEq(cy.balanceOf(engRewards), BOND - 2 * third);
        assertEq(cy.balanceOf(user), 10_000e20 - BOND);
        assertEq(eng.balanceOf(user), 0, "reward minted for a failed proposal");
        assertEq(uint256(bond.requestOf(id).status), uint256(CurveYieldProposalBond.Status.Slashed));
    }

    function test_settle_beforeTheEnd_reverts_VoteNotOver() public {
        uint256 id = _linked(50, 1);
        // still open
        voting.setProposal(1, true, false, uint64(T), uint64(T + 7 days), 0, 0, 0);
        vm.expectRevert(CurveYieldProposalBond.VoteNotOver.selector);
        bond.settle(id);
        // closed flag but the end date not reached yet
        voting.setProposal(1, false, false, uint64(T), uint64(T + 7 days), 0, 0, 0);
        vm.warp(T + 3 days);
        vm.expectRevert(CurveYieldProposalBond.VoteNotOver.selector);
        bond.settle(id);
        // exactly at the end date: still not over (block.timestamp <= endDate)
        vm.warp(T + 7 days);
        vm.expectRevert(CurveYieldProposalBond.VoteNotOver.selector);
        bond.settle(id);
        // a Pending request cannot be settled
        uint256 id2 = _request(20);
        vm.expectRevert(CurveYieldProposalBond.WrongStatus.selector);
        bond.settle(id2);
    }

    // ---------------------------------------------------------------- refund

    function test_refund_onlyAfterIntakeWindow_whilePending() public {
        uint256 id = _request(50);
        vm.expectRevert(CurveYieldProposalBond.WindowOpen.selector);
        bond.refund(id);
        vm.warp(T + 7 days); // window is "<=": still open at the boundary
        vm.expectRevert(CurveYieldProposalBond.WindowOpen.selector);
        bond.refund(id);
        vm.warp(T + 7 days + 1);
        uint256 b0 = cy.balanceOf(user);
        vm.prank(makeAddr("anyone"));
        bond.refund(id);
        assertEq(cy.balanceOf(user) - b0, BOND);
        assertEq(uint256(bond.requestOf(id).status), uint256(CurveYieldProposalBond.Status.Refunded));
        vm.expectRevert(CurveYieldProposalBond.WrongStatus.selector);
        bond.refund(id);

        // a linked request cannot be refunded, and neither can a rejected one
        uint256 id2 = _linked(60, 2);
        vm.warp(T + 30 days);
        vm.expectRevert(CurveYieldProposalBond.WrongStatus.selector);
        bond.refund(id2);
        uint256 id3 = _request(70);
        vm.prank(safe);
        bond.reject(id3);
        vm.warp(T + 60 days);
        vm.expectRevert(CurveYieldProposalBond.WrongStatus.selector);
        bond.refund(id3);
    }

    function test_afterRejectOrLink_linkingAgainFails() public {
        uint256 id = _request(50);
        vm.prank(safe);
        bond.reject(id);
        _setActions(1, address(target), 0, abi.encodeWithSelector(target.setter.selector, uint256(50)));
        vm.prank(safe);
        vm.expectRevert(CurveYieldProposalBond.WrongStatus.selector);
        bond.linkProposal(id, 1);
    }

    // ---------------------------------------------------------------- setters

    function test_adminReceiverAndDestinationsAreSeparateSetters() public {
        address newAdmin = makeAddr("newAdmin");
        bond.setAdminReceiver(newAdmin);
        assertEq(bond.adminReceiver(), newAdmin);
        assertEq(bond.contributorsReceiver(), contributors, "setAdminReceiver touched the destinations");
        assertEq(bond.engagementRewards(), engRewards);

        address newC = makeAddr("newC");
        address newE = makeAddr("newE");
        bond.setDestinations(newC, newE);
        assertEq(bond.contributorsReceiver(), newC);
        assertEq(bond.engagementRewards(), newE);
        assertEq(bond.adminReceiver(), newAdmin, "setDestinations touched the admin receiver");

        vm.expectRevert(CurveYieldProposalBond.InvalidAddress.selector);
        bond.setAdminReceiver(address(0));
        vm.expectRevert(CurveYieldProposalBond.InvalidAddress.selector);
        bond.setDestinations(address(0), newE);
        vm.expectRevert(CurveYieldProposalBond.InvalidAddress.selector);
        bond.setDestinations(newC, address(0));

        vm.startPrank(user);
        vm.expectRevert(abi.encodeWithSignature("OwnableUnauthorizedAccount(address)", user));
        bond.setAdminReceiver(user);
        vm.expectRevert(abi.encodeWithSignature("OwnableUnauthorizedAccount(address)", user));
        bond.setDestinations(user, user);
        vm.expectRevert(abi.encodeWithSignature("OwnableUnauthorizedAccount(address)", user));
        bond.setParam(1, address(target), target.setter.selector, 1, 2, true);
        vm.expectRevert(abi.encodeWithSignature("OwnableUnauthorizedAccount(address)", user));
        bond.setTerms(1, 1, 1 days);
        vm.stopPrank();

        // the slash uses the new receivers
        uint256 id = _request(50);
        vm.prank(safe);
        bond.reject(id);
        assertEq(cy.balanceOf(newAdmin), BOND / 3);
        assertEq(cy.balanceOf(newC), BOND / 3);
        assertEq(cy.balanceOf(newE), BOND - 2 * (BOND / 3));
    }

    function test_setTermsAndParamBounds() public {
        vm.expectRevert(CurveYieldProposalBond.OutOfRange.selector);
        bond.setTerms(0, 100e18, 7 days);
        vm.expectRevert(CurveYieldProposalBond.OutOfRange.selector);
        bond.setTerms(1, 1_000e18 + 1, 7 days);
        vm.expectRevert(CurveYieldProposalBond.OutOfRange.selector);
        bond.setTerms(1, 1, 1 days - 1);
        vm.expectRevert(CurveYieldProposalBond.OutOfRange.selector);
        bond.setTerms(1, 1, 30 days + 1);
        bond.setTerms(1, 1_000e18, 30 days);
        assertEq(bond.bondAmount(), 1);
        vm.expectRevert(CurveYieldProposalBond.BadParam.selector);
        bond.setParam(1, address(0), bytes4(0), 1, 2, true);
        vm.expectRevert(CurveYieldProposalBond.BadParam.selector);
        bond.setParam(1, address(target), bytes4(0), 3, 2, true);
        bond.setParam(1, address(target), target.setAdmin.selector, 0, 5, true); // appends id 1
        assertEq(bond.paramsLength(), 2);
        bond.setParam(0, address(target), target.setter.selector, 1, 2, true); // updates id 0
        assertEq(bond.paramsLength(), 2);
        assertEq(bond.paramOf(0).max, 2);
    }
}
