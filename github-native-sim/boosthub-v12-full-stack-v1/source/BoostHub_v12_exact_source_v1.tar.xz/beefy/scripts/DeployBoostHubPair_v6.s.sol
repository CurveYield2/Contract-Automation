// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// Deployment-only Foundry script; no factory deployed or referenced at runtime.
// Requires forge-std in the user's GitHub build environment.
// Runs EXACTLY two deployment transactions from the same EOA with no intervening nonce use.
import "forge-std/Script.sol";
import "../contracts/beefy/StrategyConvexBoostHubStakingV5.sol";
import "../contracts/beefy/BeefyVaultV7FixedV2.sol";

contract DeployBoostHubPairV6 is Script {
    function run() external {
        uint256 privateKey = vm.envUint("PRIVATE_KEY");
        address deployer = vm.addr(privateKey);
        address stakingAddress = vm.envAddress("BOOSTHUB_STAKING");
        address wantAddress = IBoostHubStakingV1(stakingAddress).lp_token();
        uint256 nextNonce = vm.getNonce(deployer);
        address predictedVault = vm.computeCreateAddress(deployer, nextNonce + 1);

        BaseAllToWantBoostHubV5.Addresses memory addresses = BaseAllToWantBoostHubV5.Addresses({
            want: wantAddress,
            vault: predictedVault,
            swapper: vm.envAddress("SWAPPER"),
            adminFeeReceiver: vm.envAddress("STRATEGY_ADMIN_FEE_RECEIVER")
        });
        BaseAllToWantBoostHubV5.FeeSettings memory fees = BaseAllToWantBoostHubV5.FeeSettings({
            totalPerformanceFeeBps: uint16(vm.envUint("PERFORMANCE_FEE_BPS")),
            callShareBps: uint16(vm.envUint("CALL_FEE_SHARE_BPS")),
            adminShareBps: uint16(vm.envUint("ADMIN_FEE_SHARE_BPS"))
        });
        require(uint256(fees.callShareBps) + fees.adminShareBps == 10_000, "Invalid share split");
        require(fees.totalPerformanceFeeBps <= 10_000, "Invalid strategy fee");
        // One constructor-only minimum in underlying-token smallest units.
        // Example: 1e6 means 1.0 token if the deposit token has 6 decimals.
        uint256 minWantOutput = vm.envUint("MIN_REWARD_OUTPUT_WANT_BASE_UNITS");
        uint256 lockDuration = vm.envUint("STRATEGY_LOCK_DURATION_SECONDS");
        uint256 withdrawalFeeBps = vm.envUint("VAULT_WITHDRAWAL_FEE_BPS");
        address adminFeeReceiver = vm.envAddress("VAULT_ADMIN_FEE_RECEIVER");
        string memory shareName = vm.envString("VAULT_SHARE_NAME");
        string memory shareSymbol = vm.envString("VAULT_SHARE_SYMBOL");

        vm.startBroadcast(privateKey);
        StrategyConvexBoostHubStakingV5 strategy = new StrategyConvexBoostHubStakingV5(stakingAddress, addresses, fees, lockDuration, minWantOutput);
        BeefyVaultV7FixedV2 vault = new BeefyVaultV7FixedV2(
            IStrategyBoostHubV1(address(strategy)), shareName, shareSymbol, withdrawalFeeBps, adminFeeReceiver
        );
        require(address(vault) == predictedVault, "Predicted CREATE address mismatch");
        require(address(vault.strategy()) == address(strategy), "Strategy mismatch");
        vm.stopBroadcast();
    }
}
