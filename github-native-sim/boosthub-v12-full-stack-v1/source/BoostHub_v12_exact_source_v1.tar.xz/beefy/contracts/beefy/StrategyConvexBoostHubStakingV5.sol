// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// Based on Beefy StrategyConvexStakingFraxtal.sol (blob 0560055143e89fb62869dcfb140adb75435bf303).
// Main replacements: exact BoostHubStaking Vyper ABI, dynamic rewards, no external strategy factory.
import "./BaseAllToWantBoostHubV5.sol";
import "./interfaces/IBoostHubStakingV1.sol";
import "@openzeppelin-4/contracts/token/ERC20/IERC20.sol";

contract StrategyConvexBoostHubStakingV5 is BaseAllToWantBoostHubV5 {
    IBoostHubStakingV1 public immutable staking;
    uint256 public constant MAX_STAKING_REWARDS = 8;

    constructor(
        address _staking,
        Addresses memory _addresses,
        FeeSettings memory _fees,
        uint256 _lockDuration,
        uint256 _minWantOutput
    ) BaseAllToWantBoostHubV5(_addresses, _fees, _lockDuration, _minWantOutput) {
        require(_staking != address(0) && _staking.code.length > 0, "Invalid staking");
        require(IBoostHubStakingV1(_staking).lp_token() == want, "Staking want mismatch");
        staking = IBoostHubStakingV1(_staking);
        _syncRewards();
    }

    function stratName() public pure override returns (string memory) {
        return "ConvexBoostHubStaking";
    }

    function balanceOfPool() public view override returns (uint256) {
        return staking.balanceOf(address(this));
    }

    function _deposit(uint256 amount) internal override {
        _approveExact(want, address(staking), amount);
        // Vyper function selector is deposit(uint256,address), NOT stake/stakeFor.
        staking.deposit(amount, address(this));
    }

    function _withdraw(uint256 amount) internal override {
        if (amount > 0) staking.withdraw(amount);
    }


    function _claim() internal override {
        // Staking harvest is separate from claim_rewards; both are required.
        staking.harvest();
        staking.claim_rewards();
        // Rescan after the claim to include newly paid tokens, including disabled
        // tokens that still had accrued rewards awaiting collection.
        _syncRewards();
    }

    /// @notice Current accepted reward tokens, read directly from staking (no stale stored list).
    /// Includes want; underlying-token rewards are charged directly without a swap.
    function acceptedRewardTokens() external view returns (address[] memory tokens) {
        uint256 count = staking.reward_count();
        require(count <= MAX_STAKING_REWARDS, "Excess staking rewards");
        uint256 active;
        for (uint256 i; i < count; ++i) {
            address token = staking.reward_tokens(i);
            if (token != address(0) && !staking.reward_disabled(token)) active++;
        }
        tokens = new address[](active);
        uint256 n;
        for (uint256 i; i < count; ++i) {
            address token = staking.reward_tokens(i);
            if (token != address(0) && !staking.reward_disabled(token)) tokens[n++] = token;
        }
    }

    /// @notice Permissionless explicit refresh, in addition to automatic refresh on deposit/harvest.
    function syncRewards() external {
        _syncRewards();
    }

    function _syncRewards() internal override {
        uint256 count = staking.reward_count();
        require(count <= MAX_STAKING_REWARDS, "Excess staking rewards");
        delete rewards;
        for (uint256 i; i < count; ++i) {
            address token = staking.reward_tokens(i);
            if (token == address(0)) continue;
            if (staking.reward_disabled(token) && IERC20(token).balanceOf(address(this)) == 0) continue;
            // Never swap want (it can be principal) or the staking address;
            // only registered reward-to-want pairs are active swaps.
            if (token == want || token == address(staking)) continue;
            // A staking reward is not an active converter route unless it was registered.
            // Keep it accounted for by staking, but never attempt an unregistered swap.
            if (!IBeefySwapperV2(swapper).isSupportedPair(token, want)) continue;
            rewards.push(token);
        }
        emit StakingRewardListRefreshed(rewards.length);
    }
}
