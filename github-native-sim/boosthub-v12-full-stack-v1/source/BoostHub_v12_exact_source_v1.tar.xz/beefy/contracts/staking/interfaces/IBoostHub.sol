// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.28;

interface IBoostHub {
    struct PoolView {
        address asset;
        address gauge;
        bool active;
        uint256 totalStaked;
        address[] rewardTokens;
        address depositor;
        bool depositorLocked;
        bytes4 checkpointSelector;
        uint16 platformFeeBps;
        address platformFeeRecipient;
        bool feeConfigSet;
        uint256[] accRewardPerShare;
    }

    struct PositionView {
        uint256 principal;
        bool approved;
        address[] rewardTokens;
        uint256[] pendingRewards;
    }

    struct SystemView {
        uint256 deployedAt;
        uint256 configChangeDelay;
        address vlBoost;
        address stakeDaoClaimExecutor;
        uint256 vlsdtDelegated;
        uint256 poolCount;
    }

    struct PendingFeeView {
        uint256 pid;
        uint16 platformFeeBps;
        address platformFeeRecipient;
        uint256 readyAt;
    }



    struct PendingTransactionsView {
        address pendingOwner;
        uint256 ownershipTransferReadyAt;
        PendingFeeView[] feeChanges;
    }

    function deposit(uint256 pid, uint256 amount) external;
    function withdraw(uint256 pid, uint256 amount) external;
    function harvest(uint256 pid) external returns (address[] memory tokens, uint256[] memory amounts);
    function claim(uint256 pid, address[] calldata rewardTokens, address receiver) external returns (address[] memory tokens, uint256[] memory amounts);
    function claimStakeDaoRewards(uint256 pid)
        external
        returns (address[] memory tokens, uint256[] memory amounts);
    function poolInfo(uint256 pid) external view returns (PoolView memory);
    function positionInfo(uint256 pid, address account) external view returns (PositionView memory);
    function pendingTransactions() external view returns (PendingTransactionsView memory);
    function systemInfo() external view returns (SystemView memory);
}
