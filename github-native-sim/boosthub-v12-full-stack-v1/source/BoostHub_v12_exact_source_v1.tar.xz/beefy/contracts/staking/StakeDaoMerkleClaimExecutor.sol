// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.28;

/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * Documentation: https://docs.curveyield.com
 * dApp: https://curveyield.online
 * GitHub: https://github.com/curveyield
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */

interface IMultiMerkleStash {
    function merkleRoot(address token) external view returns (bytes32);
    function update(address token) external view returns (uint256);
    function isClaimed(address token, uint256 index) external view returns (bool);
    function claim(
        address token,
        uint256 index,
        address account,
        uint256 amount,
        bytes32[] calldata merkleProof
    ) external;
}

interface IBoostHubRewardRegistry {
    struct PoolView {
        address asset;
        address gauge;
        bool active;
        uint256 totalStaked;
        address[] rewardTokens;
        address depositor;
        bool depositorLocked;
        bytes4 checkpointSelector;
        uint16 platformFeeBps;
        address platformFeeRecipient;
        bool feeConfigSet;
        uint256[] accRewardPerShare;
    }

    function owner() external view returns (address);
    function poolInfo(uint256 pid) external view returns (PoolView memory);
}

/// @title Stake DAO Merkle Claim Executor v8
/// @notice Stores verified Stake DAO claims and executes one registered token per BoostHub transaction boundary.
/// @dev BoostHub supplies the trusted PID directly. The BoostHub owner binds a new token to its PID
///      when supplying its first valid proof; subsequent proofs for that token may be supplied by anyone.
contract StakeDaoMerkleClaimExecutor {
    uint256 public constant VERSION = 8;

    error ZeroAddress();
    error ZeroAmount();
    error OnlyBoostHub();
    error OnlyConfigurator();
    error BoostHubAlreadySet();
    error BoostHubNotSet();
    error OnlyBoostHubOwner();
    error RewardTokenNotRegistered();
    error MerkleRootNotSet();
    error ClaimAlreadyCompleted();
    error InvalidProof();
    error ReentrantCall();
    error TargetNotConfigured();
    error TargetPidMismatch();

    struct Claim {
        uint256 pid;
        uint256 index;
        uint256 amount;
        uint256 updateNumber;
        bytes32 root;
        bool exists;
    }

    struct Target {
        uint256 pid;
        bool enabled;
    }

    address public boostHub;
    address public immutable configurator;
    IMultiMerkleStash public immutable merkleStash;

    mapping(address token => Target target) private _targets;
    address[] private _targetTokens;
    mapping(address token => Claim claim) private _claims;
    mapping(address token => bytes32[] proof) private _proofs;

    uint256 private _entered;

    event BoostHubSet(address indexed boostHub);

    event TargetConfigured(uint256 indexed pid, address indexed token);
    event ClaimSupplied(
        uint256 indexed pid,
        address indexed token,
        uint256 indexed updateNumber,
        uint256 index,
        uint256 amount,
        bytes32 root,
        address supplier
    );
    event ClaimExecuted(
        uint256 indexed pid,
        address indexed token,
        uint256 indexed updateNumber,
        uint256 index,
        uint256 amount
    );
    event ClaimFailed(uint256 indexed pid, address indexed token, uint256 indexed updateNumber);
    event ClaimInvalidated(
        uint256 indexed pid,
        address indexed token,
        uint256 indexed storedUpdateNumber,
        uint256 liveUpdateNumber,
        bytes32 storedRoot,
        bytes32 liveRoot,
        bool alreadyClaimed
    );

    modifier nonReentrant() {
        if (_entered != 0) revert ReentrantCall();
        _entered = 1;
        _;
        _entered = 0;
    }

    constructor(address configurator_, address merkleStash_) {
        if (configurator_ == address(0) || merkleStash_ == address(0)) revert ZeroAddress();
        configurator = configurator_;
        merkleStash = IMultiMerkleStash(merkleStash_);
    }

    /// @notice Permanently binds the deployed BoostHub; only the constructor-selected configurator may call.
    function setBoostHub(address boostHub_) external {
        if (msg.sender != configurator) revert OnlyConfigurator();
        if (boostHub != address(0)) revert BoostHubAlreadySet();
        if (boostHub_ == address(0)) revert ZeroAddress();
        boostHub = boostHub_;
        emit BoostHubSet(boostHub_);
    }

    /// @notice Supplies a current, valid claim for the permanently configured BoostHub account.
    /// @dev The BoostHub owner binds a new token to its PID; subsequent suppliers must use that PID.
    function supplyClaim(
        uint256 pid,
        address token,
        uint256 index,
        uint256 amount,
        bytes32[] calldata proof
    ) external nonReentrant {
        if (boostHub == address(0)) revert BoostHubNotSet();
        if (token == address(0)) revert ZeroAddress();
        if (amount == 0) revert ZeroAmount();
        Target memory target = _targets[token];
        if (target.enabled) {
            if (target.pid != pid) revert TargetPidMismatch();
        } else if (msg.sender != IBoostHubRewardRegistry(boostHub).owner()) {
            revert OnlyBoostHubOwner();
        }
        if (!_isRewardToken(pid, token)) {
            revert RewardTokenNotRegistered();
        }

        bytes32 root = merkleStash.merkleRoot(token);
        if (root == bytes32(0)) revert MerkleRootNotSet();
        if (merkleStash.isClaimed(token, index)) revert ClaimAlreadyCompleted();

        bytes32 leaf = keccak256(abi.encodePacked(index, boostHub, amount));
        if (_processProof(proof, leaf) != root) revert InvalidProof();

        if (!target.enabled) {
            _targets[token] = Target({pid: pid, enabled: true});
            _targetTokens.push(token);
            emit TargetConfigured(pid, token);
        }

        delete _proofs[token];
        for (uint256 i; i < proof.length; ++i) {
            _proofs[token].push(proof[i]);
        }

        uint256 updateNumber = merkleStash.update(token);
        _claims[token] = Claim({
            pid: pid,
            index: index,
            amount: amount,
            updateNumber: updateNumber,
            root: root,
            exists: true
        });

        emit ClaimSupplied(pid, token, updateNumber, index, amount, root, msg.sender);
    }

    /// @notice Executes one registered token claim inside BoostHub's per-token transaction.
    /// @dev Only BoostHub may call; absent/stale claims are skipped and failed claims stay retryable.
    function claimToken(uint256 pid, address token) external nonReentrant {
        if (msg.sender != boostHub) revert OnlyBoostHub();
        _executeClaim(pid, token);
    }

    function _executeClaim(uint256 pid, address token) internal {
        Claim memory claim_ = _claims[token];
        if (!claim_.exists || claim_.pid != pid) return;
        _requireTarget(pid, token);
        bytes32[] memory proof = _copyProof(token);

        uint256 liveUpdate = merkleStash.update(token);
        bytes32 liveRoot = merkleStash.merkleRoot(token);
        bool alreadyClaimed = merkleStash.isClaimed(token, claim_.index);

        if (
            claim_.pid != pid || claim_.updateNumber != liveUpdate || claim_.root != liveRoot
                || alreadyClaimed
        ) {
            delete _claims[token];
            delete _proofs[token];
            emit ClaimInvalidated(
                pid,
                token,
                claim_.updateNumber,
                liveUpdate,
                claim_.root,
                liveRoot,
                alreadyClaimed
            );
            return;
        }

        if (!_isRewardToken(pid, token)) {
            revert RewardTokenNotRegistered();
        }

        delete _claims[token];
        delete _proofs[token];
        try merkleStash.claim(token, claim_.index, boostHub, claim_.amount, proof) {
            emit ClaimExecuted(pid, token, claim_.updateNumber, claim_.index, claim_.amount);
        } catch {
            _claims[token] = claim_;
            for (uint256 i; i < proof.length; ++i) {
                _proofs[token].push(proof[i]);
            }
            emit ClaimFailed(pid, token, claim_.updateNumber);
        }
    }

    /// @notice Removes a claim that became stale after a Merkle-root update or was claimed elsewhere.
    function clearStaleClaim(address token) external nonReentrant returns (bool cleared) {
        Claim memory claim_ = _claims[token];
        if (!claim_.exists) return false;

        uint256 liveUpdate = merkleStash.update(token);
        bytes32 liveRoot = merkleStash.merkleRoot(token);
        bool alreadyClaimed = merkleStash.isClaimed(token, claim_.index);
        if (claim_.updateNumber == liveUpdate && claim_.root == liveRoot && !alreadyClaimed) return false;

        delete _claims[token];
        delete _proofs[token];
        emit ClaimInvalidated(
            claim_.pid,
            token,
            claim_.updateNumber,
            liveUpdate,
            claim_.root,
            liveRoot,
            alreadyClaimed
        );
        return true;
    }

    function targetPid(address token) external view returns (uint256 pid, bool enabled) {
        Target memory target = _targets[token];
        return (target.pid, target.enabled);
    }

    function targetCount() external view returns (uint256) {
        return _targetTokens.length;
    }

    function targetAt(uint256 index) external view returns (uint256 pid, address token) {
        token = _targetTokens[index];
        pid = _targets[token].pid;
    }

    function getClaim(address token) external view returns (Claim memory claim_, bytes32[] memory proof) {
        claim_ = _claims[token];
        proof = _copyProof(token);
    }

    function pendingTokens(uint256 pid) external view returns (address[] memory tokens) {
        uint256 count;
        for (uint256 i; i < _targetTokens.length; ++i) {
            address token = _targetTokens[i];
            if (_targets[token].pid == pid && _claims[token].exists) ++count;
        }

        tokens = new address[](count);
        uint256 cursor;
        for (uint256 i; i < _targetTokens.length; ++i) {
            address token = _targetTokens[i];
            if (_targets[token].pid == pid && _claims[token].exists) {
                tokens[cursor++] = token;
            }
        }
    }

    function hasPendingClaims(uint256 pid) external view returns (bool) {
        for (uint256 i; i < _targetTokens.length; ++i) {
            address token = _targetTokens[i];
            if (_targets[token].pid == pid && _claims[token].exists) return true;
        }
        return false;
    }


    /// @notice Returns canonical calldata for the pool-ID-only BoostHub claim method.
    function buildBoostHubClaimCalldata(uint256 pid) external view returns (bytes memory data) {
        IBoostHubRewardRegistry(boostHub).poolInfo(pid);
        data = abi.encodeWithSignature("claimStakeDaoRewards(uint256)", pid);
    }


    /// @dev Uses BoostHub's consolidated pool read to validate reward membership.
    function _isRewardToken(uint256 pid, address token) internal view returns (bool) {
        IBoostHubRewardRegistry.PoolView memory pool = IBoostHubRewardRegistry(boostHub).poolInfo(pid);
        for (uint256 i; i < pool.rewardTokens.length; ++i) {
            if (pool.rewardTokens[i] == token) return true;
        }
        return false;
    }

    function _requireTarget(uint256 pid, address token) internal view {
        Target memory target = _targets[token];
        if (!target.enabled) revert TargetNotConfigured();
        if (target.pid != pid) revert TargetPidMismatch();
    }

    function _copyProof(address token) internal view returns (bytes32[] memory proof) {
        bytes32[] storage stored = _proofs[token];
        proof = new bytes32[](stored.length);
        for (uint256 i; i < stored.length; ++i) {
            proof[i] = stored[i];
        }
    }

    function _processProof(bytes32[] calldata proof, bytes32 leaf) internal pure returns (bytes32 computedHash) {
        computedHash = leaf;
        for (uint256 i; i < proof.length; ++i) {
            bytes32 proofElement = proof[i];
            computedHash = computedHash <= proofElement
                ? keccak256(abi.encodePacked(computedHash, proofElement))
                : keccak256(abi.encodePacked(proofElement, computedHash));
        }
    }
}
