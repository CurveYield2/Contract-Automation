# BoostHub deployment and Fraxtal FXS → sdFXS converter — v9

## Scope
Ethereum has exactly two configured deployment pools: PID 0 sdCRV and PID 1 sdFXN. **sdYB is excluded from all new Hub, staking, strategy, vault and converter deployments.** Fraxtal has only PID 0 sdFXS. Do not register any additional swap pairs.

## Fraxtal downstream link and route
- Existing chain-252 BoostHub: `0xFbEF8941Da53EA724385B44E91ae9672061D0263` (only a source/configuration reference; new Hub is deployed separately).
- Its snapshot PID-0 staking: `0xa4BfFa7D08dC3c5a46bFC668C6dDa290BB3Cf183` (read-only reference; runner deploys fresh staking).
- FXS reward: `0xFc00000000000000000000000000000000000002`.
- sdFXS want/reward: `0x1AEe2382e05Dc68BDfC472F1E46d570feCca5814`.
- **Only converter route:** FXS → sdFXS using Curve `0x3df1658e3E76d14eF3C4d410829EA7575bB83B9B`, expected coin indices `0 → 1`.
- sdFXS rewards are already underlying and are not swapped. No other token is registered.
- `BoostHubFraxtalRewardConverter_v1.sol` is deployed chain-locally through the same CREATE3 converter salt as Ethereum, producing the same converter *address* if the factory/deployer/deploymentId match. **The code is different on each chain.**
- The Fraxtal converter uses direct `exchange(0,1,amount,minOut)` and the selected Curve pool's own EMA `price_oracle()`, falling back to `price_oracle(0)` only. It deliberately has **no** same-block `get_dy()` protection fallback. 1% slippage, owner explicitly assigned in constructor.
- Fraxtal strategy and Beefy vault are enabled. The strategy `swapper` resolves to the predicted Fraxtal converter address, not Ethereum bytecode.

## Economic configuration
| Pool | Performance fee | Caller / admin share of performance | Lock | Min output | Withdrawal fee |
|---|---|---|---|---|---|
| Ethereum sdCRV | 3% | 1667 / 8333 bps | 15 days | 0.2 sdCRV | 45 bps |
| Ethereum sdFXN | 3% | 1667 / 8333 bps | 15 days | 0.005 sdFXN | 90 bps |
| Fraxtal sdFXS | 3% | **500 / 9500 bps** | 15 days | 0.1 sdFXS | 30 bps |

## Compile externally and import artifacts (not locally)
Five required *current* compiled artifacts: staking v22, strategy V5, vault V2, Ethereum converter V6, and **Fraxtal converter V1**. Existing factory/Hub/helper artifacts are bundled. Compile via GitHub environment and import with `deployment/Import_Build_Artifacts_v4.py`, passing `--staking`, `--strategy`, `--vault`, `--converter`, and `--fraxtalConverter` paths. This operation only imports supplied artifacts and validates ABI/bytecode metadata.

## Run on Windows
1. Unzip completely; keep all nested files together. Install Node.js 22+.
2. Supply deployer EOA via `-DeployerAddress`, or change `deployer` in the JSON. The hardcoded zero is a **placeholder**, not a deployment account.
3. For read-only checks: `powershell -ExecutionPolicy Bypass -File .\deployment\Deploy_Configure_v9.ps1 -Chain Fraxtal -Mode Check -DeployerAddress 0xYOUR_DEPLOYER`.
4. To deploy: same command with `-Mode Deploy`, signing with that deployer. Use `-Mode Verify` afterward.
5. If role acceptance is pending, rerun `-Mode AcceptRoles` using the authorized receiving owner/admin signer.

**Mandatory no-go on preflight failure:** RPC must identify chain 252, pool `coins(0)` must be FXS, `coins(1)` sdFXS, both token decimals 18, and `price_oracle()` or indexed equivalent must produce a positive value. No transaction is broadcast on preflight failure. Runtime converter `getAmountOut` must produce a nonzero oracle quote. A route's existence alone does NOT prove safe execution: successful swap simulation remains a prerequisite to funding a live vault.

**No compilation, dependency installation, or live transaction was performed for this package.**


## v12 — Ethereum stETH/ETH oracle liveness repair

The legacy stETH/ETH Curve pool 0xDC24316b9AE028F1497c275EB9192a3Ea0f67022 does not expose `price_oracle()` or `price_oracle(0)` and caused wstETH -> sdFXN conversion preview to revert in full-chain simulation. The converter now uses Curve stETH-NG 0x21E27a5E5513D6e65C4f830167390997aA84843a with the same [ETH, stETH] coin ordering (swap indices 1 -> 0), verified via the Ethereum RPC. This retains the converter's pool-local EMA-only slippage requirements. All three registered Ethereum conversion pairs and Fraxtal FXS -> sdFXS are retained. Do not deploy from v11; use v12 and check that its exact source is compiled and fork-verified.
