const {test} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const {spawnSync} = require('node:child_process');
const runner = require('./deploy_runner_v9.cjs');
const config = JSON.parse(fs.readFileSync(path.join(__dirname,'deployment_config_v9.json'),'utf8'));
const address = '0x1000000000000000000000000000000000000001';
const configForTests = () => {
  const c=structuredClone(config);
  c.deployer=address;
  return c;
};
test('only Ethereum PID 0 and 1 have configured Beefy strategies and vaults',()=>{
  const c=configForTests(); assert.equal(runner.validateConfig(c),c);
  assert.equal(c.deploymentId,"CurveYield.BoostHub.Stack.v3");
  assert.deepEqual(c.chains.ethereum.pools.map(p=>p.pid),[0,1]);
  assert(c.chains.ethereum.pools.every(p=>p.beefy.enabled));
  assert(c.chains.fraxtal.pools.every(p=>p.beefy.enabled));
});
test('no unspecified or invalid vault fees, token converter or fee splits are accepted',()=>{
  const incomplete=configForTests();incomplete.chains.ethereum.pools[0].beefy.withdrawalFeeBps=null;
  assert.throws(()=>runner.validateConfig(incomplete),/Beefy.*withdrawalFeeBps/);
  const c=configForTests();c.chains.ethereum.pools[1].beefy.adminShareBps=8000;
  assert.throws(()=>runner.validateConfig(c),/total 10000/);
  const d=configForTests();d.chains.ethereum.pools[1].beefy.minWantOutputBaseUnits='1.2';
  assert.throws(()=>runner.validateConfig(d),/decimal string/);
  const e=configForTests();e.chains.ethereum.pools[1].beefy.enabled=false;
  assert.throws(()=>runner.validateConfig(e),/exactly two Beefy vaults/);
});
test('matching pair address slots are deterministic, distinct and independent of chain',()=>{
  const f={factory:{bytecode:'0x6000600055'}};
  const a=runner.predictAddresses(f,address,'release-test',2);
  const b=runner.predictAddresses(f,address,'release-test',1);
  assert.equal(a.staking[0],b.staking[0]);
  assert.equal(a.strategy[0],b.strategy[0]);
  assert.equal(a.vault[0],b.vault[0]);
  assert.equal(new Set([...a.staking,...a.strategy,...a.vault]).size,6);
  assert.notEqual(a.strategy[0],a.vault[0]);
  assert.notEqual(a.vault[0],a.vault[1]);
  assert.notEqual(a.converter,a.vault[0]);
});
test('a broken package fails before network access or transaction broadcast',()=>{
  const result=spawnSync(process.execPath,[path.join(__dirname,'deploy_runner_v9.cjs')],
    {input:JSON.stringify({mode:'Deploy',chain:'Ethereum',configPath:path.join(__dirname,'deployment_config_v9.json'),
     packageRoot:path.resolve(__dirname,'..')}),env:{...process.env,BOOSTHUB_EXECUTE:'1'},encoding:'utf8'});
  assert.equal(result.status,1);
  assert.match(result.stderr,/Missing current compiled staking artifact/);
});

test('two strategies share one predicted converter instead of external swapper addresses',()=>{
 const c=configForTests();runner.validateConfig(c);
 assert.equal(c.chains.ethereum.converter.enabled,true);
 assert.equal(c.chains.fraxtal.converter.enabled,true);
 assert.equal(c.chains.ethereum.converter.slippageBps,100);
 assert(c.chains.ethereum.pools.every(p=>p.beefy.swapper==='shared-converter'));
 assert.equal(runner.DEFAULT_CONVERTER_PAIRS.length,3);
});
test('converter slippage, owner and policy are validated before deployment',()=>{
 const c=configForTests();c.chains.ethereum.converter.slippageBps=401;
 assert.throws(()=>runner.validateConfig(c),/slippageBps/);
 const d=configForTests();d.chains.ethereum.converter.owner='0x0000000000000000000000000000000000000000';
 assert.throws(()=>runner.validateConfig(d),/converter owner/);
 const e=configForTests();e.chains.ethereum.pools[0].beefy.swapper=address;
 assert.throws(()=>runner.validateConfig(e),/shared converter/);
});


test('v12 validator rejects a ninth unique staking reward token before broadcast',()=>{
  const c=configForTests();
  const pool=c.chains.ethereum.pools[0];
  const extras=[
    '0x0000000000000000000000000000000000000101',
    '0x0000000000000000000000000000000000000102',
    '0x0000000000000000000000000000000000000103',
    '0x0000000000000000000000000000000000000104'
  ];
  pool.externalRewardTokens=extras; // 5 current hub tokens + 4 additional = 9 total, including want.
  assert.throws(()=>runner.validateConfig(c),/eight unique rewards/);
});
test('v12 validator still permits exactly eight distinct staking rewards',()=>{
  const c=configForTests();
  c.chains.ethereum.pools[0].externalRewardTokens=[
    '0x0000000000000000000000000000000000000101',
    '0x0000000000000000000000000000000000000102',
    '0x0000000000000000000000000000000000000103'
  ];
  assert.equal(runner.validateConfig(c),c);
});


test('v12 converter verification tracks registered routes only, never infers required swaps from staking reward lists',()=>{
  const mjs=fs.readFileSync(path.join(__dirname,'deploy_runner_v9.mjs'),'utf8');
  const cjs=fs.readFileSync(path.join(__dirname,'deploy_runner_v9.cjs'),'utf8');
  for(const source of [mjs,cjs]) {
    const method=source.slice(source.indexOf('async function verifyConverter('),source.indexOf('function validateConfig('));
    assert.match(method,/routeAt\(i\)/);
    assert.match(method,/isSupportedPair\(from,to\)/);
    assert.doesNotMatch(method,/hubRewardTokens|externalRewardTokens|\bgaps\b|REWARD_ROUTES_INCOMPLETE/);
    assert.match(method,/activeRoutes/);
  }
});
test('v12 strategy includes only registered converter pairs in its active swap array',()=>{
  const root=path.resolve(__dirname,'..');
  const strategy=fs.readFileSync(path.join(root,'beefy/contracts/beefy/StrategyConvexBoostHubStakingV5.sol'),'utf8');
  const iface=fs.readFileSync(path.join(root,'beefy/contracts/beefy/interfaces/IBeefySwapperV2.sol'),'utf8');
  assert.match(iface,/function isSupportedPair\(address fromToken, address toToken\)/);
  assert.match(strategy,/if \(!IBeefySwapperV2\(swapper\)\.isSupportedPair\(token, want\)\) continue;/);
  assert.match(strategy,/staking\.reward_count\(\)/);
});


test('v12 immutable economic choices and chain-specific caller allocations',()=>{
  const c=configForTests();
  assert.equal(runner.validateConfig(c),c);
  for(const p of c.chains.ethereum.pools){
    assert.equal(p.beefy.totalPerformanceFeeBps,300);
    assert.equal(p.beefy.callShareBps,1667);
    assert.equal(p.beefy.adminShareBps,8333);
    assert.equal(p.beefy.lockDurationSeconds,1296000);
  }
  const crv=c.chains.ethereum.pools[0].beefy;
  assert.deepEqual([crv.minWantOutputTokens,crv.minWantOutputBaseUnits,crv.withdrawalFeeBps],['0.2','200000000000000000',45]);
  const fxn=c.chains.ethereum.pools[1].beefy;
  assert.deepEqual([fxn.minWantOutputTokens,fxn.minWantOutputBaseUnits,fxn.withdrawalFeeBps],['0.005','5000000000000000',90]);
  const frax=c.chains.fraxtal.pools[0].beefy;
  assert.equal(frax.enabled,true,'Fraxtal deploys its own converter before the vault');
  assert.deepEqual([frax.totalPerformanceFeeBps,frax.callShareBps,frax.adminShareBps,frax.lockDurationSeconds], [300,500,9500,1296000]);
  assert.deepEqual([frax.minWantOutputTokens,frax.minWantOutputBaseUnits,frax.withdrawalFeeBps],['0.1','100000000000000000',30]);
});
test('v12 Fraxtal uses a single on-pool FXS -> sdFXS converter',()=>{
 const c=configForTests();assert.equal(runner.validateConfig(c),c);
 assert.equal(c.chains.fraxtal.converter.enabled,true);
 assert.equal(c.chains.fraxtal.converter.routePolicy,'fraxtal-fxs-to-sdfxs-only');
 assert.equal(c.chains.fraxtal.converter.pool.toLowerCase(),'0x3df1658e3e76d14ef3c4d410829ea7575bb83b9b');
 assert.equal(c.chains.fraxtal.pools[0].beefy.swapper,'shared-converter');
 assert.deepEqual(c.chains.fraxtal.pools.map(p=>p.pid),[0]);
 const changed=configForTests();changed.chains.fraxtal.converter.pool=address;
 assert.throws(()=>runner.validateConfig(changed),/single confirmed Curve pool/);
 const bypass=configForTests();bypass.chains.fraxtal.pools[0].beefy.swapper=address;
 assert.throws(()=>runner.validateConfig(bypass),/chain-local shared converter/);
 const extra=configForTests();extra.chains.fraxtal.pools.push({...extra.chains.fraxtal.pools[0],pid:1});
 assert.throws(()=>runner.validateConfig(extra),/exactly one sdFXS staking pool/);
});

test('v12 Fraxtal converter source has exactly one registered pair and pool EMA protection',()=>{
 const root=path.resolve(__dirname,'..');
 const frax=fs.readFileSync(path.join(root,'beefy/contracts/converter/BoostHubFraxtalRewardConverter_v1.sol'),'utf8');
 assert.match(frax,/routeCount\(\) external pure returns \(uint256\) \{ return 1; \}/);
 assert.match(frax,/CURVE_POOL = 0x3df1658e3E76d14eF3C4d410829EA7575bB83B9B/);
 assert.match(frax,/function _poolOracle\(\) internal view/);
 assert.match(frax,/price_oracle\(\)/);
 assert.match(frax,/Math\.mulDiv\(amountIn, 1e18, _poolOracle\(\)\)/);
 assert.match(frax,/exchange\(0, 1, amountIn, minimum\)/);
 assert.doesNotMatch(frax,/function\s+get_dy|function\s+setRoute|function\s+addRoute|\brouter\s*=/);
 for(const ext of ['mjs','cjs']) {
   const runnerCode=fs.readFileSync(path.join(__dirname,'deploy_runner_v9.'+ext),'utf8');
   assert.match(runnerCode,/fraxtalConverter/);
   assert.match(runnerCode,/ctx\.name==='fraxtal'\?artifacts\.fraxtalConverter:artifacts\.converter/);
   assert.match(runnerCode,/Fraxtal pool price_oracle unavailable/);
   assert.match(runnerCode,/Fraxtal Curve pool coin ordering mismatch/);
   assert.match(runnerCode,/Fraxtal pool EMA oracle quote failed/);
 }
});
test('v12 rejects mis-scaled minimum-output amounts even when numeric',()=>{
 const c=configForTests();c.chains.ethereum.pools[0].beefy.minWantOutputBaseUnits='20000000000000000';
 assert.throws(()=>runner.validateConfig(c),/base units do not match/);
});
test('v12 rejects a third Ethereum pool before any chain access',()=>{
 const c=configForTests(); const unexpected=structuredClone(c.chains.ethereum.pools[1]);
 unexpected.pid=2;unexpected.asset='0x1000000000000000000000000000000000000003';
 unexpected.gauge='0x28604Ff7B4aEAE28d4d9e54d14038c910844343a';
 c.chains.ethereum.pools.push(unexpected);
 assert.throws(()=>runner.validateConfig(c),/exactly two Beefy vaults/);
});
test('v12 converter registers only three defaults with no removed-pool route',()=>{
 const c=configForTests();assert.equal(runner.validateConfig(c),c);
 const pairs=runner.DEFAULT_CONVERTER_PAIRS;
 assert.equal(pairs.length,3);
 assert(pairs.every(([,out])=>out.toLowerCase()===c.chains.ethereum.pools[0].asset.toLowerCase()||out.toLowerCase()===c.chains.ethereum.pools[1].asset.toLowerCase()));
 const source=fs.readFileSync(path.join(__dirname,'../beefy/contracts/converter/BoostHubEthereumRewardConverter_v7.sol'),'utf8');
 assert.equal((source.match(/_installOriginalRoute\(/g)||[]).length,4); // 3 calls + declaration
 assert.doesNotMatch(source,/directYb|_convertSdYb/);
});

test('v12 also rejects replacing either approved Ethereum pool token',()=>{
 const c=configForTests();c.chains.ethereum.pools[1].asset='0x1000000000000000000000000000000000000002';
 assert.throws(()=>runner.validateConfig(c),/exactly two Beefy vaults/);
});
