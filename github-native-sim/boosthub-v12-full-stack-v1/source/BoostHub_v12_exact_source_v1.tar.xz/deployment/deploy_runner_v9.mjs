import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { AbiCoder, Contract, ContractFactory, FetchRequest, JsonRpcProvider, Wallet, ZeroAddress,
  concat, getAddress, getCreate2Address, getCreateAddress, id, keccak256, parseUnits, toUtf8Bytes } from 'ethers';


// Fixed constructor-installed pairs in BoostHubEthereumRewardConverter_v7.
export const DEFAULT_CONVERTER_PAIRS = [
  ['0xD533a949740bb3306d119CC777fa900bA034cd52','0xD1b5651E55D4CeeD36251c61c50C889B36F6abB5'],
  ['0xf939E0A03FB07F59A73314E73794Be0E57ac1b4E','0xD1b5651E55D4CeeD36251c61c50C889B36F6abB5'],
  ['0x7f39C581F595B53c5cb19bD0b3f8dA6c935E2Ca0','0xe19d1c837B8A1C83A56cD9165b2c0256D39653aD']
];

const FRAXTAL_DEFAULT_CONVERTER_PAIRS = [
  ['0xFc00000000000000000000000000000000000002','0x1AEe2382e05Dc68BDfC472F1E46d570feCca5814']
];
const FRAXTAL_ROUTE_POOL = '0x3df1658e3E76d14eF3C4d410829EA7575bB83B9B';

export const UNIVERSAL_PROXY = '0x4e59b44847b379578588920ca78fbf26c0b4956c';
export const FRAXTAL_URD = '0xAeB87C92b2E7d3b21fA046Ae1E51E0ebF11A41Af';
export const FRAXTAL_SDFXS = '0x1AEe2382e05Dc68BDfC472F1E46d570feCca5814';
const PROXY_CREATION = '0x67363d3d37363d34f03d5260086018f3';
const coder = AbiCoder.defaultAbiCoder();
const eq = (a,b) => String(a).toLowerCase() === String(b).toLowerCase();
const requireThat = (b,m) => { if(!b) throw new Error(m); };
const json = x => JSON.stringify(x,(_,v)=>typeof v==='bigint'?v.toString():v,2);
const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
export function parseJson(text) { return JSON.parse(String(text).replace(/^\uFEFF/,'')); }
function address(a,label) { try { const v=getAddress(a);requireThat(v!==ZeroAddress,label+' cannot be zero');return v; } catch {throw new Error(label+' must be a nonzero EVM address');} }


function checkBeefySettings(p,networkName) {
  const b=p.beefy;
  requireThat(b&&typeof b.enabled==='boolean',networkName+' pool '+p.pid+' must specify beefy.enabled');
  if(!b.enabled)return;
  const prefix=networkName+' pool '+p.pid+' Beefy';
  for(const k of ['strategyAdminFeeReceiver','vaultAdminFeeReceiver'])
    address(b[k],prefix+'.'+k+' (set required operator input)');
  for(const k of ['shareName','shareSymbol'])
    requireThat(typeof b[k]==='string'&&b[k].trim().length>0&&b[k].length<=100,prefix+'.'+k+' is required');
  for(const k of ['totalPerformanceFeeBps','callShareBps','adminShareBps','withdrawalFeeBps'])
    requireThat(Number.isInteger(b[k])&&b[k]>=0&&b[k]<=10000,prefix+'.'+k+' must be an explicitly chosen integer between 0 and 10000');
  requireThat(b.callShareBps+b.adminShareBps===10000,prefix+' performance-fee shares must total 10000');
  requireThat(Number.isSafeInteger(b.lockDurationSeconds)&&b.lockDurationSeconds>=0,prefix+' lockDurationSeconds must be chosen');
  requireThat(typeof b.minWantOutputBaseUnits==='string'&&/^(0|[1-9][0-9]*)$/.test(b.minWantOutputBaseUnits),prefix+' minWantOutputBaseUnits must be a decimal string');
  requireThat(BigInt(b.minWantOutputBaseUnits)<=(2n**256n-1n),prefix+' minWantOutputBaseUnits overflow');
  requireThat(b.swapper==='shared-converter',prefix+' must use the chain-local shared converter');
  requireThat(Number.isInteger(b.wantDecimals)&&b.wantDecimals>=0&&b.wantDecimals<=77,prefix+' wantDecimals must be provided');
  requireThat(typeof b.minWantOutputTokens==='string'&&/^\d+(\.\d+)?$/.test(b.minWantOutputTokens),prefix+' minimum output human units must be specified');
  requireThat(parseUnits(b.minWantOutputTokens,b.wantDecimals)===BigInt(b.minWantOutputBaseUnits),prefix+' base units do not match token decimal scaling');
}

function checkConverterSettings(network,chainName) {
  const c=network.converter;
  requireThat(c&&c.enabled===true,chainName+' requires a deployed chain-local converter');
  requireThat(Number.isInteger(c.slippageBps)&&c.slippageBps>=0&&c.slippageBps<=400,
    chainName+' converter slippageBps must be between 0 and 400');
  address(c.owner,chainName+' converter owner');
  requireThat(c.routePolicy===(chainName==='ethereum'?'original-three-only':'fraxtal-fxs-to-sdfxs-only'),
    chainName+' converter route policy must match the canonical on-chain routes');
  if(chainName==='fraxtal') {
    requireThat(eq(c.pool,FRAXTAL_ROUTE_POOL),'Fraxtal FXS/sdFXS converter must use the single confirmed Curve pool');
    requireThat(network.pools.length===1&&network.pools[0].pid===0&&eq(network.pools[0].asset,FRAXTAL_SDFXS),
      'Fraxtal requires exactly one sdFXS staking pool at PID 0');
  }
}
function strategySwapper(p,prediction) {
  return p.beefy.swapper==='shared-converter'?prediction.converter:p.beefy.swapper;
}

async function verifyConverter(ctx,artifacts,prediction) {
  if(!ctx.network.converter.enabled)return {activeRoutes:[],previewFailures:[]};
  const {provider,network}=ctx;
  const artifact=ctx.name==='fraxtal'?artifacts.fraxtalConverter:artifacts.converter;
  const defaults=ctx.name==='fraxtal'?FRAXTAL_DEFAULT_CONVERTER_PAIRS:DEFAULT_CONVERTER_PAIRS;
  requireThat(codeMatches(artifact,await provider.getCode(prediction.converter)),
    ctx.name+' converter runtime mismatch');
  const c=new Contract(prediction.converter,artifact.abi,provider);
  requireThat(eq(await c.owner(),network.converter.owner),'Shared converter owner mismatch');
  requireThat(Number(await c.slippageBps())===network.converter.slippageBps,'Shared converter slippage mismatch');
  const count=Number(await c.routeCount());
  requireThat(Number.isSafeInteger(count)&&
    (ctx.name==='fraxtal'?count===1:count>=defaults.length),
    ctx.name+' converter route count mismatch');
  const activeRoutes=[],previewFailures=[],seen=new Set();
  for(let i=0;i<count;i++) {
    const [from,to]=await c.routeAt(i);
    const key=from.toLowerCase()+'/'+to.toLowerCase();
    requireThat(!seen.has(key),'Duplicate registered converter route: '+i);
    seen.add(key);
    requireThat(await c.isSupportedPair(from,to),'Converter registry mismatch: '+i);
    if(i<defaults.length) {
      const [expectedFrom,expectedTo]=defaults[i];
      requireThat(eq(from,expectedFrom)&&eq(to,expectedTo),
        ctx.name+' converter original route mismatch: '+i);
    }
    activeRoutes.push({tokenIn:from,tokenOut:to});
    try {
      const token=new Contract(from,['function decimals() view returns(uint8)'],provider);
      const decimals=Number(await token.decimals());
      requireThat(decimals>=4&&decimals<=77,'Unsupported reward decimals');
      const quote=await c.getAmountOut(from,to,10n**BigInt(decimals-4));
      requireThat(quote>0n,'Zero oracle quote');
    } catch(e) {previewFailures.push({tokenIn:from,tokenOut:to,error:String(e.shortMessage||e.reason||e.message).slice(0,200)});}
  }
  // A missing EMA is a hard failure on Fraxtal; never mark a converter ready
  // merely because its route exists or the Curve pool supports spot quotes.
  requireThat(ctx.name!=='fraxtal'||previewFailures.length===0,
    'Fraxtal pool EMA oracle quote failed; conversion is not safe to activate: '+JSON.stringify(previewFailures));
  for(const f of previewFailures)console.warn(ctx.name+': CONVERTER ROUTE ORACLE PREVIEW FAILED '+f.tokenIn+' -> '+f.tokenOut);
  console.log(ctx.name+': converter '+prediction.converter+'; routes '+activeRoutes.length+'; oracle preview failures '+previewFailures.length);
  return {activeRoutes,previewFailures};
}

function validateConfig(c) {
  requireThat(c.version==='v9','Configuration version must be v9');
  address(c.deployer,'deployer');
  requireThat(typeof c.deploymentId==='string'&&c.deploymentId.length>0,'deploymentId is required');
  requireThat(c.chains&&Object.keys(c.chains).length>0,'At least one chain must be configured');
  for(const name of Object.keys(c.chains)) {
    const expected={ethereum:1,fraxtal:252}[name];requireThat(expected,'Unsupported chain');
    const n=c.chains[name];requireThat(n?.chainId===expected,name+' chainId is incorrect');
    for(const k of ['owner','rewardDistributor']) address(n[k],name+'.'+k);
    if(name==='fraxtal') {
      requireThat(eq(n.vlBoost,ZeroAddress),'Fraxtal has no vlBoost; set its address to zero');
      requireThat(eq(n.rewardDistributor,FRAXTAL_URD),'Fraxtal helper v5 uses the approved Stake DAO URD');
      requireThat(n.claimMode==='urd','Fraxtal requires the URD helper');
    }else {
      requireThat(n.claimMode==='stash','Ethereum requires the MultiMerkleStash helper');
      if(!eq(n.vlBoost,ZeroAddress))address(n.vlBoost,name+'.vlBoost');
    }
    requireThat(Array.isArray(n.pools)&&n.pools.length>0,name+' pools are required');
    requireThat(parseUnits(n.maxFeePerGasGwei,'gwei')>0n,name+' max gas fee must be positive');
    requireThat(parseUnits(n.priorityFeePerGasGwei,'gwei')>=0n,name+' priority fee must be nonnegative');
    requireThat(parseUnits(n.priorityFeePerGasGwei,'gwei')<=parseUnits(n.maxFeePerGasGwei,'gwei'),name+' priority exceeds maximum fee');
    const gauges=new Set();
    checkConverterSettings(n,name);
    n.pools.forEach((p,i)=>{
      requireThat(p.pid===i,name+' PIDs must preserve live order');
      for(const k of ['asset','gauge','stakingAdmin','keeper','stakingFeeReceiver','platformFeeRecipient'])address(p[k],name+'.pool['+i+'].'+k);
      requireThat(!gauges.has(p.gauge.toLowerCase()),'Duplicate gauge');gauges.add(p.gauge.toLowerCase());
      requireThat(Number.isInteger(p.platformFeeBps)&&p.platformFeeBps>=0&&p.platformFeeBps<=2000,'Platform fee out of range');
      requireThat(Number.isInteger(p.rewardSmoothingUnits)&&p.rewardSmoothingUnits>=0&&p.rewardSmoothingUnits<=300,'Reward smoothing out of range');
      requireThat(typeof p.active==='boolean'&&typeof p.lockDepositor==='boolean','Pool activity/lock must be boolean');
      requireThat(p.active||!p.lockDepositor,'An inactive depositor cannot be permanently locked');
      requireThat(/^0x[0-9a-fA-F]{8}$/.test(p.checkpointSelector),'Checkpoint selector must be bytes4');
      for(const list of [p.hubRewardTokens,p.externalRewardTokens,p.disabledRewardTokens]) {
        requireThat(Array.isArray(list),'Reward lists are required');list.forEach(a=>address(a,'reward token'));
        requireThat(new Set(list.map(a=>a.toLowerCase())).size===list.length,'Duplicate reward token');
      }
      requireThat(p.hubRewardTokens.length<=8,'Hub supports at most eight rewards');
      const rewards=[p.asset,...p.hubRewardTokens.filter(a=>!eq(a,p.asset)),...p.externalRewardTokens];
      requireThat(rewards.length<=8&&new Set(rewards.map(a=>a.toLowerCase())).size===rewards.length,'Staking supports eight unique rewards including its principal token');
      p.disabledRewardTokens.forEach(a=>requireThat(rewards.some(t=>eq(t,a)),'Disabled reward is unregistered'));
      checkBeefySettings(p,name);
    });
    if(name==='ethereum')requireThat(n.pools.length===2&&eq(n.pools[0].asset,'0xD1b5651E55D4CeeD36251c61c50C889B36F6abB5')&&eq(n.pools[1].asset,'0xe19d1c837B8A1C83A56cD9165b2c0256D39653aD')&&n.pools.every(p=>p.beefy.enabled),'Ethereum requires exactly two Beefy vaults on PIDs 0 and 1');
    if(name==='fraxtal')requireThat(eq(n.pools[0].asset,FRAXTAL_SDFXS)&&n.pools[0].hubRewardTokens.some(t=>eq(t,FRAXTAL_SDFXS)),'Fraxtal helper v5 requires sdFXS as registered PID-0 asset/reward');
  }
  return c;
}

export function predictAddresses(artifacts,deployer,deploymentId,count) {
  const factorySalt=id('CurveYield.BoostHubDeploymentFactory.v1');
  const factory=getCreate2Address(UNIVERSAL_PROXY,factorySalt,keccak256(artifacts.factory.bytecode));
  const get=(label)=>{
    const salt=id(deploymentId+'/'+label);
    const scoped=keccak256(coder.encode(['address','bytes32'],[deployer,salt]));
    const proxy=getCreate2Address(factory,scoped,keccak256(PROXY_CREATION));
    return getCreateAddress({from:proxy,nonce:1});
  };
  return {factory,factorySalt,hub:get('hub'),helper:get('helper'),converter:get('converter'),staking:Array.from({length:count},(_,i)=>get('staking/'+i)),strategy:Array.from({length:count},(_,i)=>get('beefy/strategy/'+i)),vault:Array.from({length:count},(_,i)=>get('beefy/vault/'+i))};
}

export async function submitStep(ctx,label,transaction) {
  let step=ctx.state.steps[label];
  if(step?.status==='confirmed') {
    const receipt=await ctx.provider.getTransactionReceipt(step.hash);
    requireThat(receipt&&receipt.status===1,'Recorded transaction is absent/reverted: '+label);
    return receipt;
  }
  if(!step) {
    requireThat(ctx.signer,'A signing key is required for '+label);
    const populated=await ctx.signer.populateTransaction(transaction);
    const raw=await ctx.signer.signTransaction(populated);
    step=ctx.state.steps[label]={hash:keccak256(raw),raw,nonce:populated.nonce,status:'pending'};
    ctx.save(); // Save before the first network submission; a retry must use identical signed bytes.
  }
  let receipt=await ctx.provider.getTransactionReceipt(step.hash);
  if(!receipt) {
    const pending=await ctx.provider.getTransaction(step.hash);
    if(!pending) {
      try {await ctx.provider.broadcastTransaction(step.raw);}catch(e){
        const found=await ctx.provider.getTransactionReceipt(step.hash)||await ctx.provider.getTransaction(step.hash);
        if(!found)throw e;
      }
    }
    receipt=await ctx.provider.waitForTransaction(step.hash,ctx.confirmations,ctx.timeoutMs);
  }
  requireThat(receipt,'Receipt timeout for '+label+'; rerun the same command and keep its state file');
  requireThat(receipt.status===1,'Transaction reverted: '+label+' '+step.hash);
  step.status='confirmed';step.blockNumber=receipt.blockNumber;step.gasUsed=receipt.gasUsed.toString();
  delete step.raw;ctx.save();return receipt;
}

function codeMatches(artifact,actual) {
  if(!actual||actual==='0x')return false;
  let a=actual.slice(2).toLowerCase(),b=artifact.deployedBytecode.slice(2).toLowerCase();
  if(a.length!==b.length)return false;
  for(const refs of Object.values(artifact.immutableReferences||{}))for(const {start,length}of refs){
    a=a.slice(0,start*2)+'0'.repeat(length*2)+a.slice((start+length)*2);
    b=b.slice(0,start*2)+'0'.repeat(length*2)+b.slice((start+length)*2);
  }
  return a===b;
}

function loadArtifacts(root) {
  const manifest=parseJson(fs.readFileSync(path.join(root,'package_manifest_v12.json'),'utf8'));
  for(const [relative,digest] of Object.entries(manifest.sha256)) {
    const full=path.resolve(root,relative);requireThat(full.startsWith(root+path.sep),'Invalid manifest path');
    requireThat(sha256(fs.readFileSync(full))===digest,'Package integrity mismatch: '+relative);
  }
  const artifactFiles={
    factory:'artifacts_v1/factory_v1.json',hub:'artifacts_v1/hub_v1.json',
    helper:'artifacts_v1/helper_v1.json',helperFraxtal:'artifacts_v1/helperFraxtal_v1.json',
    staking:'artifacts_v1/staking_v22.json',
    strategy:'beefy/artifacts_v1/strategy_v1.json',vault:'beefy/artifacts_v1/vault_v1.json',converter:'beefy/artifacts_v1/converter_v6.json',fraxtalConverter:'beefy/artifacts_v1/fraxtal_converter_v1.json'
  };
  const result={};
  for(const [key,rel] of Object.entries(artifactFiles)) {
    const full=path.join(root,rel);
    requireThat(fs.existsSync(full),'Missing current compiled '+key+' artifact: '+rel+'. Build on GitHub; never use historical staking v21 artifact.');
    const artifact=parseJson(fs.readFileSync(full,'utf8'));
    requireThat(Array.isArray(artifact.abi)&&/^0x[0-9a-fA-F]+$/.test(artifact.bytecode)&&/^0x[0-9a-fA-F]+$/.test(artifact.deployedBytecode),
      'Incomplete compiled artifact: '+rel);
    requireThat(!(artifact.linkReferences&&Object.keys(artifact.linkReferences).length),'Unlinked library references: '+rel);
    if(key==='staking'&&artifact.sourceVersion!==undefined)
      requireThat(artifact.sourceVersion==='v22','Historical staking artifact is not v22');
    const expectedContracts={strategy:'StrategyConvexBoostHubStakingV5',vault:'BeefyVaultV7FixedV2',converter:'BoostHubEthereumRewardConverter',fraxtalConverter:'BoostHubFraxtalRewardConverter'};
    if(expectedContracts[key]&&artifact.contractName!==undefined)
      requireThat(artifact.contractName===expectedContracts[key],'Unexpected compiled contract: '+key);
    result[key]=artifact;
  }
  return result;
}

export async function preflight(provider,network,prediction) {
  requireThat(Number(await provider.send('eth_chainId',[]))===network.chainId,'RPC connected to the wrong chain');
  const proxyCode=await provider.getCode(UNIVERSAL_PROXY);
  requireThat(proxyCode!=='0x'&&keccak256(proxyCode)===network.universalProxyCodeHash,'Canonical deterministic deployment proxy is missing or has different code');
  const dependencies=[['rewardDistributor',network.rewardDistributor]];
  if(!eq(network.vlBoost,ZeroAddress))dependencies.push(['vlBoost',network.vlBoost]);
  for(const [label,a]of dependencies) {
    requireThat(await provider.getCode(a)!=='0x',label+' has no contract code on chain '+network.chainId+'; configure a real dependency before deployment');
  }
  if(!eq(network.vlBoost,ZeroAddress)) {
    const vl=new Contract(network.vlBoost,['function delegatedIn(address) view returns(uint256)'],provider);await vl.delegatedIn(prediction.hub);
  }
  const stash=network.claimMode==='stash'?new Contract(network.rewardDistributor,['function merkleRoot(address) view returns(bytes32)','function update(address) view returns(uint256)'],provider):null;
  if(network.claimMode==='urd') {
    const urd=new Contract(network.rewardDistributor,['function root() view returns(bytes32)','function claimed(address,address) view returns(uint256)','function recipients(address) view returns(address)'],provider);
    await urd.root();await urd.claimed(prediction.hub,FRAXTAL_SDFXS);
    const recipient=await urd.recipients(prediction.hub);requireThat(eq(recipient,ZeroAddress)||eq(recipient,prediction.hub),'URD recipient would redirect rewards away from the new Hub');
  }
  if(network.chainId===252 && network.converter.enabled) {
    const pool=new Contract(FRAXTAL_ROUTE_POOL,[
      'function coins(uint256) view returns(address)',
      'function price_oracle() view returns(uint256)',
      'function price_oracle(uint256) view returns(uint256)'
    ],provider);
    requireThat(await provider.getCode(FRAXTAL_ROUTE_POOL)!=='0x','Fraxtal Curve pool has no code');
    requireThat(eq(await pool.coins(0),FRAXTAL_DEFAULT_CONVERTER_PAIRS[0][0])&&
      eq(await pool.coins(1),FRAXTAL_SDFXS),'Fraxtal Curve pool coin ordering mismatch');
    for(const token of FRAXTAL_DEFAULT_CONVERTER_PAIRS[0]) {
      const t=new Contract(token,['function decimals() view returns(uint8)'],provider);
      requireThat(Number(await t.decimals())===18,'Fraxtal converter requires both tokens to have 18 decimals');
    }
    let price;
    try {price=await pool['price_oracle()']();}
    catch {try{price=await pool['price_oracle(uint256)'](0);}catch{throw new Error('Fraxtal pool price_oracle unavailable: cannot safely deploy converter');}}
    requireThat(price>0n,'Fraxtal pool returned zero EMA price');
  }
  for(const p of network.pools) {
    if(p.beefy.enabled) {
      const selectedSwapper=strategySwapper(p,prediction);
      if(network.converter.enabled) requireThat(eq(selectedSwapper,prediction.converter),'Beefy PID '+p.pid+' is not connected to the shared converter');

    }
    const gauge=new Contract(p.gauge,['function staking_token() view returns(address)'],provider);
    requireThat(eq(await gauge.staking_token(),p.asset),'Gauge asset does not match pool '+p.pid);
    const asset=new Contract(p.asset,['function totalSupply() view returns(uint256)','function decimals() view returns(uint8)'],provider);await asset.totalSupply();
    if(p.beefy.enabled)requireThat(Number(await asset.decimals())===p.beefy.wantDecimals,'Underlying token decimals mismatch for Beefy PID '+p.pid);
    for(const token of [...p.hubRewardTokens,...p.externalRewardTokens]) requireThat(await provider.getCode(token)!=='0x','Reward token has no code: '+token);
    if(stash&&p.hubRewardTokens.length){await stash.merkleRoot(p.hubRewardTokens[0]);await stash.update(p.hubRewardTokens[0]);}
    requireThat(!eq(p.stakingFeeReceiver,prediction.hub)&&!eq(p.stakingFeeReceiver,network.sourceHub),'Staking admin fees must have an external receiver; the revised Hub has no retained-token recovery');
  }
}

async function transaction(ctx,label,request) {
  if(ctx.state.steps[label])return submitStep(ctx,label,request);
  const block=await ctx.provider.getBlock('latest');
  const cap=parseUnits(ctx.network.maxFeePerGasGwei,'gwei'),tip=parseUnits(ctx.network.priorityFeePerGasGwei,'gwei');
  requireThat(block.baseFeePerGas!==null,'EIP-1559 base fee unavailable');
  requireThat(block.baseFeePerGas+tip<=cap,'Current base fee plus priority exceeds the configured gas cap');
  const maxFee=block.baseFeePerGas*2n+tip<cap?block.baseFeePerGas*2n+tip:cap;
  const estimate=await ctx.provider.estimateGas({...request,from:ctx.signer.address});
  const gasLimit=estimate*120n/100n+10000n;
  requireThat(gasLimit<block.gasLimit,'Transaction exceeds block gas limit');
  requireThat(await ctx.provider.getBalance(ctx.signer.address)>=gasLimit*maxFee,'Insufficient native balance for '+label);
  console.log(ctx.name+': '+label);
  const receipt=await submitStep(ctx,label,{...request,type:2,maxFeePerGas:maxFee,maxPriorityFeePerGas:tip,gasLimit,chainId:ctx.network.chainId});
  console.log('  confirmed '+receipt.hash+'; gas '+receipt.gasUsed);return receipt;
}

export async function deployAndConfigure(ctx,artifacts,prediction) {
  const {provider,network:n,deployer,deploymentId}=ctx;
  for(const [label,step]of Object.entries(ctx.state.steps))if(step.status==='pending')await submitStep(ctx,label,{});
  const factory=new Contract(prediction.factory,artifacts.factory.abi,ctx.signer);
  const existingFactory=await provider.getCode(prediction.factory);
  if(existingFactory==='0x') await transaction(ctx,'factory',{to:UNIVERSAL_PROXY,data:concat([prediction.factorySalt,artifacts.factory.bytecode]),value:0});
  requireThat(codeMatches(artifacts.factory,await provider.getCode(prediction.factory)),'Unexpected CREATE3 factory runtime');
  async function deploy(label,artifact,args,expected) {
    const code=await provider.getCode(expected);
    if(code==='0x') {
      const creation=await new ContractFactory(artifact.abi,artifact.bytecode).getDeployTransaction(...args);
      await transaction(ctx,'deploy/'+label,await factory.deploy.populateTransaction(id(deploymentId+'/'+label),creation.data));
    }
    requireThat(codeMatches(artifact,await provider.getCode(expected)),'Unexpected deployed runtime: '+label);
    return new Contract(expected,artifact.abi,ctx.signer);
  }
  if(n.converter.enabled){
    const converterArtifact=ctx.name==='fraxtal'?artifacts.fraxtalConverter:artifacts.converter;
    const converter=await deploy('converter',converterArtifact,[n.converter.slippageBps,n.converter.owner],prediction.converter);
    requireThat(eq(await converter.owner(),n.converter.owner) && Number(await converter.slippageBps())===n.converter.slippageBps,
      'Shared converter constructor differs from this release');
  }
  const helperArtifact=n.claimMode==='urd'?artifacts.helperFraxtal:artifacts.helper;
  const helperArgs=n.claimMode==='urd'?[deployer]:[deployer,n.rewardDistributor];
  const helper=await deploy('helper',helperArtifact,helperArgs,prediction.helper);
  const hub=await deploy('hub',artifacts.hub,[deployer,n.vlBoost,prediction.helper],prediction.hub);
  requireThat(eq(await helper.configurator(),deployer)&&eq(n.claimMode==='urd'?await helper.urd():await helper.merkleStash(),n.rewardDistributor),'Helper constructor differs from this release');
  let bound=await helper.boostHub();
  if(eq(bound,ZeroAddress))await transaction(ctx,'bind/helper',await helper.setBoostHub.populateTransaction(prediction.hub));
  requireThat(eq(await helper.boostHub(),prediction.hub),'Helper is bound to a different Hub');
  const sys=await hub.systemInfo();
  requireThat(eq(sys.vlBoost,n.vlBoost)&&eq(sys.stakeDaoClaimExecutor,prediction.helper),'Hub constructor differs from this release');
  requireThat(Number(sys.poolCount)<=n.pools.length,'Existing deployment contains unexpected pools');
  for(const p of n.pools) {
    const count=Number((await hub.systemInfo()).poolCount);
    if(count===p.pid)await transaction(ctx,'pool/'+p.pid,await hub.addPoolsBatch.populateTransaction([p.asset],[p.gauge],[p.hubRewardTokens]));
    const info=await hub.poolInfo(p.pid);
    requireThat(eq(info.asset,p.asset)&&eq(info.gauge,p.gauge),'Existing pool differs from configuration');
    requireThat(json(info.rewardTokens.map(a=>a.toLowerCase()))===json(p.hubRewardTokens.map(a=>a.toLowerCase())),'Existing Hub reward list differs');
    const rewardArgs=Array(8).fill(ZeroAddress); // Staking discovers all Hub rewards in its constructor.
    const staking=await deploy('staking/'+p.pid,artifacts.staking,[p.asset,prediction.hub,p.pid,deployer,rewardArgs,p.stakingFeeReceiver,p.rewardSmoothingUnits,p.keeper],prediction.staking[p.pid]);
    requireThat(eq(await staking.lp_token(),p.asset)&&eq(await staking.boost_hub(),prediction.hub)&&Number(await staking.pid())===p.pid,'Staking constructor differs');
    for(const token of p.externalRewardTokens) {
      const tokens=[];for(let i=0;i<Number(await staking.reward_count());i++)tokens.push(await staking.reward_tokens(i));
      if(!tokens.some(t=>eq(t,token)))await transaction(ctx,'external/'+p.pid+'/'+token,await staking.add_external_reward.populateTransaction(token));
    }
    for(const token of p.disabledRewardTokens)if(!await staking.reward_disabled(token))await transaction(ctx,'disable/'+p.pid+'/'+token,await staking.disable_reward.populateTransaction(token));
    const allowance=await new Contract(p.asset,['function allowance(address,address) view returns(uint256)'],provider).allowance(prediction.staking[p.pid],prediction.hub);
    requireThat(allowance>0n,'Principal approval to Hub failed for pool '+p.pid);
    await deployBeefyPair(ctx,artifacts,prediction,p,deploy);
  }
  let needsConfig=false;
  for(const p of n.pools) {
    const q=await hub.poolInfo(p.pid);
    if(!eq(q.depositor,prediction.staking[p.pid])||q.depositorLocked!==p.lockDepositor||q.active!==p.active||!q.feeConfigSet||Number(q.platformFeeBps)!==p.platformFeeBps||!eq(q.platformFeeRecipient,p.platformFeeRecipient)||!eq(q.checkpointSelector,p.checkpointSelector))needsConfig=true;
  }
  if(needsConfig&&!ctx.state.steps['configure/pools'])await transaction(ctx,'configure/pools',await hub.setDepositors.populateTransaction(
    n.pools.map(p=>p.pid),prediction.staking.slice(0,n.pools.length),n.pools.map(p=>p.lockDepositor),n.pools.map(p=>p.checkpointSelector),
    n.pools.map(p=>[p.platformFeeBps,p.platformFeeRecipient]),n.pools.map(p=>p.active)));
  const pending=await hub.pendingTransactions();
  if(pending.feeChanges.length) {
    const now=BigInt((await provider.getBlock('latest')).timestamp);
    requireThat(pending.feeChanges.every(f=>f.readyAt<=now),'Fee timelock is still active; rerun after its readyAt timestamp');
    await transaction(ctx,'configure/executeFees',await hub.executeTransactions.populateTransaction());
  }
  for(const p of n.pools) {
    const staking=new Contract(prediction.staking[p.pid],artifacts.staking.abi,ctx.signer);
    if(!eq(await staking.admin(),p.stakingAdmin)&&!eq(await staking.future_admin(),p.stakingAdmin)) await transaction(ctx,'roles/staking/'+p.pid,await staking.commit_transfer_ownership.populateTransaction(p.stakingAdmin));
  }
  if(!eq(await hub.owner(),n.owner)&&!eq((await hub.pendingTransactions()).pendingOwner,n.owner)) await transaction(ctx,'roles/hub',await hub.transferOwnership.populateTransaction(n.owner));
  return verifyStack(ctx,artifacts,prediction);
}


async function deployBeefyPair(ctx,artifacts,prediction,p,deploy) {
  const b=p.beefy;if(!b.enabled)return;
  const pid=p.pid, stakingAddress=prediction.staking[pid];
  const strategyAddress=prediction.strategy[pid],vaultAddress=prediction.vault[pid];
  const strategy=await deploy('beefy/strategy/'+pid,artifacts.strategy,[stakingAddress,
    [p.asset,vaultAddress,strategySwapper(p,prediction),b.strategyAdminFeeReceiver],
    [b.totalPerformanceFeeBps,b.callShareBps,b.adminShareBps],b.lockDurationSeconds,BigInt(b.minWantOutputBaseUnits)],strategyAddress);
  requireThat(eq(await strategy.staking(),stakingAddress)&&eq(await strategy.want(),p.asset)&&eq(await strategy.vault(),vaultAddress)&&eq(await strategy.swapper(),strategySwapper(p,prediction)),
    'Strategy deployment configuration mismatch: PID '+pid);
  const vault=await deploy('beefy/vault/'+pid,artifacts.vault,[strategyAddress,b.shareName,b.shareSymbol,b.withdrawalFeeBps,b.vaultAdminFeeReceiver],vaultAddress);
  requireThat(eq(await vault.strategy(),strategyAddress)&&eq(await vault.want(),p.asset),
    'Vault/strategy deployment mismatch: PID '+pid);
}
async function verifyBeefyPair(ctx,artifacts,prediction,p) {
  const b=p.beefy;if(!b.enabled)return;
  const pid=p.pid,provider=ctx.provider;
  const strategyAddress=prediction.strategy[pid],vaultAddress=prediction.vault[pid];
  requireThat(codeMatches(artifacts.strategy,await provider.getCode(strategyAddress)), 'Beefy strategy runtime mismatch: PID '+pid);
  requireThat(codeMatches(artifacts.vault,await provider.getCode(vaultAddress)), 'Beefy vault runtime mismatch: PID '+pid);
  const s=new Contract(strategyAddress,artifacts.strategy.abi,provider);
  const v=new Contract(vaultAddress,artifacts.vault.abi,provider);
  requireThat(eq(await s.staking(),prediction.staking[pid])&&eq(await s.want(),p.asset)&&eq(await s.vault(),vaultAddress)&&eq(await s.swapper(),strategySwapper(p,prediction))&&
    eq(await s.adminFeeReceiverAddress(),b.strategyAdminFeeReceiver)&&Number(await s.totalPerformanceFeeBps())===b.totalPerformanceFeeBps&&
    Number(await s.callShareBps())===b.callShareBps&&Number(await s.adminShareBps())===b.adminShareBps&&
    BigInt(await s.lockDuration())===BigInt(b.lockDurationSeconds)&&BigInt(await s.minWantOutput())===BigInt(b.minWantOutputBaseUnits),
    'Beefy strategy parameters mismatch: PID '+pid);
  requireThat(eq(await v.strategy(),strategyAddress)&&eq(await v.want(),p.asset)&&eq(await v.adminFeeReceiver(),b.vaultAdminFeeReceiver)&&
    Number(await v.withdrawalFeeBps())===b.withdrawalFeeBps&&await v.name()===b.shareName&&await v.symbol()===b.shareSymbol,
    'Beefy vault parameters mismatch: PID '+pid);
  console.log(ctx.name+': PID '+pid+' staking '+prediction.staking[pid]+' strategy '+strategyAddress+' vault '+vaultAddress);
}

export async function verifyStack(ctx,artifacts,prediction) {
  const {provider,network:n}=ctx;const pendingRoles=[];
  const helperArtifact=n.claimMode==='urd'?artifacts.helperFraxtal:artifacts.helper;
  for(const [artifact,a,label]of [[artifacts.factory,prediction.factory,'factory'],[helperArtifact,prediction.helper,'helper'],[artifacts.hub,prediction.hub,'hub']])requireThat(codeMatches(artifact,await provider.getCode(a)),'Runtime mismatch: '+label);
  const hub=new Contract(prediction.hub,artifacts.hub.abi,provider),helper=new Contract(prediction.helper,helperArtifact.abi,provider);
  requireThat(eq(await helper.boostHub(),prediction.hub)&&eq(n.claimMode==='urd'?await helper.urd():await helper.merkleStash(),n.rewardDistributor)&&eq(await helper.configurator(),ctx.deployer),'Helper configuration mismatch');
  const converterReport=await verifyConverter(ctx,artifacts,prediction);
  const system=await hub.systemInfo();requireThat(eq(system.vlBoost,n.vlBoost)&&eq(system.stakeDaoClaimExecutor,prediction.helper)&&Number(system.poolCount)===n.pools.length,'Hub system configuration mismatch');
  if(!eq(await hub.owner(),n.owner)) {
    requireThat(eq((await hub.pendingTransactions()).pendingOwner,n.owner),'Final Hub owner is not queued');
    pendingRoles.push({address:prediction.hub,role:'Hub owner',receiver:n.owner,data:hub.interface.encodeFunctionData('executeTransactions')});
  }
  for(const p of n.pools) {
    const q=await hub.poolInfo(p.pid);requireThat(eq(q.asset,p.asset)&&eq(q.gauge,p.gauge)&&eq(q.depositor,prediction.staking[p.pid])&&q.depositorLocked===p.lockDepositor&&q.active===p.active&&q.feeConfigSet&&Number(q.platformFeeBps)===p.platformFeeBps&&eq(q.platformFeeRecipient,p.platformFeeRecipient)&&eq(q.checkpointSelector,p.checkpointSelector),'Hub pool configuration mismatch: '+p.pid);
    requireThat(json(q.rewardTokens.map(a=>a.toLowerCase()))===json(p.hubRewardTokens.map(a=>a.toLowerCase())),'Hub reward token mismatch');
    requireThat(codeMatches(artifacts.staking,await provider.getCode(prediction.staking[p.pid])),'Staking runtime mismatch: '+p.pid);
    const s=new Contract(prediction.staking[p.pid],artifacts.staking.abi,provider);
    await verifyBeefyPair(ctx,artifacts,prediction,p);
    requireThat(eq(await s.lp_token(),p.asset)&&eq(await s.boost_hub(),prediction.hub)&&Number(await s.pid())===p.pid&&eq(await s.keeper(),p.keeper)&&eq(await s.fee_receiver(),p.stakingFeeReceiver)&&Number(await s.reward_smoothing_units())===p.rewardSmoothingUnits,'Staking configuration mismatch: '+p.pid);
    const expected=[p.asset,...p.hubRewardTokens.filter(t=>!eq(t,p.asset)),...p.externalRewardTokens];
    requireThat(Number(await s.reward_count())===expected.length,'Staking reward count mismatch');
    for(let i=0;i<expected.length;i++) {
      const token=await s.reward_tokens(i);requireThat(eq(token,expected[i]),'Staking reward order mismatch');
      requireThat(await s.reward_from_boosthub(token)===p.hubRewardTokens.some(t=>eq(t,token)),'Staking reward source mismatch');
      requireThat(await s.reward_disabled(token)===p.disabledRewardTokens.some(t=>eq(t,token)),'Staking disabled-reward mismatch');
    }
    if(!eq(await s.admin(),p.stakingAdmin)) {
      requireThat(eq(await s.future_admin(),p.stakingAdmin),'Final staking admin is not queued');
      pendingRoles.push({address:prediction.staking[p.pid],role:'Staking admin',receiver:p.stakingAdmin,data:s.interface.encodeFunctionData('accept_transfer_ownership')});
    }
  }
  ctx.state.converterReport=converterReport;
  ctx.state.pendingRoles=pendingRoles;ctx.state.status=pendingRoles.length?'ROLE_ACCEPTANCE_REQUIRED':(converterReport.previewFailures.length ? 'CONVERTER_ROUTES_UNVERIFIED':'CONFIGURED_AND_VERIFIED');ctx.state.addresses=prediction;ctx.save();
  console.log(ctx.name+': '+ctx.state.status);return ctx.state;
}

async function acceptRoles(ctx,artifacts,prediction) {
  const hub=new Contract(prediction.hub,artifacts.hub.abi,ctx.signer);
  if(!eq(await hub.owner(),ctx.network.owner)&&eq(ctx.signer.address,ctx.network.owner)) await transaction(ctx,'accept/hub',await hub.executeTransactions.populateTransaction());
  for(const p of ctx.network.pools)if(eq(ctx.signer.address,p.stakingAdmin)) {
    const s=new Contract(prediction.staking[p.pid],artifacts.staking.abi,ctx.signer);
    if(!eq(await s.admin(),p.stakingAdmin))await transaction(ctx,'accept/staking/'+p.pid,await s.accept_transfer_ownership.populateTransaction());
  }
  return verifyStack(ctx,artifacts,prediction);
}

export async function main(payload) {
  const root=path.resolve(payload.packageRoot||path.join(path.dirname(payload.configPath),'..'));
  const artifacts=loadArtifacts(root);
  const config=parseJson(fs.readFileSync(payload.configPath,'utf8'));
  if(payload.deployerAddress)config.deployer=payload.deployerAddress;
  if(payload.deploymentId)config.deploymentId=payload.deploymentId;
  for(const [name,overrides]of Object.entries(payload.dependencyOverrides||{})) Object.assign(config.chains[name],overrides);
  validateConfig(config);
  const prediction=predictAddresses(artifacts,config.deployer,config.deploymentId,Math.max(...Object.values(config.chains).map(n=>n.pools.length)));
  console.log('Predicted chain-local converter address (deployed on both chains): '+prediction.converter);
  console.log('New BoostHub: '+prediction.hub+'\nClaim helper: '+prediction.helper+'\nDeployment factory: '+prediction.factory);
  for(const chain of Object.values(config.chains))for(const p of chain.pools)if(p.beefy.enabled)console.log('PID '+p.pid+': predicted strategy '+prediction.strategy[p.pid]+' vault '+prediction.vault[p.pid]);
  const mode=payload.mode||'Check';requireThat(['Check','Deploy','Verify','AcceptRoles'].includes(mode),'Unknown mode');
  let key=payload.privateKey,signer;
  if(['Deploy','AcceptRoles'].includes(mode)) {
    requireThat(typeof key==='string'&&/^(0x)?[0-9a-fA-F]{64}$/.test(key),'A valid private key is required');
    try{signer=new Wallet(key.startsWith('0x')?key:'0x'+key);}catch{throw new Error('Invalid signing key');}
    if(mode==='Deploy')requireThat(eq(signer.address,config.deployer),'Signing account does not match configured deployer');
  }
  delete payload.privateKey;key=undefined;
  const selection=payload.chain==='Both'?['ethereum','fraxtal']:[(payload.chain||'ethereum').toLowerCase()];
  requireThat(selection.every(n=>n in config.chains),'Invalid chain selection');
  const contexts=[];
  const providers=[];
  try {
  for(const name of selection) {
    const network=config.chains[name],url=payload.rpcUrls?.[name]||network.rpcUrl;
    requireThat(/^https?:\/\//.test(url),'RPC URL is required for '+name);
    const request=new FetchRequest(url);request.timeout=30000;
    const provider=new JsonRpcProvider(request,network.chainId,{staticNetwork:true,batchMaxCount:1,cacheTimeout:-1});provider.pollingInterval=1000;
    providers.push(provider);
    await preflight(provider,network,prediction);
    const stateDir=path.resolve(payload.stateDirectory);fs.mkdirSync(stateDir,{recursive:true});
    const statePath=path.join(stateDir,'deployment_'+name+'_v1.json');
    const configDigest=sha256(json({deployer:config.deployer,deploymentId:config.deploymentId,network:{...network,rpcUrl:undefined},artifacts:Object.fromEntries(Object.entries(artifacts).map(([k,a])=>[k,sha256(json(a))]))}));
    const state=fs.existsSync(statePath)?parseJson(fs.readFileSync(statePath,'utf8')):{version:'v1',chainId:network.chainId,configDigest,steps:{},status:'INITIALIZED'};
    requireThat(state.configDigest===configDigest,'State belongs to different configuration/artifacts; restore its exact inputs');
    const ctx={name,provider,network,state,deployer:config.deployer,deploymentId:config.deploymentId,
      signer:signer?.connect(provider),confirmations:network.confirmations||1,timeoutMs:600000,
      save:()=>{const temp=statePath+'.tmp';fs.writeFileSync(temp,json(state));fs.renameSync(temp,statePath);}};
    contexts.push(ctx);
  }
    for(const ctx of contexts) {
      if(mode==='Check'){console.log(ctx.name+': preflight passed; '+ctx.network.pools.length+' pools');continue;}
      if(mode==='Deploy')await deployAndConfigure(ctx,artifacts,prediction);
      if(mode==='Verify')await verifyStack(ctx,artifacts,prediction);
      if(mode==='AcceptRoles')await acceptRoles(ctx,artifacts,prediction);
    }
  }finally{for(const provider of providers)provider.destroy();}
}

if(process.env.BOOSTHUB_EXECUTE==='1') {
  let payload;
  try { payload=parseJson(fs.readFileSync(0,'utf8')); }
  catch { console.error('Stopped: invalid input JSON; rerun through the PowerShell wrapper.');process.exitCode=1; }
  if(payload)main(payload).catch(e=>{
    const message=String(e.shortMessage||e.reason||e.message||e.code||'Unknown error').replace(/https?:\/\/[^\s"']+/g,'[RPC endpoint]');
    console.error('Stopped: '+message);process.exitCode=1;
  });
}
