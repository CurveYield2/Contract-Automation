// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;
import {Math} from "@openzeppelin/contracts/utils/math/Math.sol";
interface IBHVT3Pool {
    function observe(uint32[] calldata secondsAgos) external view returns(int56[] memory,uint160[] memory);
}
// Immutable stateless TWAP math helper deployed automatically from both converter constructors.
contract BoostHubV3TwapQuote {
    uint32 public constant MIN_TWAP_SECONDS = 1800;
    uint32 public constant MAX_TWAP_SECONDS = 86400;
    error InvalidTwapWindow();
    error RouteOracleUnavailable(address pool);
    function quote(address pool,address tokenIn,address tokenOut,uint32 windowSeconds,uint256 amountIn) external view returns (uint256) {
        if (windowSeconds<MIN_TWAP_SECONDS || windowSeconds>MAX_TWAP_SECONDS) revert InvalidTwapWindow();
        uint32[] memory secondsAgos=new uint32[](2);
        secondsAgos[0]=windowSeconds;
        // second = now; v3 observe never substitutes spot balances
        (int56[] memory cumulative,)=IBHVT3Pool(pool).observe(secondsAgos);
        if (cumulative.length!=2) revert RouteOracleUnavailable(pool);
        int56 delta=cumulative[1]-cumulative[0];
        int56 window=int56(uint56(windowSeconds));
        int256 tickValue=int256(delta/window);
        if (delta<0 && delta%window!=0) tickValue--;
        if (tickValue < -887272 || tickValue > 887272) revert RouteOracleUnavailable(pool);
        int24 meanTick=int24(tickValue);
        uint160 sqrtX96=BHTickMath.sqrtRatioAtTick(meanTick);
        if (sqrtX96<=type(uint128).max) {
            uint256 ratio=uint256(sqrtX96)*uint256(sqrtX96);
            return tokenIn<tokenOut?Math.mulDiv(amountIn,ratio,1<<192):Math.mulDiv(amountIn,1<<192,ratio);
        }
        uint256 ratio128=Math.mulDiv(sqrtX96,sqrtX96,1<<64);
        return tokenIn<tokenOut?Math.mulDiv(amountIn,ratio128,1<<128):Math.mulDiv(amountIn,1<<128,ratio128);
    }

}
/// @notice Fractional bit math used only to turn a v3 pool's historic mean tick into an output quote.
/// @dev Adapted arithmetic from Uniswap v3 TickMath, deployed on v2/v3 *execution* pools' own observations.
library BHTickMath {
    error TickOutOfBounds();
    function sqrtRatioAtTick(int24 tick) internal pure returns (uint160 sqrtPriceX96) {
        int256 signedTick = int256(tick);
        uint256 absTick = uint256(signedTick < 0 ? -signedTick : signedTick);
        if (absTick > 887272) revert TickOutOfBounds();
        uint256 ratio = absTick & 0x1 != 0 ? 0xfffcb933bd6fad37aa2d162d1a594001 : 0x100000000000000000000000000000000;
        if (absTick & 0x2 != 0) ratio = (ratio * 0xfff97272373d413259a46990580e213a) >> 128;
        if (absTick & 0x4 != 0) ratio = (ratio * 0xfff2e50f5f656932ef12357cf3c7fdcc) >> 128;
        if (absTick & 0x8 != 0) ratio = (ratio * 0xffe5caca7e10e4e61c3624eaa0941cd0) >> 128;
        if (absTick & 0x10 != 0) ratio = (ratio * 0xffcb9843d60f6159c9db58835c926644) >> 128;
        if (absTick & 0x20 != 0) ratio = (ratio * 0xff973b41fa98c081472e6896dfb254c0) >> 128;
        if (absTick & 0x40 != 0) ratio = (ratio * 0xff2ea16466c96a3843ec78b326b52861) >> 128;
        if (absTick & 0x80 != 0) ratio = (ratio * 0xfe5dee046a99a2a811c461f1969c3053) >> 128;
        if (absTick & 0x100 != 0) ratio = (ratio * 0xfcbe86c7900a88aedcffc83b479aa3a4) >> 128;
        if (absTick & 0x200 != 0) ratio = (ratio * 0xf987a7253ac413176f2b074cf7815e54) >> 128;
        if (absTick & 0x400 != 0) ratio = (ratio * 0xf3392b0822b70005940c7a398e4b70f3) >> 128;
        if (absTick & 0x800 != 0) ratio = (ratio * 0xe7159475a2c29b7443b29c7fa6e889d9) >> 128;
        if (absTick & 0x1000 != 0) ratio = (ratio * 0xd097f3bdfd2022b8845ad8f792aa5825) >> 128;
        if (absTick & 0x2000 != 0) ratio = (ratio * 0xa9f746462d870fdf8a65dc1f90e061e5) >> 128;
        if (absTick & 0x4000 != 0) ratio = (ratio * 0x70d869a156d2a1b890bb3df62baf32f7) >> 128;
        if (absTick & 0x8000 != 0) ratio = (ratio * 0x31be135f97d08fd981231505542fcfa6) >> 128;
        if (absTick & 0x10000 != 0) ratio = (ratio * 0x9aa508b5b7a84e1c677de54f3e99bc9) >> 128;
        if (absTick & 0x20000 != 0) ratio = (ratio * 0x5d6af8dedb81196699c329225ee604) >> 128;
        if (absTick & 0x40000 != 0) ratio = (ratio * 0x2216e584f5fa1ea926041bedfe98) >> 128;
        if (absTick & 0x80000 != 0) ratio = (ratio * 0x48a170391f7dc42444e8fa2) >> 128;
        if (tick > 0) ratio = type(uint256).max / ratio;
        sqrtPriceX96 = uint160((ratio >> 32) + (ratio % (1 << 32) == 0 ? 0 : 1));
    }
}

