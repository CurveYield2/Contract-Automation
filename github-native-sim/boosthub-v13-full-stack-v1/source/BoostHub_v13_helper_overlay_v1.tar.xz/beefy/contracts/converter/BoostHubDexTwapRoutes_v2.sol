// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {IERC20Metadata} from "@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {Math} from "@openzeppelin/contracts/utils/math/Math.sol";
import {BoostHubV3TwapQuote} from "./BoostHubV3TwapQuote_v1.sol";

interface IBHTV2Pair {
    function token0() external view returns (address);
    function token1() external view returns (address);
    function factory() external view returns (address);
    function getReserves() external view returns (uint112 reserve0,uint112 reserve1,uint32 timestamp);
    function price0CumulativeLast() external view returns (uint256);
    function price1CumulativeLast() external view returns (uint256);
}
interface IBHTV2Router {
    function factory() external view returns (address);
    function swapExactTokensForTokens(uint256 amountIn,uint256 minOut,address[] calldata path,address to,uint256 deadline)
        external returns (uint256[] memory amounts);
}
interface IBHTV3Pool {
    function token0() external view returns (address);
    function token1() external view returns (address);
    function factory() external view returns (address);
    function fee() external view returns (uint24);
    function observe(uint32[] calldata secondsAgos)
        external view returns (int56[] memory tickCumulatives,uint160[] memory secondsPerLiquidityCumulativeX128s);
}
interface IBHTV3Router {
    function factory() external view returns (address);
    struct ExactInputSingleParams {
        address tokenIn;
        address tokenOut;
        uint24 fee;
        address recipient;
        uint256 deadline;
        uint256 amountIn;
        uint256 amountOutMinimum;
        uint160 sqrtPriceLimitX96;
    }
    function exactInputSingle(ExactInputSingleParams calldata params) external payable returns (uint256 amountOut);
}
interface IBHTCurveStable {
    function exchange(int128 i,int128 j,uint256 dx,uint256 minDy) external returns (uint256);
}
interface IBHTCurveCrypto {
    function exchange(uint256 i,uint256 j,uint256 dx,uint256 minDy) external returns (uint256);
}

/// @dev Extra routes use their *executing pool* as oracle, never a separate price feed.
///      Curve: EMA; UniV3: historical tick cumulative; UniV2: paired cumulative-price snapshots.
///      This engine is inherited by both existing converters and does not change their default routes.
abstract contract BoostHubDexTwapRoutes {
    BoostHubV3TwapQuote public immutable v3TwapHelper;
    constructor() { v3TwapHelper = new BoostHubV3TwapQuote(); }
    using SafeERC20 for IERC20;
    uint256 internal constant _DENOM = 10_000;
    uint256 internal constant _Q112 = 2 ** 112;
    uint32 public constant MIN_TWAP_SECONDS = 1800;
    uint32 public constant MAX_TWAP_SECONDS = 86400;
    uint32 public constant MAX_V2_AGE_SECONDS = 3600;
    uint256 public constant MAX_ROUTE_HOPS = 4;
    enum Source { CurveEMA, UniV2TWAP, UniV3TWAP }
    struct Hop {
        Source source;
        address pool;
        address router;     // For Uniswap V2/V3: must share pool's actual factory
        address tokenIn;
        address tokenOut;
        uint24 fee;         // UniV3 pool fee (exact); 0 otherwise
        uint32 window;      // Historical seconds, v3 only; min 1800
        uint8 indexIn;      // Curve coins indices only
        uint8 indexOut;
        uint8 curveSwapType; // 1=int128 stable, 3=uint256 crypto
    }
    struct V2Snapshot {
        uint256 cumulative0;
        uint256 cumulative1;
        uint256 average0;
        uint256 average1;
        uint64 timestamp;
        uint64 lastUpdated;
    }
    mapping(address => V2Snapshot) private _v2Snapshots;
    mapping(bytes32 => Hop[]) private _dexRoutes;
    mapping(bytes32 => bool) internal _dexRegistered;
    error NoDexRoute();
    error InvalidDexHop(uint256 hop);
    error PairMismatch(address pool);
    error RouteOracleUnavailable(address pool);
    error TwapNotReady(address pool);
    error TwapStale(address pool);
    error InvalidTwapWindow();
    error DexQuoteZero();
    error DexRouteDeteriorated(uint256 oldAmount, uint256 newAmount);
    error DexTooManyHops();
    error DexSlippage();
    event V2OraclePrimed(address indexed pool,uint256 timestamp);
    event V2OracleUpdated(address indexed pool,uint256 duration,uint256 average0,uint256 average1);
    event DexRouteConfigured(address indexed tokenIn,address indexed tokenOut,uint256 numberOfHops);

    function dexHops(address tokenIn,address tokenOut) external view returns (Hop[] memory) {
        bytes32 key=keccak256(abi.encode(tokenIn,tokenOut));
        if (!_dexRegistered[key]) revert NoDexRoute();
        return _dexRoutes[key];
    }
    function v2OracleState(address pool) external view returns (V2Snapshot memory) {return _v2Snapshots[pool];}

    function _v2Cumulatives(address pool) internal view returns (uint256 p0,uint256 p1) {
        IBHTV2Pair pair=IBHTV2Pair(pool);
        p0=pair.price0CumulativeLast();p1=pair.price1CumulativeLast();
        (uint112 reserve0,uint112 reserve1,uint32 blockTimestampLast)=pair.getReserves();
        if (reserve0==0 || reserve1==0) revert RouteOracleUnavailable(pool);
        uint32 elapsed;
        unchecked {elapsed=uint32(block.timestamp)-blockTimestampLast;}
        if (elapsed!=0) {
            unchecked {
                p0 += ((_Q112 * uint256(reserve1))/uint256(reserve0))*elapsed;
                p1 += ((_Q112 * uint256(reserve0))/uint256(reserve1))*elapsed;
            }
        }
    }
    /// @notice Permissionless two-stage observation. First call primes, second (>= 30min later) stores TWAP.
    /// @dev A recent snapshot is mandatory at swap time. No spot-price fallback or one-block average.
    function updateV2Oracle(address pool) external {
        if (pool.code.length==0) revert RouteOracleUnavailable(pool);
        IBHTV2Pair(pool).token0();IBHTV2Pair(pool).token1();
        (uint256 p0,uint256 p1)=_v2Cumulatives(pool);
        V2Snapshot storage snap=_v2Snapshots[pool];
        if (snap.timestamp==0) {
            snap.cumulative0=p0;snap.cumulative1=p1;snap.timestamp=uint64(block.timestamp);
            emit V2OraclePrimed(pool,block.timestamp);
            return;
        }
        uint256 elapsed=block.timestamp-uint256(snap.timestamp);
        if (elapsed<MIN_TWAP_SECONDS || elapsed>MAX_TWAP_SECONDS) {
            if (elapsed>MAX_TWAP_SECONDS) {
                // Reset expired baseline; a fresh observation window must pass again.
                snap.cumulative0=p0;snap.cumulative1=p1;snap.timestamp=uint64(block.timestamp);
                snap.average0=0;snap.average1=0;snap.lastUpdated=0;
                emit V2OraclePrimed(pool,block.timestamp);
                return;
            }
            revert TwapNotReady(pool);
        }
        uint256 avg0;uint256 avg1;
        unchecked {avg0=(p0-snap.cumulative0)/elapsed;avg1=(p1-snap.cumulative1)/elapsed;}
        if (avg0==0 || avg1==0) revert RouteOracleUnavailable(pool);
        snap.average0=avg0;snap.average1=avg1;
        snap.cumulative0=p0;snap.cumulative1=p1;
        snap.timestamp=uint64(block.timestamp);snap.lastUpdated=uint64(block.timestamp);
        emit V2OracleUpdated(pool,elapsed,avg0,avg1);
    }
    function _v2Quote(Hop memory hop,uint256 amountIn) internal view returns (uint256) {
        V2Snapshot storage snap=_v2Snapshots[hop.pool];
        if (snap.lastUpdated==0) revert TwapNotReady(hop.pool);
        if (block.timestamp-uint256(snap.lastUpdated)>MAX_V2_AGE_SECONDS) revert TwapStale(hop.pool);
        uint256 price=hop.tokenIn==IBHTV2Pair(hop.pool).token0()?snap.average0:snap.average1;
        return Math.mulDiv(amountIn,price,_Q112);
    }
    function _v3Quote(Hop memory hop,uint256 amountIn) internal view returns (uint256) {
        return v3TwapHelper.quote(hop.pool,hop.tokenIn,hop.tokenOut,hop.window,amountIn);
    }
    function _curveOracle(address pool,uint8 coinIndex) internal view returns (uint256 price) {
        if (coinIndex==0) return 1e18;
        bool ok; bytes memory result;
        if (coinIndex==1) {
            (ok,result)=pool.staticcall(abi.encodeWithSignature("price_oracle()"));
            if (!ok || result.length!=32) (ok,result)=pool.staticcall(abi.encodeWithSignature("price_oracle(uint256)",uint256(0)));
        } else {
            (ok,result)=pool.staticcall(abi.encodeWithSignature("price_oracle(uint256)",uint256(coinIndex-1)));
        }
        if (!ok || result.length!=32) revert RouteOracleUnavailable(pool);
        price=abi.decode(result,(uint256));
        if (price==0) revert RouteOracleUnavailable(pool);
    }
    function _curveQuote(Hop memory hop,uint256 amountIn) internal view returns (uint256) {
        uint256 priceIn=_curveOracle(hop.pool,hop.indexIn);
        uint256 priceOut=_curveOracle(hop.pool,hop.indexOut);
        uint8 decIn=IERC20Metadata(hop.tokenIn).decimals();
        uint8 decOut=IERC20Metadata(hop.tokenOut).decimals();
        if (decIn>77 || decOut>77) revert InvalidDexHop(0);
        uint256 priceValue=Math.mulDiv(amountIn,priceIn,10**uint256(decIn));
        return Math.mulDiv(priceValue,10**uint256(decOut),priceOut);
    }
    function _hopQuote(Hop memory hop,uint256 amountIn) internal view returns (uint256) {
        if (hop.source==Source.CurveEMA) return _curveQuote(hop,amountIn);
        if (hop.source==Source.UniV2TWAP) return _v2Quote(hop,amountIn);
        return _v3Quote(hop,amountIn);
    }
    function _extraQuote(bytes32 key,uint256 amountIn) internal view returns (uint256 output) {
        if (!_dexRegistered[key]) revert NoDexRoute();
        output=amountIn;
        Hop[] storage hops=_dexRoutes[key];
        for (uint256 i;i<hops.length;++i) {
            output=_hopQuote(hops[i],output);
            if (output==0) revert DexQuoteZero();
        }
    }
    function _validateHop(Hop memory h,uint256 i) internal view {
        if (h.pool.code.length==0 || h.tokenIn==address(0) || h.tokenOut==address(0) || h.tokenIn==h.tokenOut) revert InvalidDexHop(i);
        if (h.tokenIn.code.length==0 || h.tokenOut.code.length==0) revert InvalidDexHop(i);
        if (h.source==Source.CurveEMA) {
            if (h.router!=address(0) || h.fee!=0 || h.window!=0 || h.indexIn>3 || h.indexOut>3 || h.indexIn==h.indexOut || (h.curveSwapType!=1 && h.curveSwapType!=3)) revert InvalidDexHop(i);
            // Check Curve token indices against the *execution* pool; no unrelated oracles.
            address coinIn=_curveCoin(h.pool,h.indexIn);
            address coinOut=_curveCoin(h.pool,h.indexOut);
            if (coinIn!=h.tokenIn || coinOut!=h.tokenOut) revert PairMismatch(h.pool);
        } else if (h.source==Source.UniV2TWAP) {
            if (h.router.code.length==0 || h.fee!=0 || h.window!=0 || h.curveSwapType!=0 || h.indexIn!=0 || h.indexOut!=0) revert InvalidDexHop(i);
            IBHTV2Pair pair=IBHTV2Pair(h.pool);
            address t0=pair.token0();address t1=pair.token1();
            if (!((t0==h.tokenIn && t1==h.tokenOut)||(t1==h.tokenIn && t0==h.tokenOut))) revert PairMismatch(h.pool);
            if (IBHTV2Router(h.router).factory()!=pair.factory()) revert PairMismatch(h.pool);
        } else {
            if (h.router.code.length==0 || h.curveSwapType!=0 || h.indexIn!=0 || h.indexOut!=0 || h.fee==0 || h.window<MIN_TWAP_SECONDS || h.window>MAX_TWAP_SECONDS) revert InvalidDexHop(i);
            IBHTV3Pool pair=IBHTV3Pool(h.pool);
            address t0=pair.token0();address t1=pair.token1();
            if (!((t0==h.tokenIn && t1==h.tokenOut)||(t1==h.tokenIn && t0==h.tokenOut))) revert PairMismatch(h.pool);
            if (pair.fee()!=h.fee || IBHTV3Router(h.router).factory()!=pair.factory()) revert PairMismatch(h.pool);
        }
    }
    function _curveCoin(address pool,uint8 index) internal view returns (address coin) {
        (bool ok,bytes memory result)=pool.staticcall(abi.encodeWithSignature("coins(uint256)",uint256(index)));
        if (!ok || result.length!=32) (ok,result)=pool.staticcall(abi.encodeWithSignature("coins(int128)",int128(uint128(index))));
        if (!ok || result.length!=32) revert RouteOracleUnavailable(pool);
        coin=abi.decode(result,(address));
    }
    function _configureExtra(address tokenIn,address tokenOut,Hop[] calldata hops,bool replacing) internal {
        if (hops.length==0 || hops.length>MAX_ROUTE_HOPS) revert DexTooManyHops();
        bytes32 key=keccak256(abi.encode(tokenIn,tokenOut));
        if (replacing!=_dexRegistered[key]) revert NoDexRoute();
        address expectedIn=tokenIn;
        for (uint256 i;i<hops.length;i++) {
            Hop memory h=hops[i];
            if (h.tokenIn!=expectedIn) revert InvalidDexHop(i);
            _validateHop(h,i);
            expectedIn=h.tokenOut;
        }
        if (expectedIn!=tokenOut || tokenIn==tokenOut) revert InvalidDexHop(hops.length);
        uint8 decimals_=IERC20Metadata(tokenIn).decimals();
        if (decimals_<4 || decimals_>77) revert InvalidDexHop(0);
        uint256 probe=10**(uint256(decimals_)-4);
        uint256 prev=replacing?_extraQuote(key,probe):0;
        delete _dexRoutes[key];
        for (uint256 i;i<hops.length;i++) _dexRoutes[key].push(hops[i]);
        _dexRegistered[key]=true;
        uint256 next=_extraQuote(key,probe);
        if (next==0) revert DexQuoteZero();
        if (replacing && next<Math.mulDiv(prev,9800,_DENOM,Math.Rounding.Ceil)) revert DexRouteDeteriorated(prev,next);
        emit DexRouteConfigured(tokenIn,tokenOut,hops.length);
    }
    function _executeExtra(bytes32 key,uint256 amountIn,uint256 minOut,address recipient) internal returns (uint256 result) {
        if (!_dexRegistered[key]) revert NoDexRoute();
        Hop[] storage hops=_dexRoutes[key];
        IERC20(hops[0].tokenIn).safeTransferFrom(msg.sender,address(this),amountIn);
        uint256 current=amountIn;
        for (uint256 i;i<hops.length;i++) {
            Hop memory h=hops[i];
            IERC20 token=IERC20(h.tokenIn);
            address spender=h.source==Source.CurveEMA?h.pool:h.router;
            token.forceApprove(spender,current);
            uint256 beforeOut=IERC20(h.tokenOut).balanceOf(address(this));
            if (h.source==Source.CurveEMA) {
                if (h.curveSwapType==1) IBHTCurveStable(h.pool).exchange(int128(uint128(h.indexIn)),int128(uint128(h.indexOut)),current,0);
                else IBHTCurveCrypto(h.pool).exchange(uint256(h.indexIn),uint256(h.indexOut),current,0);
            } else if (h.source==Source.UniV2TWAP) {
                address[] memory path=new address[](2);path[0]=h.tokenIn;path[1]=h.tokenOut;
                IBHTV2Router(h.router).swapExactTokensForTokens(current,0,path,address(this),block.timestamp);
            } else {
                IBHTV3Router(h.router).exactInputSingle(IBHTV3Router.ExactInputSingleParams({
                    tokenIn:h.tokenIn,tokenOut:h.tokenOut,fee:h.fee,recipient:address(this),deadline:block.timestamp,
                    amountIn:current,amountOutMinimum:0,sqrtPriceLimitX96:0
                }));
            }
            token.forceApprove(spender,0);
            current=IERC20(h.tokenOut).balanceOf(address(this))-beforeOut;
            if (current==0) revert DexQuoteZero();
        }
        if (current<minOut) revert DexSlippage();
        IERC20(hops[hops.length-1].tokenOut).safeTransfer(recipient,current);
        return current;
    }
}
