#!/usr/bin/env python3
"""Import five externally compiled GitHub build artifacts; never compiles or downloads anything."""
import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SPECS = {
    "staking": (ROOT / "artifacts_v1/staking_v22.json", "BoostHubStaking"),
    "strategy": (ROOT / "beefy/artifacts_v1/strategy_v1.json", "StrategyConvexBoostHubStakingV5"),
    "vault": (ROOT / "beefy/artifacts_v1/vault_v1.json", "BeefyVaultV7FixedV2"),
    "converter": (ROOT / "beefy/artifacts_v1/converter_v7.json", "BoostHubEthereumRewardConverter"),
    "fraxtalConverter": (ROOT / "beefy/artifacts_v1/fraxtal_converter_v2.json", "BoostHubFraxtalRewardConverter"),
}


def bytecode(x, label):
    if isinstance(x, dict):
        x = x.get("object") or x.get("bytecode")
    if not isinstance(x, str) or not x.startswith("0x") or len(x) < 4:
        raise ValueError(f"{label}: bytecode missing")
    if len(x) % 2 or not all(ch in "0123456789abcdefABCDEF" for ch in x[2:]):
        raise ValueError(f"{label}: bytecode is not hexadecimal")
    return x


def normalize(p, kind):
    raw = json.loads(p.read_text(encoding="utf-8-sig"))
    if "output" in raw and isinstance(raw["output"], dict):
        raw = raw["output"]
    abi = raw.get("abi")
    if not isinstance(abi, list) or not abi:
        raise ValueError(f"{p}: ABI is missing")
    creation = raw.get("bytecode")
    runtime = raw.get("deployedBytecode") or raw.get("deployed_bytecode") or raw.get("bytecode_runtime")
    refs = raw.get("immutableReferences") or raw.get("immutable_references") or {}
    if isinstance(runtime, dict):
        refs = runtime.get("immutableReferences") or refs
    norm = {
        "abi": abi,
        "bytecode": bytecode(creation, f"{p} creation"),
        "deployedBytecode": bytecode(runtime, f"{p} runtime"),
        "immutableReferences": refs,
    }
    if kind == 'staking':
        required = {'lp_token','boost_hub','pid','reward_count','deposit','withdraw','reward_tokens'}
    elif kind == 'strategy':
        required = {'staking','want','vault','swapper','adminFeeReceiverAddress','totalPerformanceFeeBps',
                    'callShareBps','adminShareBps','lockDuration','minWantOutput'}
    elif kind == 'vault':
        required = {'strategy','want','withdrawalFeeBps','adminFeeReceiver','name','symbol'}
    else:
        required = {'swap','getAmountOut','owner','slippageBps','routeCount','routeAt','isSupportedPair',
                    'addDexRoute','setDexRoute','updateV2Oracle','v2OracleState','dexHops'}
    functions = {a.get('name') for a in abi if a.get('type') == 'function'}
    missing = required - functions
    if missing:
        raise ValueError(f"{p}: incorrect contract ABI; missing functions {sorted(missing)}")
    if 'contractName' in raw and raw['contractName'] != SPECS[kind][1]:
        raise ValueError(f'{p}: unexpected contractName for {kind}')
    constructor = [a for a in abi if a.get('type') == 'constructor']
    expected_constructor_counts = {'staking': 8, 'strategy': 5, 'vault': 5, 'converter': 2, 'fraxtalConverter': 2}
    if len(constructor) != 1 or len(constructor[0].get('inputs', [])) != expected_constructor_counts[kind]:
        raise ValueError(f"{p}: unexpected {kind} constructor; use the current source")
    if kind in ('converter','fraxtalConverter'):
        cinputs = constructor[0]['inputs']
        if [x.get('type') for x in cinputs] != ['uint256','address']:
            raise ValueError('Converter needs explicit initial owner constructor')
    if kind == 'converter':
        fn = {a.get('name'): a for a in abi if a.get('type') == 'function'}
        for method in ('setRoute', 'addRoute'):
            if len(fn[method].get('inputs', [])) != 4:
                raise ValueError(f'{p}: must use the v13 multi-oracle converter ABI')
        if any(old in fn for old in ('usesDirectYb','get_exchange_multiple_amount','exchange_multiple')):
            raise ValueError(f'{p}: legacy converter ABI is not permitted in v6')
    if kind == 'staking':
        previous = ROOT/'historical_evidence_v3/staking_v21_artifact_DO_NOT_DEPLOY.json'
        if previous.exists():
            legacy = json.loads(previous.read_text())
            old = legacy.get('deployedBytecode') or legacy.get('deployed_bytecode') or legacy.get('bytecode_runtime')
            if old and bytecode(old,'old staking runtime').lower() == norm['deployedBytecode'].lower():
                raise ValueError('Historical staking v21 runtime is forbidden; compile staking v22 on GitHub')
    if isinstance(refs, dict):
        for positions in refs.values():
            if not isinstance(positions, list) or any(not isinstance(i, dict) or 'start' not in i or 'length' not in i for i in positions):
                raise ValueError(f'{p}: malformed immutable references')
    else:
        raise ValueError(f'{p}: malformed immutable references')
    return norm


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for key in SPECS: parser.add_argument(f'--{key}', type=Path, required=True, help='Compiled GitHub artifact JSON')
    args = parser.parse_args()
    built = {}
    for key, (out, contract) in SPECS.items():
        source = getattr(args, key)
        built[key] = (source, out, normalize(source, key))
    for key, (source, out, norm) in built.items():
        out.parent.mkdir(parents=True, exist_ok=True)
        encoded = (json.dumps(norm, indent=2)+'\n').encode()
        out.write_bytes(encoded)
        print(f'{key}: {out.relative_to(ROOT)} SHA-256 {hashlib.sha256(encoded).hexdigest()}')
    print('Artifacts imported; no compilation or network operations were performed.')


if __name__ == '__main__':
    main()
