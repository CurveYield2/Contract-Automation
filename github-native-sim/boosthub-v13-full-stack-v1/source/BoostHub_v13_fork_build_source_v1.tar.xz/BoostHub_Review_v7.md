# BoostHub Fraxtal Converter Review v5

User-confirmed: the Curve FXS/sdFXS pool is `0x3df1658e3E76d14eF3C4d410829EA7575bB83B9B`; no secondary pool should be installed.

- The v10 Fraxtal converter flag was off and the runner rejected Fraxtal-specific converters. Repaired in v11.
- Fraxtal contains **one** registered conversion pair (`FXS → sdFXS`), with direct 0→1 Curve exchange and pool-local EMA slippage protection. All other staking rewards remain excluded from swaps.
- Fraxtal Beefy strategy and vault are now enabled and wired to a chain-local converter deployed before either contract.
- Both chains use the same deterministic converter *slot*, but with distinct chain-appropriate bytecode and verification.
- Preserved Fraxtal 3% performance, 5/95 caller/admin fee split, 15-day profit lock, 0.1 sdFXS min and 30-bps withdrawal fee.
- Ethereum has sdCRV/sdFXN only and its three converter routes unchanged. No sdYB deployment.

Evidence limitations: previous block-42,441,678 snapshot identifies BoostHub and staking. The user confirmed Curve pool. A direct read of the live Fraxtal vault/strategy/converter chain, or pool oracle behavior, was not available through public web explorers. The implementation therefore verifies the pool's coins and oracle at preflight and fails closed instead of treating the source-chain assumptions as proven.

Deployment remains **NO GO** until GitHub-produced current artifacts are imported and an on-chain preflight and a representative end-to-end swap simulation succeed. This package is an editable deployment configuration, not evidence of successful on-chain deployment.


## v12 route correction

GitHub Actions exact-v11 dual-chain fork simulation confirmed the full Ethereum and Fraxtal vault deployment steps. Ethereum finished as CONVERTER_ROUTES_UNVERIFIED because the first wstETH -> sdFXN Curve hop used legacy stETH pool 0xDC24316b9AE028F1497c275EB9192a3Ea0f67022 without `price_oracle`. v12 replaces only that pool with oracle-capable Curve stETH-NG 0x21E27a5E5513D6e65C4f830167390997aA84843a. Full-stack CI is required before deployment. Fraxtal sdFXS was CONFIGURED_AND_VERIFIED in the v11 dual-chain fork.


### v13 Oracle Extension
Owner-controlled dynamic routes now support per-executed-hop Curve EMA / UniV2 cumulative TWAP / UniV3 observe TWAP. Prior routes unmodified. V2 has two-stage observations and freshness requirements; v3 uses historical tick accumulators. New routes are not automatically activated, and arbitrary future pool/router compatibility needs fork testing.
