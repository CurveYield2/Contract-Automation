# Beefy/BoostHub fixed-strategy stack v7 — deployment and security

## Provenance and scope

- Vault `BeefyVaultV7FixedV2.sol` is byte-for-byte unchanged from package v5; it derives from official Beefy `contracts/BIFI/vaults/BeefyVaultV7.sol` (blob `ac3e92ec59a18d728ae57575202c4f31d05a4786`).
- Strategy `StrategyConvexBoostHubStakingV5.sol` derives from official `contracts/BIFI/strategies/Curve/StrategyConvexStakingFraxtal.sol` (blob `0560055143e89fb62869dcfb140adb75435bf303`) through v5 of this package.
- Shared code `BaseAllToWantBoostHubV5.sol` derives from official `contracts/BIFI/strategies/Common/BaseAllToNativeFactoryStrat.sol` (blob `ffb79bd828a66c12fb2765298ce9241b9f917378`) through the prior package. The name reflects the changed **direct-to-want** reward routing.
- `contracts/staking/` is the original user-supplied staking stack, unchanged. No external strategy factory, owner, keeper, or pause role has been added.
- This current deployment affects only the strategy's reward conversion/fee denomination and its constructor, the corresponding deployment script, the tests, and these docs.

## Vault behavior (unchanged)

- Immutable strategy and underlying; no strategy changes or owner controls. `deposit`, `depositAll`, `withdraw`, `withdrawAll`, `earn` and ERC-20 share functions work as in v5.
- Vault withdrawal fees remain immutable: 70% retained as share backing and 30% sent to the vault's admin fee receiver on ordinary withdrawals; **100% goes to the admin on the final share withdrawal**.
- Only the existing vault admin fee receiver can nominate and, after seven days, execute a recipient change.

## Strategy reward conversion v7

1. The strategy queries accepted reward tokens dynamically from `BoostHubStaking.vy` and calls both `staking.harvest()` and `staking.claim_rewards()`.
2. Newly claimed underlying (`want`) rewards are measured as the positive change in the strategy's underlying-token balance *during the claim* and charged a performance fee in `want`; idle user principal is excluded.
3. Each non-`want` reward token with a registered converter pair—including registered wrapped-native rewards—is converted using **one direct `swapper.swap(rewardToken, want, amount)`** call. The intermediate native and deposit-token routing fields have been deleted, with no replacement.
4. Performance fees for converted rewards are computed from the **actual increase in the strategy's `want` balance** after each swap, never from the swapper's return value or a native-token intermediary.
5. Both `callShareBps` and `adminShareBps` are shares of this `want`-denominated performance fee; the caller share is rounded down, and the administrator receives the rounding remainder. The strategist share stays removed.
6. The **net of fee** remains in the strategy and is restaked through the linked BoostHub staking contract on successful harvesting, economically backing the vault's shares. Converter output **must be delivered to the strategy address**, *not directly to the vault*, because the strategy must receive and distribute the performance fee first. No additional direct vault transfer is performed.
7. `claim()` remains claim-only; it immediately charges direct-`want` claim rewards and defers conversion of any non-`want` rewards to `harvest()`.
8. `minWantOutput` remains one immutable minimum measured in underlying-token base units. Each `rewardToken → want` swap is first quoted with `getAmountOut(rewardToken, want, amount)`, and the expected output **after fees** must meet the minimum. After swap, the converter **must deliver a nonzero want balance increase to the strategy** and the **actual output after fees** must meet the minimum or the whole transaction reverts. Failed swaps are deferred one at a time. **Quotes alone are not slippage protection.**
9. If the minimum is zero, the strategy does not require the quote function, but still uses the same direct `swap(rewardToken, want, amount)` route. A newly discovered staking reward without a converter registration remains accounted for by staking and is ignored by the strategy swap list until a supported route is registered and reward sync runs.
10. `harvestOnDeposit` remains permanently `false`; `beforeDeposit()` is a no-op. The lock duration and minimum are constructor-frozen. No public setter, keeper, admin-control, pause, or strategy upgrade function has been added.

**Deployment dependency:** Only pairs actually registered on the selected `SWAPPER` are active conversion pairs. Other staking rewards are not required converter routes. The `swap()` ABI is the existing Beefy-compatible `swap(address,address,uint256)`. Receiving a deposit token other than `want` is incompatible; no second conversion will occur. The `getAmountOut` ABI is also necessary when the minimum is nonzero. Check that the swapper returns the minted/received `want` to `msg.sender` (strategy), not to the vault, for performance fees to be collectable.

**Accounting caveats:** At least one quoted reward swap with a subsequently lower realized output can revert an entire harvest (matching v5's actual-output-floor behavior). No live compilation or on-chain integration test has proven swapper compatibility, staking reward corner cases, or economic safety. In particular, the fixed-vault/strategy pair has no administrator recovery/upgrade mechanism.

## Constructor and deployment inputs

Vault: `BeefyVaultV7FixedV2(IStrategyBoostHubV1 strategy, string name, string symbol, uint256 withdrawalFeeBps, address adminFeeReceiver)`.

Strategy: `StrategyConvexBoostHubStakingV5(address staking, Addresses addresses, FeeSettings fees, uint256 lockDuration, uint256 minWantOutput)`.

`Addresses` now contains **exactly four fields:** `want`, `vault`, `swapper`, `adminFeeReceiver`. There are **no `native`, `WRAPPED_NATIVE`, `depositToken`, `DEPOSIT_TOKEN`, or equivalent setters/getters/constructor arguments**.

`FeeSettings` contains `totalPerformanceFeeBps`, `callShareBps`, `adminShareBps`. The two fee allocation shares must sum to 10,000; the fee rate is in the range 0–10,000 BPS.

| Required environment key | Description |
|---|---|
| `PRIVATE_KEY` | Transaction-signing key used by the deployment script; keep in GitHub secrets |
| `BOOSTHUB_STAKING` | Already deployed staking contract |
| `SWAPPER` | Beefy-compatible swapper with direct reward→want routes |
| `STRATEGY_ADMIN_FEE_RECEIVER` | Immutable recipient of the strategy's want-denominated performance-fee admin share |
| `PERFORMANCE_FEE_BPS` | Immutable strategy performance fee rate |
| `CALL_FEE_SHARE_BPS` | Performance-fee share for harvest caller |
| `ADMIN_FEE_SHARE_BPS` | Performance-fee share for strategy admin; caller+admin=10,000 |
| `STRATEGY_LOCK_DURATION_SECONDS` | Immutable profit-unlocking time, in seconds |
| `MIN_REWARD_OUTPUT_WANT_BASE_UNITS` | Immutable per-swap minimum **net** underlying output, in smallest units; 0 disables the minimum |
| `VAULT_WITHDRAWAL_FEE_BPS` | Immutable vault withdrawal-fee rate |
| `VAULT_ADMIN_FEE_RECEIVER` | Initial vault withdrawal-fee recipient, independently changeable after 7 days |
| `VAULT_SHARE_NAME` | Vault ERC-20 name |
| `VAULT_SHARE_SYMBOL` | Vault ERC-20 symbol |

**No `WRAPPED_NATIVE` or `DEPOSIT_TOKEN` configuration is read by the v6 script.**

### Deployment order — mandatory

The vault constructor verifies the strategy's `vault()` and `want()` values, while the strategy constructor must already know its future vault address. `scripts/DeployBoostHubPair_v6.s.sol` predicts the vault address from the deployer EOA nonce and broadcasts exactly two successive CREATE deployments:

1. Deploy `StrategyConvexBoostHubStakingV5` with the predicted vault address.
2. Deploy `BeefyVaultV7FixedV2` from the **same deployer EOA, immediately afterward**, with no intervening nonce use.
3. Validate the vault's actual address and linked strategy address. A nonce mismatch cannot be corrected by a setter; use a new deterministic deployment sequence if the first leg becomes orphaned.

Run only in a GitHub-hosted/preconfigured Foundry environment (this package does not require compiling or downloading dependencies locally):

```bash
forge script scripts/DeployBoostHubPair_v6.s.sol:DeployBoostHubPairV6 --rpc-url "$RPC_URL" --broadcast
```

Configure direct reward-token→underlying swap routes before calling `harvest`. Users must approve the **vault** to deposit their tokens.

## Verification

`checks/static_invariants_v8.py` verifies removed configurations, direct swap directions and balance-delta performance-fee accounting, original Vyper selectors, immutable-constructor and vault invariants, randomized arithmetic/threshold models and unchanged vault/staking bytes. This does **not** compile Solidity/Vyper, deploy, or exercise the real swapper. No dependencies were downloaded or installed.

Before mainnet deployment, run GitHub-hosted compilation and integration tests with the actual `SWAPPER` and staking contracts, including: mixed direct-want and non-want rewards, fee-on-transfer/deflationary tokens, 0-fee and 100%-fee edges, absent routes and quote failures, min-net-output edges and slippage, disabled/new rewards, no-principal-fee check, 7-day vault fee-receiver timelock, final-holder withdrawal, and deployment nonce/address checks.


## Multi-oracle new conversion routes (v13)

The existing onchain routes and economics remain intact. For **new** registered routes the owner uses `addDexRoute(tokenIn,tokenOut, Hop[] hops)` or `setDexRoute(...)`. A hop may use: Curve `price_oracle` EMA and `exchange`; Uniswap v3 `observe([secondsAgo,0])` tick-cumulative TWAP and `SwapRouter.exactInputSingle`; or Uniswap v2 cumulative prices and a V2 router. The pool used for pricing **must be the execution pool** and Uniswap router factory must match pool factory. Default limits are 4 hops, 1% configured slippage, maximum 4% permitted slippage, and TWAP windows 30 minutes through 24 hours. v2 requires a permissionless `updateV2Oracle(pool)` at two different block times separated by at least 30 minutes, and an updated observation no older than 1 hour. A missing, stale, uninitialized, or insufficient oracle history fails closed. Never treat current `get_dy`, `getAmountsOut`, reserves, `slot0`, or router quotes as slippage oracles. For thin or easily manipulated pools, time averaging alone does not establish safety; examine pool liquidity and risk before registration. Both converters preserve `swap`, `convert`, and `getAmountOut` strategy selectors; no routes are automatically registered beyond the previously approved defaults.
