# BoostHub multi-DEX on-route TWAP/EMA configuration v1

Both chain-local converters retain their already configured launch routes. No additional pool or token is enabled automatically. Owner may register `addDexRoute(tokenIn, tokenOut, Hop[] hops)` using 1–4 contiguous hops, then modify only existing extra routes with `setDexRoute` (98% retention on historical quotes). `isSupportedPair` automatically exposes a registered pair to the staking strategy on the next `syncRewards`. Never attempt to register staking tokens that have no executable pool route.

Hop struct in ABI order:

| Field | Curve EMA | Uniswap v2 | Uniswap v3 |
|---|---|---|---|
| source | 0 | 1 | 2 |
| pool | live Curve swap pool | actual v2 LP pair | actual v3 swap pool |
| router | zero | compatible V2 swap router | compatible V3 SwapRouter with `exactInputSingle` |
| tokenIn/tokenOut | ERC20 pool coins | pool token0/token1 in either direction | pool token0/token1 in either direction |
| fee | 0 | 0 | `pool.fee()` |
| window | 0 | 0 | 1800–86400 seconds |
| indexIn/indexOut | actual pool coin indices | 0/0 | 0/0 |
| curveSwapType | 1 int128 or 3 uint256 | 0 | 0 |

- **Curve:** `price_oracle()` / `price_oracle(index)` reads **directly from the execution pool**; does not substitute `get_dy`, pool spot balances or unrelated feeds. Direct `exchange` calls use the configured coin indices. The existing three Ethereum and one Fraxtal routes keep their established execution and EMA logic.
- **V2:** call permissionless `updateV2Oracle(pool)` once to prime cumulative-price data. A second call **at least 1,800 seconds later** stores the time-weighted averages. The current observation must not be over 3,600 seconds old. An observation gap over 24 hours re-primes rather than silently using an ancient window. Both directions use their actual pool's historic cumulative fields, including counterfactual cumulative growth. Plan a keeper every ~30 minutes on registered V2 route pools; stale routes fail closed.
- **V3:** historical `observe([window,0])` tick accumulators produce a mean tick, rounded towards negative infinity; TickMath converts it to a pool-native output quote. Requires enough pool observation history, which may need increasing observation cardinality on the pool. No fallback to `slot0` spot tick.
- **Execution:** each hop swaps through exactly the pool whose EMA or TWAP is used, with router factory consistency checked for V2/V3. All hops form one atomic transaction. The final output must meet the full-route oracle expectation minus the configured slippage (1% default, cap 4%); an explicitly requested minimum may only strengthen it. Fees and withdrawal settings are unchanged.
- **Safety:** use real audited routers/pools with adequate liquidity. TWAP alone is not manipulation proof. Reject thin-liquidity and exotic transfer-tax tokens before owner registration. Confirm the pool, router, execution selectors, oracle availability, and exact quote on a fork for every newly authorized route.

No Uniswap routes are preinstalled in v13; deployment preflight only requires the existing launch pairs. Newly registered route configuration and the v2 observation state are chain-local and must be separately maintained after deployment.
