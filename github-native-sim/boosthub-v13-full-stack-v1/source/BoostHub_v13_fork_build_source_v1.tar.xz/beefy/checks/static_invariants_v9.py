#!/usr/bin/env python3
"""v8 non-compiler source/interface and randomized arithmetic checks. Does NOT prove runtime behavior."""
from pathlib import Path
import hashlib,random,re
root=Path(__file__).resolve().parents[1]
read=lambda p:(root/p).read_text()
base=read('contracts/beefy/BaseAllToWantBoostHubV5.sol')
strat=read('contracts/beefy/StrategyConvexBoostHubStakingV5.sol')
vault=read('contracts/beefy/BeefyVaultV7FixedV2.sol')
script=read('scripts/DeployBoostHubPair_v6.s.sol')
staking=read('contracts/staking/BoostHubStaking.vy')
iface=read('contracts/beefy/interfaces/IBoostHubStakingV1.sol')
swapper=read('contracts/beefy/interfaces/IBeefySwapperV2.sol')
docs=read('docs/DEPLOYMENT_AND_SECURITY_v8.md')
unchanged={'contracts/beefy/BeefyVaultV7FixedV2.sol':'28d5ab6bb1362d04b4e04e8c0d94abb84c016978836e3ed049b43991e400ed62',
'contracts/staking/BoostHubStaking.vy':'b5fa93956dc2a045375182aa0a12064199e8fadabc075d48798b538a953bb36e'}
for path,sha in unchanged.items():
    assert hashlib.sha256((root/path).read_bytes()).hexdigest()==sha,path

for forbidden in ('address public immutable native;', 'address public immutable depositToken;',
                  'address native;', 'address depositToken;', '_a.native', '_a.depositToken',
                  'function native(', 'function depositToken(', 'WRAPPED_NATIVE', 'DEPOSIT_TOKEN',
                  '_swapNativeToWant(', '_swapRewardsToNative(', '_quoteNativeAsWant(',
                  'function _chargeFees(', 'swap(token, native', 'swap(native,',
                  'keeperAddress', 'function keeper(', 'onlyManager', 'Ownable', 'Pausable',
                  'function panic(', 'function pause(', 'function unpause(',
                  'function setRewardMinAmount(', 'function setLockDuration(',
                  'function setHarvestOnDeposit(', 'protocolShareBps','strategistShareBps'):
    assert forbidden not in base+strat+script,forbidden
assert 'contract BaseAllToWantBoostHubV5' in base
assert 'contract StrategyConvexBoostHubStakingV5 is BaseAllToWantBoostHubV5' in strat
assert 'BaseAllToWantBoostHubV5(_addresses, _fees, _lockDuration, _minWantOutput)' in strat
assert 'struct Addresses {\n        address want;\n        address vault;\n        address swapper;\n        address adminFeeReceiver;\n    }' in base
for f in ('uint256 public immutable minWantOutput;', 'uint256 public immutable lockDuration;',
          'bool public constant harvestOnDeposit = false;', 'function beforeDeposit() external pure {}',
          'uint16 public immutable callShareBps;', 'uint16 public immutable adminShareBps;',
          'address public immutable adminFeeReceiverAddress;', 'function claim() external',
          'function harvest() external', 'function harvest(address callFeeRecipient) external'):
    assert f in base,f
for f in ('uint256 beforeBal = balanceOfWant();\n        _claim();',
          '_chargeWantFees(balanceOfWant() - beforeBal, callFeeRecipient);',
          '_swapRewardsToWant(callFeeRecipient);',
          'if (token == want) continue;',
          '_quoteAmountOut(token, want, amount)',
          'quotedWant - quotedWant * totalPerformanceFeeBps / FEE_DENOMINATOR',
          'IBeefySwapperV2(swapper).swap(token, want, amount)',
          'uint256 wantBefore = balanceOfWant();',
          'uint256 receivedWant = balanceOfWant() - wantBefore;',
          'require(receivedWant != 0, "Converter returned no want");',
          'require(receivedWant - fee >= minWantOutput, "Want output below minimum");',
          '_chargeWantFees(receivedWant, callFeeRecipient);',
          'IERC20(want).safeTransfer(callFeeRecipient, callFeeAmount);',
          'IERC20(want).safeTransfer(adminFeeReceiverAddress, adminFeeAmount);',
          'uint256 adminFeeAmount = fee - callFeeAmount;',
          'emit ChargedFees(want, callFeeAmount, adminFeeAmount);',
          '_chargeWantFees(balanceOfWant() - beforeBal, tx.origin);'):
    assert f in base,f
assert 'native' not in re.sub(r'//[^\n]*', '',base), 'leftover native field or call'
assert 'depositToken' not in base+strat+script
assert 'STRATEGY_ADMIN_FEE_RECEIVER' in script
assert 'isSupportedPair(token, want)' in strat, 'Only registered converter pairs may be swapped'
assert 'function isSupportedPair(' in swapper, 'Swapper interface must expose registry lookup'
for f in ('BaseAllToWantBoostHubV5.Addresses', 'BaseAllToWantBoostHubV5.FeeSettings',
          'new StrategyConvexBoostHubStakingV5', 'new BeefyVaultV7FixedV2',
          'MIN_REWARD_OUTPUT_WANT_BASE_UNITS','STRATEGY_LOCK_DURATION_SECONDS',
          'vm.computeCreateAddress(deployer, nextNonce + 1)'):
    assert f in script,f
for f in ('staking.deposit(amount, address(this))','staking.withdraw(amount)',
          'staking.harvest()', 'staking.claim_rewards()', 'staking.reward_count()',
          'staking.reward_tokens(i)', 'staking.reward_disabled(token)',
          'if (token == want || token == address(staking)) continue;'):
    assert f in strat,f
for method in ('balanceOf','deposit','withdraw','harvest','claim_rewards','reward_count','reward_tokens','reward_disabled','lp_token'):
    assert re.search(rf'\bdef {method}\(',staking) or re.search(rf'\b{method}: public\(',staking),method
    assert re.search(rf'\bfunction {method}\(',iface),method
for method in ('swap','getAmountOut'):
    assert 'function '+method+'(' in swapper
assert 'adminPayment = totalSupply() == 0' in vault and 'fee - adminPayment' in vault
assert 'WRAPPED_NATIVE' in docs and 'No `WRAPPED_NATIVE`' in docs

rng=random.Random(20261011)
# 30k mixed claim-only/direct converted want, with idle principal that MUST be unaffected.
for _ in range(30000):
    initial_principal=rng.randrange(0,10**24)
    direct_claim=rng.randrange(0,10**24)
    converted_received=rng.randrange(0,10**24)
    perf_fee_bps=rng.randrange(10001)
    caller_share_bps=rng.randrange(10001)
    def charge(gross):
        fee=gross*perf_fee_bps//10000
        caller=fee*caller_share_bps//10000
        admin=fee-caller
        net=gross-fee
        assert fee<=gross
        assert caller+admin+net==gross
        return net,caller,admin
    direct_net,direct_call,direct_admin=charge(direct_claim)
    swapped_net,swapped_call,swapped_admin=charge(converted_received)
    remaining=initial_principal+direct_net+swapped_net
    assert remaining+direct_call+direct_admin+swapped_call+swapped_admin==initial_principal+direct_claim+converted_received
    assert initial_principal+charge(0)[0]==initial_principal
# 20k global want minimum eligibility and realized minimum checks (per swap).
for _ in range(20000):
    amount_in=rng.randrange(0,10**24)
    quote_want=amount_in*rng.randrange(0,20000)//10000
    fee_bps=rng.randrange(10001)
    min_want=rng.randrange(0,10**24)
    quote_net=quote_want-quote_want*fee_bps//10000
    allowed=(min_want==0 or quote_net>=min_want)
    if not allowed:
        assert quote_net<min_want
    actual_want=rng.randrange(0,10**24)
    net_actual=actual_want-actual_want*fee_bps//10000
    if allowed and min_want!=0:
        assert (net_actual>=min_want)==(not net_actual<min_want)
# 15k vault withdrawal regressions including final-holder routing.
for i in range(15000):
    gross=rng.randrange(0,10**24)
    withdrawal_bps=rng.randrange(10001)
    withdrawal_fee=gross*withdrawal_bps//10000
    final=i%2==0
    admin=withdrawal_fee if final else withdrawal_fee*3000//10000
    retained=withdrawal_fee-admin
    assert gross == (gross-withdrawal_fee)+admin+retained
    if final: assert admin==withdrawal_fee and retained==0
print('PASS v8: direct reward->want fees; immutable no-native configuration; 30k performance, 20k minimum and 15k withdrawal model cases; unchanged vault/staking hashes; selectors. No compilation.')
