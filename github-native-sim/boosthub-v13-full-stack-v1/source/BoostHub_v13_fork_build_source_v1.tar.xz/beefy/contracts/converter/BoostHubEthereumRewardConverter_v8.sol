// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.28;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {IERC20Metadata} from "@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol";
import {Math} from "@openzeppelin/contracts/utils/math/Math.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {BoostHubDexTwapRoutes} from "./BoostHubDexTwapRoutes_v1.sol";

/// @notice Curve EMA oracle is read DIRECTLY from each selected route pool.
/// @dev Stable/crypto pools expose price_oracle(), price_oracle(uint256), or both.
///      A missing or malformed on-pool oracle makes the swap revert (no fallback).
interface IBoostHubEthereumPoolOracle {
    function price_oracle() external view returns (uint256);
    function price_oracle(uint256 coinIndex) external view returns (uint256);
}
interface IBoostHubEthereumCurveRouter {
    function exchange_multiple(address[9] calldata route, uint256[3][4] calldata params, uint256 amount, uint256 minimum)
        external payable returns (uint256);
}
interface IBoostHubEthereumWstEth {
    function getStETHByWstETH(uint256 amount) external view returns (uint256);
    function unwrap(uint256 amount) external returns (uint256);
}
interface IBoostHubEthereumStablePool {
    function get_dy(int128 i, int128 j, uint256 amount) external view returns (uint256);
    function exchange(int128 i, int128 j, uint256 amount, uint256 minimum) external returns (uint256);
}
interface IBoostHubEthereumCryptoPool {
    function get_dy(uint256 i, uint256 j, uint256 amount) external view returns (uint256);
    function exchange(uint256 i, uint256 j, uint256 amount, uint256 minimum) external returns (uint256);
}

/// @notice Three default Ethereum BoostHub conversions, plus owner-added pairs.
/// @dev v7 remediation: use stETH/ETH NG pool, whose pool-local EMA price_oracle() is available,
///      instead of the retired legacy stETH pool without EMA. Both pools share coin ordering.
/// @dev Explicit initial owner is essential when deploying through a CREATE3
///      proxy: msg.sender inside the constructor is the ephemeral proxy, not
///      the signing EOA. Never use Ownable(msg.sender) for this deployment.
/// @dev For each executed hop, the minimum-output computation calls price_oracle()
///      or price_oracle(index) on THAT hop's actual configured Curve pool address.
///      No owner-supplied or per-pair price feed; no execution-time get_dy() floor.
///      Curve get_dy is ONLY used for the original 98% route-update guard.
///      All Curve prices are expected to be 1e18 EMA prices of coin N in coin 0.
///      If a route pool lacks the required oracle, swaps fail closed. Old Curve
///      stableswap pools may lack EMA; swap availability must be checked onchain.
contract BoostHubEthereumRewardConverter is ReentrancyGuard, Ownable, BoostHubDexTwapRoutes {
    using SafeERC20 for IERC20;

    address public constant CRV = 0xD533a949740bb3306d119CC777fa900bA034cd52;
    address public constant CRVUSD = 0xf939E0A03FB07F59A73314E73794Be0E57ac1b4E;
    address public constant SDCRV = 0xD1b5651E55D4CeeD36251c61c50C889B36F6abB5;
    address public constant WSTETH = 0x7f39C581F595B53c5cb19bD0b3f8dA6c935E2Ca0;
    address public constant STETH = 0xae7ab96520DE3A18E5e111B5EaAb095312D7fE84;
    address public constant FXN = 0x365AccFCa291e7D3914637ABf1F7635dB165Bb09;
    address public constant SDFXN = 0xe19d1c837B8A1C83A56cD9165b2c0256D39653aD;
    address public constant router = 0x99a58482BD75cbab83b27EC03CA68fF489b5788f;
    address public constant TRI_CRV_POOL = 0x4eBdF703948ddCEA3B11f675B4D1Fba9d2414A14;
    address public constant CRV_SDCRV_POOL = 0xCA0253A98D16e9C1e3614caFDA19318EE69772D0;
    address public constant STETH_ETH_POOL = 0x21E27a5E5513D6e65C4f830167390997aA84843a;
    address public constant ETH_FXN_POOL = 0xC15F285679a1Ef2d25F53D4CbD0265E1D02F2A92;
    address public constant FXN_SDFXN_POOL = 0x28Ca243dc0aC075dD012fCf9375C25D18A844d96;
    address internal constant CURVE_NATIVE = 0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE;
    uint256 public constant FEE_DENOMINATOR = 10_000;
    uint256 public constant MAX_SLIPPAGE_BPS = 400;
    uint256 public slippageBps;
    uint256 public constant ROUTE_RETENTION_BPS = 9800;

    struct RouteConfig {
        address[9] route;
        uint256[3][4] params;
    }

    mapping(bytes32 => RouteConfig) private _routes;
    mapping(bytes32 => bool) private _registered;
    address[] private _pairInputs;
    address[] private _pairOutputs;

    error InvalidToken();
    error InvalidRoute();
    error InvalidSlippage();
    error ZeroAmount();
    error ZeroQuote();
    error Slippage();
    error RouteRateTooLow(uint256 oldQuote, uint256 newQuote);
    error InvalidProbeTokenDecimals();
    error PairAlreadyRegistered();
    error PoolOracleUnavailable(address pool, uint256 index);
    error InvalidPoolOracle(address pool);

    event Converted(address indexed caller, address indexed tokenIn, address indexed tokenOut, uint256 amountIn, uint256 amountOut);
    event SetSlippageBps(uint256 slippageBps);
    event PairAdded(address indexed tokenIn, address indexed tokenOut);
    event SetRoute(address indexed tokenIn, address indexed tokenOut, uint256 oldQuote, uint256 newQuote);

    constructor(uint256 slippageBps_, address initialOwner_) Ownable(initialOwner_) {
        _setSlippageBps(slippageBps_);
        _installOriginalRoute(CRV, SDCRV);
        _installOriginalRoute(CRVUSD, SDCRV);
        _installOriginalRoute(WSTETH, SDFXN);
    }

    function setSlippageBps(uint256 newSlippageBps) external onlyOwner {
        _setSlippageBps(newSlippageBps);
    }

    function _setSlippageBps(uint256 newSlippageBps) internal {
        if (newSlippageBps > MAX_SLIPPAGE_BPS) revert InvalidSlippage();
        slippageBps = newSlippageBps;
        emit SetSlippageBps(newSlippageBps);
    }

    /// @notice Replace a pool route only if a DEX quote for 0.0001 input token
    ///         returns the same destination token and at least 98% of the old quote.
    /// @dev Registered routes use the Curve router with swap types 1/3.
    function setRoute(
        address tokenIn,
        address tokenOut,
        address[9] calldata newRoute,
        uint256[3][4] calldata newParams
    ) external onlyOwner {
        _checkPair(tokenIn, tokenOut);
        if (_dexRegistered[_pairKey(tokenIn,tokenOut)]) revert InvalidRoute();
        RouteConfig memory candidate = RouteConfig(newRoute, newParams);
        _validateRoute(tokenIn, tokenOut, candidate);
        uint8 decimals_ = IERC20Metadata(tokenIn).decimals();
        if (decimals_ < 4 || decimals_ > 77) revert InvalidProbeTokenDecimals();
        uint256 probeAmount = 10 ** (uint256(decimals_) - 4);
        uint256 oldQuote = _quoteRoute(tokenIn, _routes[_pairKey(tokenIn, tokenOut)], probeAmount);
        uint256 newQuote = _quoteRoute(tokenIn, candidate, probeAmount);
        if (oldQuote == 0 || newQuote == 0) revert ZeroQuote();
        if (newQuote < Math.mulDiv(oldQuote, ROUTE_RETENTION_BPS, FEE_DENOMINATOR, Math.Rounding.Ceil)) {
            revert RouteRateTooLow(oldQuote, newQuote);
        }
        _routes[_pairKey(tokenIn, tokenOut)] = candidate;
        emit SetRoute(tokenIn, tokenOut, oldQuote, newQuote);
    }

    /// @notice Add a NEW output pair. Existing pair replacements MUST use setRoute().
    /// @dev There is no old route to compare against. Swap protection reads each
    ///      selected pool's on-chain EMA oracle and fails closed if missing.
    function addRoute(
        address tokenIn,
        address tokenOut,
        address[9] calldata newRoute,
        uint256[3][4] calldata newParams
    ) external onlyOwner {
        if (tokenIn == address(0) || tokenOut == address(0) || tokenIn == tokenOut) revert InvalidToken();
        bytes32 key = _pairKey(tokenIn, tokenOut);
        if (_registered[key]) revert PairAlreadyRegistered();
        RouteConfig memory candidate = RouteConfig(newRoute, newParams);
        _validateRoute(tokenIn, tokenOut, candidate);
        _routes[key] = candidate;
        _registerPair(tokenIn, tokenOut);
        emit PairAdded(tokenIn, tokenOut);
    }

    /// @notice Register a new route whose execution pools provide Curve EMA, V2 cumulative TWAP,
    ///         or V3 historical-tick TWAP. Each configured pool is also its swap execution pool.
    /// @dev V2 must first receive two updateV2Oracle calls >= 30 minutes apart.
    function addDexRoute(address tokenIn,address tokenOut,Hop[] calldata hops) external onlyOwner {
        if (tokenIn==address(0) || tokenOut==address(0) || tokenIn==tokenOut || isSupportedPair(tokenIn,tokenOut)) revert PairAlreadyRegistered();
        _configureExtra(tokenIn,tokenOut,hops,false);
        _registerPair(tokenIn,tokenOut);
    }

    /// @notice Replace an existing extra route only when its 0.0001-token historic oracle
    ///         quote remains >=98% of the old route quote, excluding spot manipulation.
    function setDexRoute(address tokenIn,address tokenOut,Hop[] calldata hops) external onlyOwner {
        _configureExtra(tokenIn,tokenOut,hops,true);
    }

    function _registerPair(address tokenIn, address tokenOut) internal {
        bytes32 key = _pairKey(tokenIn, tokenOut);
        if (_registered[key]) revert PairAlreadyRegistered();
        _registered[key] = true;
        _pairInputs.push(tokenIn);
        _pairOutputs.push(tokenOut);
    }

    function _installOriginalRoute(address tokenIn, address tokenOut) internal {
        (address[9] memory initialRoute, uint256[3][4] memory initialParams) = _originalRoute(tokenIn, tokenOut);
        RouteConfig memory initial = RouteConfig(initialRoute, initialParams);
        _validateRoute(tokenIn, tokenOut, initial);
        _routes[_pairKey(tokenIn, tokenOut)] = initial;
        _registerPair(tokenIn, tokenOut);
    }

    function _pairKey(address tokenIn, address tokenOut) internal pure returns (bytes32) {
        return keccak256(abi.encode(tokenIn, tokenOut));
    }

    receive() external payable {}

    function routeCount() external view returns (uint256) { return _pairInputs.length; }

    function routeAt(uint256 index) external view returns (address tokenIn, address tokenOut) {
        if (index >= _pairInputs.length) revert InvalidRoute();
        return (_pairInputs[index], _pairOutputs[index]);
    }

    function isSupportedPair(address tokenIn, address tokenOut) public view returns (bool) {
        return _registered[_pairKey(tokenIn, tokenOut)];
    }

    function route(address tokenIn, address tokenOut) external view returns (address[9] memory) {
        _checkPair(tokenIn, tokenOut);
        if (_dexRegistered[_pairKey(tokenIn,tokenOut)]) revert InvalidRoute();
        return _routes[_pairKey(tokenIn, tokenOut)].route;
    }

    function swapParams(address tokenIn, address tokenOut) external view returns (uint256[3][4] memory) {
        _checkPair(tokenIn, tokenOut);
        if (_dexRegistered[_pairKey(tokenIn,tokenOut)]) revert InvalidRoute();
        return _routes[_pairKey(tokenIn, tokenOut)].params;
    }

    function pools(address tokenIn, address tokenOut) external view returns (address[] memory routePools) {
        _checkPair(tokenIn, tokenOut);
        bytes32 key=_pairKey(tokenIn,tokenOut);
        if (_dexRegistered[key]) {
            Hop[] memory hops=this.dexHops(tokenIn,tokenOut);
            routePools=new address[](hops.length);
            for (uint256 k;k<hops.length;k++) routePools[k]=hops[k].pool;
            return routePools;
        }
        address[9] memory route_ = _routes[key].route;
        uint256 count;
        for (uint256 i = 1; i < 9 && route_[i] != address(0); i += 2) count++;
        routePools = new address[](count);
        for (uint256 i; i < count; i++) routePools[i] = route_[1 + i * 2];
    }

    function _checkPair(address tokenIn, address tokenOut) internal view {
        if (!isSupportedPair(tokenIn, tokenOut)) revert InvalidToken();
    }

    function _validateRoute(address tokenIn, address tokenOut, RouteConfig memory config) internal pure {
        if (config.route[0] != (tokenIn == WSTETH ? STETH : tokenIn)) revert InvalidRoute();
        uint256 count;
        bool ended;
        address lastToken = config.route[0];
        for (uint256 hop; hop < 4; ++hop) {
            address pool = config.route[1 + 2 * hop];
            address nextToken = config.route[2 + 2 * hop];
            if (pool == address(0) || nextToken == address(0)) {
                if (pool != address(0) || nextToken != address(0)) revert InvalidRoute();
                ended = true;
                if (config.params[hop][0] != 0 || config.params[hop][1] != 0 || config.params[hop][2] != 0) revert InvalidRoute();
                continue;
            }
            if (ended || nextToken == lastToken) revert InvalidRoute();
            uint256 swapType = config.params[hop][2];
            if (swapType != 1 && swapType != 3) revert InvalidRoute();
            if (config.params[hop][0] == config.params[hop][1]) revert InvalidRoute();
            lastToken = nextToken;
            count++;
        }
        if (count == 0 || lastToken != tokenOut) revert InvalidRoute();

    }

    /// @notice Expected output from each pool's own EMA oracle; NEVER from get_dy().
    /// @dev In a Curve EMA, price_oracle(k) reports 1e18-scaled value of coin
    ///      k+1 denominated in coin0. For two-coin pools, price_oracle()
    ///      reports the coin1 price in coin0. Inversion/cross-rate is automatic.
    ///      All hops and the wstETH->stETH wrap-rate adjustment are included.
    function previewConvert(address tokenIn, address tokenOut, uint256 amountIn) public view returns (uint256) {
        _checkPair(tokenIn, tokenOut);
        if (amountIn == 0) return 0;
        bytes32 key=_pairKey(tokenIn,tokenOut);
        if (_dexRegistered[key]) return _extraQuote(key,amountIn);
        return _oracleQuoteRoute(tokenIn, _routes[key], amountIn);
    }

    /// @dev A pool MUST expose price_oracle() for two coins or
    ///      price_oracle(index-1) for indexed multi-coin oracles.
    ///      No reads of get_dy(), get_p(), last_prices(), or spot balances here.
    function _coinOraclePrice(address pool, uint256 coinIndex) internal view returns (uint256 price) {
        if (coinIndex == 0) return 1e18;
        bytes memory result;
        bool ok;
        if (coinIndex == 1) {
            // Prefer the ordinary 2-coin getter. Some pools expose indexed only.
            (ok, result) = pool.staticcall(abi.encodeWithSignature("price_oracle()"));
            if (!ok || result.length != 32) {
                (ok, result) = pool.staticcall(abi.encodeWithSignature("price_oracle(uint256)", uint256(0)));
            }
        } else {
            // Curve indexed getter uses coinIndex - 1 for coinIndex >= 1.
            (ok, result) = pool.staticcall(abi.encodeWithSignature("price_oracle(uint256)", coinIndex - 1));
        }
        if (!ok || result.length != 32) revert PoolOracleUnavailable(pool, coinIndex);
        price = abi.decode(result, (uint256));
        if (price == 0) revert InvalidPoolOracle(pool);
    }

    function _oracleQuoteRoute(address tokenIn, RouteConfig memory config, uint256 amountIn)
        internal view returns (uint256 amountOut)
    {
        amountOut = tokenIn == WSTETH
            ? IBoostHubEthereumWstEth(WSTETH).getStETHByWstETH(amountIn)
            : amountIn;
        if (amountOut == 0) return 0;
        address coinIn = config.route[0];
        for (uint256 hop; hop < 4; ++hop) {
            address pool = config.route[1 + 2 * hop];
            if (pool == address(0)) break;
            address coinOut = config.route[2 + 2 * hop];
            uint256 indexIn = config.params[hop][0];
            uint256 indexOut = config.params[hop][1];
            if (indexIn == indexOut || indexIn > 3 || indexOut > 3) revert InvalidRoute();
            // BOTH values are from this exact swap pool; no external feed.
            // Read at most the one or two coin-index EMA sources needed.
            uint256 priceIn = _coinOraclePrice(pool, indexIn);
            uint256 priceOut = _coinOraclePrice(pool, indexOut);
            uint256 baseIn = _tokenBase(coinIn);
            uint256 baseOut = _tokenBase(coinOut);
            // Each coin has an EMA value relative to coin0; quoted output is
            // amountIn/baseIn * priceIn/priceOut * baseOut.
            // Avoid precision loss by scaling BEFORE the final division.
            uint256 pricedIn = Math.mulDiv(amountOut, priceIn, baseIn);
            amountOut = Math.mulDiv(pricedIn, baseOut, priceOut);
            if (amountOut == 0) return 0;
            coinIn = coinOut;
        }
    }

    function _tokenBase(address token) internal view returns (uint256) {
        if (token == CURVE_NATIVE) return 1e18;
        uint8 d = IERC20Metadata(token).decimals();
        if (d > 77) revert InvalidProbeTokenDecimals();
        return 10 ** uint256(d);
    }

    function _quoteRoute(address tokenIn, RouteConfig memory config, uint256 amountIn)
        internal view returns (uint256 amountOut) {
        amountOut = tokenIn == WSTETH
            ? IBoostHubEthereumWstEth(WSTETH).getStETHByWstETH(amountIn)
            : amountIn;
        if (amountOut == 0) return 0;
        for (uint256 hop; hop < 4; ++hop) {
            address pool = config.route[1 + 2 * hop];
            if (pool == address(0)) break;
            uint256 i = config.params[hop][0];
            uint256 j = config.params[hop][1];
            if (config.params[hop][2] == 1) {
                if (i > 127 || j > 127) revert InvalidRoute();
                amountOut = IBoostHubEthereumStablePool(pool).get_dy(int128(int256(i)), int128(int256(j)), amountOut);
            } else {
                amountOut = IBoostHubEthereumCryptoPool(pool).get_dy(i, j, amountOut);
            }
            if (amountOut == 0) return 0;
        }
    }

    function getAmountOut(address tokenIn, address tokenOut, uint256 amountIn) external view returns (uint256) {
        return previewConvert(tokenIn, tokenOut, amountIn);
    }

    /// @notice Legacy four-argument call, also enforcing the per-pool EMA floor.
    function convert(address tokenIn, address tokenOut, uint256 amountIn, uint256 minAmountOut)
        external nonReentrant returns (uint256) {
        return _convert(tokenIn, tokenOut, amountIn, _protectedMinOut(tokenIn, tokenOut, amountIn, minAmountOut, slippageBps));
    }

    /// @notice Default swap: specify tokens and input amount only.
    function swap(address tokenIn, address tokenOut, uint256 amountIn) external nonReentrant returns (uint256) {
        return _convert(tokenIn, tokenOut, amountIn, _protectedMinOut(tokenIn, tokenOut, amountIn, 0, slippageBps));
    }

    /// @notice Explicit minimum output (also enforces every route pool's EMA floor).
    function swap(address tokenIn, address tokenOut, uint256 amountIn, uint256 minAmountOut)
        external nonReentrant returns (uint256) {
        return _convert(tokenIn, tokenOut, amountIn, _protectedMinOut(tokenIn, tokenOut, amountIn, minAmountOut, slippageBps));
    }

    /// @notice Caller-chosen slippage tolerance, capped at 4%.
    /// @dev Separate function name because the Solidity ABI cannot distinguish two uint256 arguments
    ///      representing minAmountOut and slippageBps in otherwise identical signatures.
    function swapWithSlippage(address tokenIn, address tokenOut, uint256 amountIn, uint256 allowedSlippageBps)
        external nonReentrant returns (uint256) {
        return _convert(tokenIn, tokenOut, amountIn, _protectedMinOut(tokenIn, tokenOut, amountIn, 0, allowedSlippageBps));
    }

    function _protectedMinOut(address tokenIn, address tokenOut, uint256 amountIn, uint256 requestedMinOut, uint256 toleranceBps)
        internal view returns (uint256 minimum) {
        if (toleranceBps > MAX_SLIPPAGE_BPS) revert InvalidSlippage();
        if (amountIn == 0) revert ZeroAmount();
        // Never use same-block pool quotes as slippage protection.
        uint256 quoted = previewConvert(tokenIn, tokenOut, amountIn);
        if (quoted == 0) revert ZeroQuote();
        minimum = Math.mulDiv(quoted, FEE_DENOMINATOR - toleranceBps, FEE_DENOMINATOR);
        if (requestedMinOut > minimum) minimum = requestedMinOut;
        if (minimum == 0) revert ZeroQuote();
    }

    function _convert(address tokenIn, address tokenOut, uint256 amountIn, uint256 minAmountOut)
        internal returns (uint256 amountOut) {
        if (!isSupportedPair(tokenIn, tokenOut)) revert InvalidToken();
        if (amountIn == 0) revert ZeroAmount();
        bytes32 key=_pairKey(tokenIn,tokenOut);
        if (_dexRegistered[key]) {
            amountOut=_executeExtra(key,amountIn,minAmountOut,msg.sender);
            emit Converted(msg.sender,tokenIn,tokenOut,amountIn,amountOut);
            return amountOut;
        }
        RouteConfig memory config = _routes[key];
        {
            address[9] memory route_ = config.route;
            uint256[3][4] memory params = config.params;
            IERC20(tokenIn).safeTransferFrom(msg.sender, address(this), amountIn);
            uint256 routerAmount = amountIn;
            address routerToken = tokenIn;
            if (tokenIn == WSTETH) {
                uint256 beforeStEth = IERC20(STETH).balanceOf(address(this));
                IBoostHubEthereumWstEth(WSTETH).unwrap(amountIn);
                routerAmount = IERC20(STETH).balanceOf(address(this)) - beforeStEth;
                if (routerAmount == 0) revert ZeroQuote();
                routerToken = STETH;
            }
            IERC20(routerToken).forceApprove(router, routerAmount);
            uint256 beforeOut = IERC20(tokenOut).balanceOf(address(this));
            IBoostHubEthereumCurveRouter(router).exchange_multiple(route_, params, routerAmount, minAmountOut);
            IERC20(routerToken).forceApprove(router, 0);
            amountOut = IERC20(tokenOut).balanceOf(address(this)) - beforeOut;
            if (amountOut == 0) revert ZeroQuote();
            if (amountOut < minAmountOut) revert Slippage();
            IERC20(tokenOut).safeTransfer(msg.sender, amountOut);
        }
        emit Converted(msg.sender, tokenIn, tokenOut, amountIn, amountOut);
    }

    function _originalRoute(address tokenIn, address tokenOut) internal pure
        returns (address[9] memory r, uint256[3][4] memory p) {
        if (tokenIn == CRV && tokenOut == SDCRV) {
            r[0] = CRV;r[1] = CRV_SDCRV_POOL;r[2] = SDCRV;p[0] = [uint256(0),1,1];
        } else if (tokenIn == CRVUSD && tokenOut == SDCRV) {
            r[0] = CRVUSD;r[1] = TRI_CRV_POOL;r[2] = CRV;r[3] = CRV_SDCRV_POOL;r[4] = SDCRV;
            p[0] = [uint256(0),2,3];p[1] = [uint256(0),1,1];
        } else if (tokenIn == WSTETH && tokenOut == SDFXN) {
            r[0] = STETH;r[1] = STETH_ETH_POOL;r[2] = CURVE_NATIVE;r[3] = ETH_FXN_POOL;
            r[4] = FXN;r[5] = FXN_SDFXN_POOL;r[6] = SDFXN;
            p[0] = [uint256(1),0,1];p[1] = [uint256(0),1,3];p[2] = [uint256(0),1,1];
        } else revert InvalidToken();
    }


}
